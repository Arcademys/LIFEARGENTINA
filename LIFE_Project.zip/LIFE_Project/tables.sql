
use gruther4_life;

DROP TABLE IF EXISTS Users;
CREATE TABLE Users(
	user_id SERIAL,
	user_name VARCHAR(255) UNIQUE,
	user_password CHAR(32),
	user_arrival_date DATE,
	user_departure_date DATE,
	user_fullname VARCHAR(255),
	user_gender INT,
	user_lang INT DEFAULT 1,
	user_nationality VARCHAR(255),
	user_region INT,
	user_passport VARCHAR(255),
	user_email VARCHAR(255),
	user_email_valid BOOLEAN DEFAULT 1,
	user_date_of_birth DATE,
	user_marital_status INT,
	user_religion INT,
	user_spanish_level INT,
	user_purpose_of_visit VARCHAR(255),
	user_reference VARCHAR(255),
	user_local_address VARCHAR(255),
	user_local_phone_cell VARCHAR(255),
	user_local_phone VARCHAR(255),
	user_home_address VARCHAR(255),
	user_home_phone_cell VARCHAR(255),
	user_home_phone VARCHAR(255),
	user_education_level INT,
	user_education_institution VARCHAR(255),
	user_health_diseases VARCHAR(255),
	user_health_allergies VARCHAR(255),
	user_health_medication VARCHAR(255),
	user_health_dietary_req VARCHAR(255),
	user_health_medical_coverage VARCHAR(255),
	user_emergency_contact_name VARCHAR(255),
	user_emergency_contact_phone VARCHAR(255),
	user_vol_area_recreation BOOLEAN,
	user_vol_area_sports BOOLEAN,
	user_vol_area_teaching BOOLEAN,
	user_vol_area_language BOOLEAN,
	user_vol_area_hospital BOOLEAN,
	user_vol_area_art BOOLEAN,
	user_vol_area_fundraising BOOLEAN,
	user_vol_area_translation BOOLEAN,
	user_vol_area_admin BOOLEAN,
	user_vol_area_management BOOLEAN,
	user_vol_area_research BOOLEAN,
	user_vol_area_other VARCHAR(255),
	user_status INT DEFAULT 8,
	user_date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	user_last_login TIMESTAMP DEFAULT 0,
	user_balance_usd DOUBLE DEFAULT 0,
	user_balance_arg DOUBLE DEFAULT 0,
	user_org INT DEFAULT 1,
	user_fund_potential BOOLEAN DEFAULT 0,
	user_trans_potential BOOLEAN DEFAULT 0,
	PRIMARY KEY (user_id)
);


DROP TABLE IF EXISTS Contacts;
CREATE TABLE Contacts(
	contact_id SERIAL,
	contact_name VARCHAR(255) UNIQUE,
	contact_lang VARCHAR(255),
	contact_nationality VARCHAR(255),
	contact_email VARCHAR(255),
	contact_email_valid BOOLEAN DEFAULT 1,
	contact_active BOOLEAN DEFAULT 1,
	PRIMARY KEY (contact_id)
);


DROP TABLE IF EXISTS UserNotes;
CREATE TABLE UserNotes(
	note_id SERIAL,
	note_user BIGINT,
	note_note VARCHAR(255) UNIQUE,
	note_date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	note_created_by BIGINT,
	note_private BOOLEAN DEFAULT 0,
	note_deleted BOOLEAN DEFAULT 0,
	PRIMARY KEY (note_id)
);

DROP VIEW IF EXISTS SmallUsers;
CREATE VIEW SmallUsers AS SELECT
	user_id,
	user_fullname,
	user_status
	FROM Users;

DROP TABLE IF EXISTS Choices;
CREATE TABLE Choices(
	choice_id SERIAL,
	choice_text VARCHAR(255),
	choice_value INT,
	choice_field VARCHAR(255),
	PRIMARY KEY (choice_id)
);

DROP TABLE IF EXISTS Locations;
CREATE TABLE Locations(
	loc_id SERIAL,
	loc_name VARCHAR(255),
	loc_desc VARCHAR(255),
	loc_cost_usd DOUBLE,
	loc_cost_arg DOUBLE,
	PRIMARY KEY (loc_id)
);

DROP TABLE IF EXISTS Organizations;
CREATE TABLE Organizations(
	org_id SERIAL,
	org_name VARCHAR(255),
	org_notes VARCHAR(255),
	org_unlimited BOOLEAN DEFAULT 0,
	PRIMARY KEY (org_id)
);


DROP TABLE IF EXISTS Events;
CREATE TABLE Events(
	event_id SERIAL,
	event_name VARCHAR(255),
	event_desc VARCHAR(255),
	event_type BIGINT,
	event_location BIGINT,
	event_coordinator BIGINT,
	event_cost_usd DOUBLE,
	event_cost_arg DOUBLE,
	event_max_users INT DEFAULT 0,
	event_date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	event_created_by BIGINT,
	event_registration_deadline TIMESTAMP,
	event_meeting_time TIMESTAMP,
	event_departure_time TIMESTAMP,
	event_departed BOOLEAN DEFAULT 0,
	event_actual_departure_time TIMESTAMP,
	event_return_time TIMESTAMP,
	event_actual_return_time TIMESTAMP,
	event_cancellation_time TIMESTAMP,
	event_meeting_location VARCHAR(255),
	event_cancelled BOOLEAN DEFAULT 0,
	event_cancelled_by BIGINT DEFAULT NULL,
	event_completed BOOLEAN DEFAULT 0,
	event_completed_by BIGINT DEFAULT NULL,
	event_notes VARCHAR(255),
	PRIMARY KEY (event_id)
);

DROP VIEW IF EXISTS SmallEvents;
CREATE VIEW SmallEvents AS SELECT
	event_id,
	event_max_users > 0 AND event_max_users <= (SELECT COUNT(reg_id) FROM Registrations WHERE reg_cancelled = 0 AND reg_event = event_id) AS event_full,
	event_name,
	event_desc,
	event_type,
	event_location,
	event_coordinator,
	event_cost_usd,
	event_cost_arg,
	event_registration_deadline,
	event_meeting_time,
	event_departure_time,
	event_return_time,
	event_meeting_location
	FROM Events
	WHERE event_cancelled = 0 AND event_completed = 0 AND event_departed = 0;


DROP VIEW IF EXISTS SmallEventsUnfiltered;
CREATE VIEW SmallEventsUnfiltered AS SELECT
	event_id,
	event_max_users > 0 AND event_max_users <= (SELECT COUNT(reg_id) FROM Registrations WHERE reg_cancelled = 0 AND reg_event = event_id) AS event_full,
	event_name,
	event_desc,
	event_type,
	event_location,
	event_coordinator,
	event_cost_usd,
	event_cost_arg,
	event_registration_deadline,
	event_meeting_time,
	event_departure_time,
	event_return_time,
	event_meeting_location
	FROM Events;


DROP TABLE IF EXISTS EventTypes;
CREATE TABLE EventTypes(
	type_id SERIAL,
	type_name VARCHAR(255),
	type_desc VARCHAR(255),
	PRIMARY KEY (type_id)
);

DROP TABLE IF EXISTS Registrations;
CREATE TABLE Registrations(
	reg_id SERIAL,
	reg_user BIGINT,
	reg_event BIGINT,
	reg_date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	reg_created_by BIGINT,
	reg_cancelled BOOLEAN DEFAULT 0,
	reg_cancelled_by BIGINT DEFAULT NULL,
	reg_cancellation_time TIMESTAMP DEFAULT 0,
	reg_attended BOOLEAN DEFAULT 0,
	reg_free BOOLEAN DEFAULT 0,
	PRIMARY KEY (reg_id)
);

DROP TABLE IF EXISTS Transactions;
CREATE TABLE Transactions(
	trans_id SERIAL,
	trans_user BIGINT,
	trans_type INT,
	trans_reference BIGINT,
	trans_amount_usd DOUBLE,
	trans_amount_arg DOUBLE,
	trans_notes VARCHAR(255),
	trans_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	trans_created_by BIGINT,
	PRIMARY KEY (trans_id)
);

DROP TABLE IF EXISTS Languages;
CREATE TABLE Languages(
	lang_id SERIAL,
	lang_en VARCHAR(255),
	lang_sp VARCHAR(255),
	PRIMARY KEY (lang_id)
);


