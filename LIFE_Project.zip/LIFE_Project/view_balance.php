<?

$index = $_GET['index'];
include_once "header_system.php";

// The if the page is for the current user, it is always visible. Otherwise, more restrictive
if ($index == $_SESSION["userid"]){
	$pageStatus = 0;
}
else{
	$pageStatus = 2;
}

// Get the user name and the final balance
$query = "SELECT user_fullname, FORMAT(ROUND(user_balance_usd, 2), 2), FORMAT(ROUND(user_balance_arg, 2), 2) FROM Users WHERE user_id = " . $index;
$result = ExecuteQuery($query);
if ($row = mysql_fetch_row($result)){
	$userName = $row[0];
	$usd = $row[1];
	$arg = $row[2];
}
else{
	$pageTitle = Translate("Invalid User");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("User data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

include_once "functions.php";
$pageTitle = Translate("View Balance History") . " - " . $userName;
include_once "header.php";

// Get the list of transactions for this user, ordered by most recent to oldest
// Output includes transaction date, transaction type, transaction reference (or note), transaction amount, user who entered it, and the transaction ID
$query = "SELECT a.trans_date, b.choice_text, IF (a.trans_type = 1, c.event_name, a.trans_notes), FORMAT(ROUND(a.trans_amount_usd, 2), 2), FORMAT(ROUND(a.trans_amount_arg, 2), 2), d.user_fullname, a.trans_reference, a.trans_id FROM Transactions AS a LEFT OUTER JOIN Choices AS b ON (a.trans_type = b.choice_value AND b.choice_field = 'trans_type') LEFT OUTER JOIN Events AS c ON (a.trans_reference = c.event_id AND a.trans_type = 1) LEFT OUTER JOIN Users AS d ON (a.trans_created_by = d.user_id) WHERE trans_user = " . $index . " ORDER BY trans_date DESC";
$result = ExecuteQuery($query);

$noResults = true;
while ($row = mysql_fetch_row($result)){
	$thisIndex = $row[count($row) - 1];
	if ($noResults){
		// first row, so display header, and final balance
		// note that header takes 3 rows of the table
		echo "<TABLE BGCOLOR=" . $tableBGColor . " CELLPADDING=5 ALIGN=CENTER>\n";
		echo "<TR BGCOLOR=" . $tableHeadingColor . ">\n";
		echo "<TD ALIGN=CENTER NOWRAP ROWSPAN=2 VALIGN=MIDDLE><B>" . Translate("Date") . "</B></TD>\n";
		echo "<TD ALIGN=CENTER NOWRAP ROWSPAN=2 VALIGN=MIDDLE><B>" . Translate("Type") . "</B></TD>\n";
		echo "<TD ALIGN=CENTER ROWSPAN=2 VALIGN=MIDDLE><B>" . Translate("Notes") . "</B></TD>\n";
		echo "<TD ALIGN=CENTER NOWRAP COLSPAN=2><B>US Dollars</B></TD>\n";
		echo "<TD ALIGN=CENTER NOWRAP COLSPAN=2><B>ARG Pesos</B></TD>\n";
		echo "<TD ALIGN=CENTER NOWRAP ROWSPAN=2 VALIGN=MIDDLE><B>" . Translate("User") . "</B></TD>\n";
		echo "</TR>\n";
		echo "<TR BGCOLOR=" . $tableHeadingColor . ">\n";
		echo "<TD ALIGN=CENTER NOWRAP><B>" . Translate("Change") . "</B></TD>\n";
		echo "<TD ALIGN=CENTER NOWRAP><B>" . Translate("Balance") . "</B></TD>\n";
		echo "<TD ALIGN=CENTER NOWRAP><B>" . Translate("Change") . "</B></TD>\n";
		echo "<TD ALIGN=CENTER NOWRAP><B>" . Translate("Balance") . "</B></TD>\n";
		echo "</TR>\n";
		echo "<TR BGCOLOR=" . $tableCellColor . ">\n";
		echo "<TD ALIGN=CENTER NOWRAP COLSPAN=3>" . Translate("Final Balance") . ": <I>(" . Translate("Owed to LIFE") . ")</I></TD>\n";
		echo "<TD ALIGN=RIGHT NOWRAP></TD>\n";
		echo "<TD ALIGN=RIGHT NOWRAP>" . $usd . "</TD>\n";
		echo "<TD ALIGN=RIGHT NOWRAP></TD>\n";
		echo "<TD ALIGN=RIGHT NOWRAP>" . $arg . "</TD>\n";
		echo "<TD ALIGN=CENTER NOWRAP></TD>\n";
		echo "</TR>\n";
		$noResults = false;
	}

	// Show the transaction information
	echo "<TR BGCOLOR=" . $tableCellColor . ">\n";

	// only show the link if the user has access to follow it...
	if ($_SESSION["userstatus"] <= 2){
		// row 7 is the transaction index, row 0 is the transaction date/time
		echo "<TD ALIGN=CENTER NOWRAP><A HREF=view_item.php?table=Transactions&index=" . $row[7] . ">" . DateOutput($row[0]) . "</A></TD>\n";
	}
	else{
		// row 0 is the transaction date/time
		echo "<TD ALIGN=CENTER NOWRAP>" . DateOutput($row[0]) . "</TD>\n";
	}
	// row 1 is the event type
	echo "<TD ALIGN=CENTER NOWRAP>" . Translate($row[1]) . "</TD>\n";

	// only show the link if the user has access to follow it...
	if ($row[6] && $_SESSION["userstatus"] <= 2){
		// row 6 is the event reference, and row 2 is the note or the event name
		echo "<TD ALIGN=CENTER><A HREF=view_item.php?table=Events&index=" . $row[6] . ">" . $row[2] . "</A></TD>\n";
	}
	else{
		// row 2 is the note or the event name
		echo "<TD ALIGN=CENTER>" . $row[2] . "</TD>\n";
	}

	// rows 3 and 4 are transaction amounts, row 5 is the name of the person who created the transaction
	echo "<TD ALIGN=RIGHT NOWRAP>" . $row[3] . "</TD>\n";
	echo "<TD ALIGN=RIGHT NOWRAP>" . $usd . "</TD>\n";
	echo "<TD ALIGN=RIGHT NOWRAP>" . $row[4] . "</TD>\n";
	echo "<TD ALIGN=RIGHT NOWRAP>" . $arg . "</TD>\n";
	echo "<TD ALIGN=CENTER NOWRAP>" . $row[5] . "</TD>\n";
	echo "</TR>\n";

	// update running balance (counting back from current balance)
	$usd -= $row[3];
	$arg -= $row[4];
	$usd = number_format($usd, 2);
	$arg = number_format($arg, 2);

}
if (!$noResults){
	// if no transactions, show only initial balance
	echo "<TR BGCOLOR=" . $tableCellColor . ">\n";
	echo "<TD ALIGN=CENTER NOWRAP COLSPAN=3>" . Translate("Initial Balance") . ":</TD>\n";
	echo "<TD ALIGN=RIGHT NOWRAP></TD>\n";
	echo "<TD ALIGN=RIGHT NOWRAP>" . $usd . "</TD>\n";
	echo "<TD ALIGN=RIGHT NOWRAP></TD>\n";
	echo "<TD ALIGN=RIGHT NOWRAP>" . $arg . "</TD>\n";
	echo "<TD ALIGN=CENTER></TD>\n";
	echo "</TR>\n";
	echo "</TABLE>\n";
}
else{
	echo "<P ALIGN=CENTER>" . Translate("No balance history") . "</P>\n";
}

$currentUserStatus = $_SESSION["userstatus"];
if ($currentUserStatus <= 2){
	echo "<P ALIGN=CENTER>\n";
	echo "<A HREF=enter_payment_init.php?index=" . $index . ">" . Translate("Enter Payment") . "</A> <B>|</B> \n";
	echo "<A HREF=enter_tshirt_fee_init.php?index=" . $index . ">" . Translate("Enter T-Shirt Fee") . "</A> <B>|</B> \n";

	if ($currentUserStatus <= 2){
		echo "<A HREF=enter_adjustment_init.php?index=" . $index . ">" . Translate("Enter Adjustment") . "</A> <B>|</B> \n";
	}
}


include_once "footer.php";
?>

