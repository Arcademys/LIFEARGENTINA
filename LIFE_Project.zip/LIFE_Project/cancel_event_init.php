<?
include_once "header_system.php";

$pageStatus = 2;

$index = $_GET["index"];

$query = "SELECT event_name FROM Events WHERE event_cancelled = 0 AND event_completed = 0 AND event_departed = 0 AND event_id = " . $index;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	// The requested event does not exist, or is not valid for cancellation

	$pageTitle = Translate("Cancel Event") . " - " . Translate("Invalid");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("Event data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

$eventName = $row[0];

$pageTitle = Translate("Cancel Event") . " - " . htmlspecialchars($eventName);
include_once "header.php";

// display confirmation dialog

echo "<FORM NAME=cancelEventForm METHOD=POST ACTION=cancel_event_results.php>\n";
echo "<P ALIGN=CENTER>" . Translate("Are you sure?  This action cannot be undone.") . "<BR>\n";
echo "<INPUT TYPE=HIDDEN NAME=index VALUE=" . $index . ">\n";
echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Return", 1) . "' onClick='window.location.href=\"view_item.php?table=Events&index=" . $index . "\"'>" . Translate("Return", 2) . "\n";
echo "<INPUT TYPE=SUBMIT NAME=submit VALUE='" . Translate("Cancel Event", 1) . "'>" . Translate("Cancel Event", 2) . "\n";
echo "</P>\n";
echo "</FORM>\n";

include_once "footer.php";
?>

