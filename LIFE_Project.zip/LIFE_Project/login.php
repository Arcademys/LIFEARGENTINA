<?php

include_once "header_system.php";

// Confirm that user exists, and password matches
$query = "SELECT user_id, user_fullname, user_status FROM Users WHERE user_name = '" . $_POST['username'] . "' AND user_password = '" . md5($_POST['password']) . "'";
$result = ExecuteQuery($query);
if ($row = mysql_fetch_row($result)){

	// User is valid, set variables
	$_SESSION['userid'] = $row[0];
	$_SESSION['auth'] = "TRUE";

	// Set last login value
	$query = "UPDATE Users SET user_last_login = CURRENT_TIMESTAMP WHERE user_id = " . $row[0];
	ExecuteQuery($query);

	// Redirect to internal page if set
	if ($_POST['redirect']){
		header("Location: " . urldecode($_POST['redirect']));
	}
	else{
		header("Location: home.php");
	}
}
else{
	// not a valid login - report error

	// destoying the session erases any login information
	session_destroy();
	$indexErrorMsg = "<P ALIGN=CENTER><B>" . Translate("Login Failed") . "</B></P>";
	$_GET['lang'] = $_POST['lang'];

	// include the main login page
	include "index.php";
	include_once "footer_system.php";
}

?>

