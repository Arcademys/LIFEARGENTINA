<?
include_once "header_system.php";
$pageTitle = Translate("Home");
include_once "header.php";

echo "<P>" . Translate("Welcome to LIFE Argentina's online portal.  Please choose an option from the following list:") . "</P>\n";

echo "<UL>\n";

// Navigational list (high user access)
if ($_SESSION['userstatus'] <= 2){
	echo "<LI>\n";
	echo "<B>" . Translate("Search") . ":</B><BR>\n";
	echo "<UL>\n";
	echo "<LI><A HREF=search_form.php?table=Contacts>" . Translate("Contacts") . "</A></LI>\n";
	echo "<LI><A HREF=search_form.php?table=Users>" . Translate("Users") . "</A></LI>\n";
	echo "<LI><A HREF=search_form.php?table=Events>" . Translate("Events") . "</A></LI>\n";
	echo "<LI><A HREF=search_form.php?table=Locations>" . Translate("Locations") . "</A></LI>\n";
	echo "<LI><A HREF=search_form.php?table=EventTypes>" . Translate("Event Types") . "</A></LI>\n";
	echo "<LI><A HREF=search_form.php?table=Organizations>" . Translate("Organizations") . "</A></LI>\n";
	echo "<LI><A HREF=search_form.php?table=Languages>" . Translate("Translations") . "</A></LI>\n";
	echo "<LI><A HREF=search_form.php?table=Transactions>" . Translate("Transactions") . "</A></LI>\n";
	echo "<LI><A HREF=predefined_user_searches.php>" . Translate("Predefined User Searches") . "</A></LI>\n";
	echo "<LI><A HREF=predefined_event_searches.php>" . Translate("Predefined Event Searches") . "</A></LI>\n";
	echo "</UL>\n";
	echo "</LI>\n";
}

// Get list of events that you are coordinating, allow "complete" for these events...
$eventFound = false;
$query = "SELECT event_name, event_id FROM Events WHERE event_cancelled = 0 AND event_completed = 0 AND event_departed = 1 AND event_coordinator = " . $_SESSION["userid"];
$result = ExecuteQuery($query);
while (($row = mysql_fetch_row($result)) && $_SESSION['userstatus'] <= 3){
	if (!$eventFound){
		$eventFound = true;
		echo "<LI>\n";
		echo "<B>" . Translate("Coordinator") . ":</B><BR>\n";
		echo "<UL>\n";
	}
	echo "<LI><A HREF=complete_event_init.php?index=" . $row[1] . ">" . Translate("Complete Event") . " '" . htmlspecialchars($row[0]) . "'</A></LI>\n";
}
if ($eventFound){
	echo "</UL>\n";
	echo "</LI>\n";
}

// Volunteers can register for events, and view their balance
echo "<LI>\n";
echo "<B>" . Translate("Volunteer") . ":</B><BR>\n";
echo "<UL>\n";
if ($_SESSION['userstatus'] <= 4){
	echo "<LI><A HREF=user_registrations.php?index=" . $_SESSION["userid"] . ">" . Translate("Event Registrations") . "</A></LI>\n";
}
echo "<LI><A HREF=view_balance.php?index=" . $_SESSION["userid"] . ">" . Translate("Balance History") . "</A></LI>\n";
echo "</UL>\n";
echo "</LI>\n";

// Everyone can view and edit their account, or change their password
echo "<LI>\n";
echo "<B>" . Translate("Account") . ":</B><BR>\n";
echo "<UL>\n";
echo "<LI><A HREF=user_view_settings.php>" . Translate("View Settings") . "</A></LI>\n";
echo "<LI><A HREF=user_edit_settings_init.php>" . Translate("Edit Settings") . "</A></LI>\n";
echo "<LI><A HREF=user_change_pw_init.php>" . Translate("Change Password") . "</A></LI>\n";
echo "<LI><A HREF=logout.php>" . Translate("Logout") . "</A></LI>\n";
echo "</UL>\n";
echo "</LI>\n";

echo "</UL>\n";

include_once "footer.php";
?>

