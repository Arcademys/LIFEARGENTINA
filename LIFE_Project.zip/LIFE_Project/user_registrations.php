<?
include_once "header_system.php";

$userNum = $_GET['index'];

// Get the user name, and determine if they have unlimited (free) registrations
$query = "SELECT a.user_fullname, b.org_unlimited FROM Users AS a LEFT OUTER JOIN Organizations AS b ON (a.user_org = b.org_id) WHERE a.user_id = " . $userNum;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	$pageTitle = Translate("Registrations") . " - " . Translate("Unknown User");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("User data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

$userName = $row[0];
$freeEvents = $row[1]; // This user does not pay for events

// If the page being viewed is for the current user, relax permissions
if ($userNum == $_SESSION["userid"]){
	$pageStatus = 4;
}
else{
	$pageStatus = 2;
}

$pageTitle = Translate("Registrations") . " - " . htmlspecialchars($userName);
include_once "header.php";

// form links back to this page
echo "<FORM NAME=userRegistrationForm METHOD=POST ACTION=user_registrations.php?index=" . $userNum . ">\n";

$tableData = GetTableData("SmallEvents");
$regTableData = GetTableData("Registrations");

// Get list of registered events
// This is for cancelling registrations only, not for display
// This must be done first so that the list of available events is correct
$query = GetSelectQuery($tableData, "SmallEvents") . GetTableList("SmallEvents", $tableData) . " LEFT OUTER JOIN Registrations AS b ON (a.event_id = b.reg_event AND b.reg_user = " . $userNum . " AND b.reg_cancelled = 0) WHERE b.reg_id IS NOT NULL ORDER BY a.event_meeting_time ASC";
$result = ExecuteQuery($query);

$removeActionText = "";
while ($row = mysql_fetch_row($result)){
	$thisIndex = $row[count($row) - 1];
	if ($_POST["removeRegistration"] && $_POST["item" . $thisIndex]){
		// user wishes to cancel reservation...

		// Look up user registration, and verify that the deadline has not passed
		$query = "SELECT a.event_name, b.reg_id, a.event_registration_deadline > CURRENT_TIMESTAMP FROM SmallEvents AS a LEFT OUTER JOIN Registrations AS b ON (a.event_id = b.reg_event AND b.reg_user = " . $userNum . " AND b.reg_cancelled = 0) WHERE b.reg_id IS NOT NULL AND a.event_id = " . $thisIndex;
		$innerResult = ExecuteQuery($query);
		if ($innerRow = mysql_fetch_row($innerResult)){
			// Cancel registration
			$query = "UPDATE Registrations SET reg_cancelled = 1, reg_cancelled_by = " . $_SESSION["userid"] . ", reg_cancellation_time = CURRENT_TIMESTAMP WHERE reg_id = " . $innerRow[1];

			if ($innerRow[2]){
				// not past deadline, so refund registration fee

				if (ExecuteQuery($query)){
					$removeActionText .= "<P ALIGN=CENTER><B>" . Translate("Registration cancelled for") . ":</B> " . $innerRow[0] . "<BR>" . Translate("Event Fee Refunded") . "</P>\n";
				}

				// Get registration fee amount
				$query = "SELECT trans_amount_usd, trans_amount_arg FROM Transactions WHERE trans_user = " . $userNum . " AND trans_type = 1 AND trans_reference = " . $thisIndex;
				$insideResult = ExecuteQuery($query);
				if ($insideRow = mysql_fetch_row($insideResult)){
					$rebateCostUSD = $insideRow[0];
					$rebateCostARG = $insideRow[1];
				}
				else{
					$rebateCostUSD = 0;
					$rebateCostARG = 0;
				}

				// Remove registration fee transaction
				$query = "DELETE FROM Transactions WHERE trans_user = " . $userNum . " AND trans_type = 1 AND trans_reference = " . $thisIndex;
				ExecuteQuery($query);

				// Update balance (subtract fee amount)
				$query = "UPDATE Users SET user_balance_usd = user_balance_usd - " . $rebateCostUSD . ", user_balance_arg = user_balance_arg - " . $rebateCostARG . " WHERE user_id = " . $userNum;
				ExecuteQuery($query);
			}
			else{
				// Deadline passed, so do not refund fee
				if (ExecuteQuery($query)){
					$removeActionText .= "<P ALIGN=CENTER><B>" . Translate("Registration cancelled for") . ":</B> " . $innerRow[0] . "<BR>" . Translate("Event Fee NOT Refunded (deadline passed)") . "</P>\n";
				}
			}
		}
	}
}

// Get list of events that are available for registration
$query = GetSelectQuery($tableData, "SmallEvents") . ", a.event_cost_usd, a.event_cost_arg" . GetTableList("SmallEvents", $tableData) . " LEFT OUTER JOIN Registrations AS b ON (a.event_id = b.reg_event AND b.reg_user = " . $userNum . " AND b.reg_cancelled = 0) WHERE b.reg_id IS NULL AND a.event_registration_deadline > CURRENT_TIMESTAMP AND event_full = 0 ORDER BY a.event_meeting_time ASC";
$result = ExecuteQuery($query);

$noResults = true;
$actionText = "";
echo "<P ALIGN=CENTER><B>" . Translate("Available Events") . ":</B></P>\n";
while ($row = mysql_fetch_row($result)){
	$thisIndex = $row[count($row) - 3];
	$costUSD = $row[count($row) - 2];
	$costARG = $row[count($row) - 1];
	if ($_POST["addRegistration"] && $_POST["item" . $thisIndex]){
		// user wishes to add registration

		// ensure that event is still available for registration
		// Also, check if user has previously created and cancelled a registration for this event
		$query = "SELECT a.event_name, c.reg_id FROM SmallEvents AS a LEFT OUTER JOIN Registrations AS b ON (a.event_id = b.reg_event AND b.reg_user = " . $userNum . " AND b.reg_cancelled = 0) LEFT OUTER JOIN Registrations AS c ON (a.event_id = c.reg_event AND c.reg_user = " . $userNum . " AND c.reg_cancelled = 1) WHERE b.reg_id IS NULL AND a.event_registration_deadline > CURRENT_TIMESTAMP AND event_full = 0 AND a.event_id = " . $thisIndex;
		$innerResult = ExecuteQuery($query);
		if ($innerRow = mysql_fetch_row($innerResult)){
			if ($innerRow[1]){
				// Delete cancelled registration for event, if present
				$query = "DELETE FROM Registrations WHERE reg_id = " . $innerRow[1];
				ExecuteQuery($query);
			}

			// Add a new registration
			$query = "INSERT INTO Registrations(reg_user, reg_event, reg_created_by, reg_free) VALUES (" . $userNum . ", " . $thisIndex . ", " . $_SESSION["userid"] . ", " . $freeEvents . ")";
			if (ExecuteQuery($query)){
				$actionText .= "<P ALIGN=CENTER><B>" . Translate("Registration added for") . ":</B> " . $innerRow[0] . "</P>\n";
			}

			if (!$freeEvents){
				// User pays for events, so add a transaction
				$query = "INSERT INTO Transactions(trans_user, trans_type, trans_reference, trans_amount_usd, trans_amount_arg, trans_created_by) VALUES (" . $userNum . ", 1, " . $thisIndex . ", " . $costUSD . ", " . $costARG . ", " . $_SESSION["userid"] . ")";
				ExecuteQuery($query);

				// Update balance to reflect transaction
				$query = "UPDATE Users SET user_balance_usd = user_balance_usd + " . $costUSD . ", user_balance_arg = user_balance_arg + " . $costARG . " WHERE user_id = " . $userNum;
				ExecuteQuery($query);
			}

		}
	}
	else{
		// Not adding event, so display it
		if ($noResults){
			// header row if first event
			echo "<TABLE BGCOLOR=" . $tableBGColor . " CELLPADDING=5 ALIGN=CENTER>\n";
			echo GetHeaderRow($tableData, true);
			$noResults = false;
		}
		// Display event info
		echo GetFormData($tableData, $row, true, true, "Events", $thisIndex);
	}
}
if (!$noResults){
	echo "</TABLE>\n";
	echo "<P ALIGN=CENTER><INPUT TYPE=SUBMIT NAME=addRegistration VALUE='" . Translate("Register", 1) . "'>" . Translate("Register", 2) . "</P>\n";
}
else{
	echo "<P ALIGN=CENTER>" . Translate("No more events available") . "</P>\n";
}
echo $actionText;


echo "<HR>\n";

// Get list of registered events
$query = GetSelectQuery($tableData, "SmallEvents") . GetTableList("SmallEvents", $tableData) . " LEFT OUTER JOIN Registrations AS b ON (a.event_id = b.reg_event AND b.reg_user = " . $userNum . " AND b.reg_cancelled = 0) WHERE b.reg_id IS NOT NULL ORDER BY a.event_meeting_time ASC";
$result = ExecuteQuery($query);

// display list of registered events, with cancel checkboxes and cancel registration button
$noResults = true;
echo "<P ALIGN=CENTER><B>" . Translate("Registered Events") . ":</B></P>\n";
while ($row = mysql_fetch_row($result)){
	$thisIndex = $row[count($row) - 1];
	if ($noResults){
		// header row if first event
		echo "<TABLE BGCOLOR=" . $tableBGColor . " CELLPADDING=5 ALIGN=CENTER WIDTH=100%>\n";
		echo GetHeaderRow($tableData, true);
		$noResults = false;
	}
	// Display event info
	echo GetFormData($tableData, $row, true, true, "Events", $thisIndex);
}
if (!$noResults){
	echo "</TABLE>\n";
	echo "<P ALIGN=CENTER><INPUT TYPE=SUBMIT NAME=removeRegistration VALUE='" . Translate("Cancel Registration", 1) . "'>" . Translate("Cancel Registration", 2) . "</P>\n";
}
else{
	echo "<P ALIGN=CENTER>" . Translate("No events registered") . "</P>\n";
}
echo $removeActionText;

echo "</FORM>\n";




echo "<HR>\n";

// Get list of attended events
$query = GetSelectQuery($tableData, "SmallEvents") . GetTableList("SmallEventsUnfiltered", $tableData) . " LEFT OUTER JOIN Registrations AS b ON (a.event_id = b.reg_event AND b.reg_user = " . $userNum . " AND b.reg_attended = 1) WHERE b.reg_id IS NOT NULL ORDER BY a.event_meeting_time ASC";
$result = ExecuteQuery($query);

// Display list of attended events
$noResults = true;
echo "<P ALIGN=CENTER><B>" . Translate("Attended Events") . ":</B></P>\n";
while ($row = mysql_fetch_row($result)){
	$thisIndex = $row[count($row) - 1];
	if ($noResults){
		// header row if first event
		echo "<TABLE BGCOLOR=" . $tableBGColor . " CELLPADDING=5 ALIGN=CENTER WIDTH=100%>\n";
		echo GetHeaderRow($tableData);
		$noResults = false;
	}
	// Display event info
	echo GetFormData($tableData, $row, false, true, "Events", $thisIndex);
}
if (!$noResults){
	echo "</TABLE>\n";
}
else{
	echo "<P ALIGN=CENTER>" . Translate("No events attended") . "</P>\n";
}

// Get list of cancelled events
$query = GetSelectQuery($regTableData, "SmallEvents") . GetTableList("SmallEventsUnfiltered", $regTableData) . " LEFT OUTER JOIN Registrations AS b ON (a.event_id = b.reg_event AND b.reg_user = " . $userNum . " AND b.reg_cancelled = 1) LEFT OUTER JOIN Registrations AS c ON (a.event_id = c.reg_event AND c.reg_user = " . $userNum . " AND c.reg_cancelled = 0) WHERE b.reg_id IS NOT NULL AND c.reg_id IS NULL ORDER BY a.event_meeting_time ASC";
$result = ExecuteQuery($query);

// Display list of cancelled events
$noResults = true;
echo "<P ALIGN=CENTER><B>" . Translate("Cancelled Events") . ":</B></P>\n";
while ($row = mysql_fetch_row($result)){
	$thisIndex = $row[count($row) - 1];
	if ($noResults){
		// header row if first event
		echo "<TABLE BGCOLOR=" . $tableBGColor . " CELLPADDING=5 ALIGN=CENTER WIDTH=100%>\n";
		echo GetHeaderRow($regTableData);
		$noResults = false;
	}
	// Display event info
	echo GetFormData($regTableData, $row, false, true, "Events", $thisIndex);
}
if (!$noResults){
	echo "</TABLE>\n";
}
else{
	echo "<P ALIGN=CENTER>" . Translate("No events cancelled") . "</P>\n";
}


include_once "footer.php";
?>

