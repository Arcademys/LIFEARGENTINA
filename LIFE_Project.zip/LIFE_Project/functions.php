<?

// These types define different field classes.
// For example, a user name is type FIELD_TEXT, and an event departure time is type FIELD_DATETIME
define("FIELD_TEXT", 1);
define("FIELD_NUMBER", 2);
define("FIELD_DATETIME", 3);
define("FIELD_CHOICE", 4);
define("FIELD_NATION", 5);
define("FIELD_CURRENCY", 6);
define("FIELD_REFERENCE", 7);
define("FIELD_BOOLEAN", 8);
define("FIELD_DATE", 9);

// These types indicate the various permissions of fields.
define("ALLOW_VIEW", 1); // view only
define("ALLOW_EDIT", 2); // allow change on add or edit
define("ALLOW_ADD", 3); // change on add only (cannot edit)
define("ALLOW_EDIT_ONLY", 4); // editable, but default value when adding an entry


// This function sends an SQL query to the database
function ExecuteQuery($query, $silentFail=false){
	$result = mysql_query($query);
	if (!$result && !$silentFail){
		echo "<P ALIGN=CENTER>SQL Failure:<BR>\n";
		echo "Error: " . mysql_error() . "<BR>\n";
		echo "SQL: " . $query . "</P>\n";
	}
	return $result;
}


// This function escapes all unsafe HTML/Javascript characters from database values
function SafeValue($text){
	return str_replace("'", "&#39;", htmlspecialchars($text));
}


// Reformat mysql date strings in various ways
// $type =
//     0 for default display (date and time)
//     1 for date only (numeric) (intended for javascript function default value)
//     2 for time only (intended for default value of time input
//     3 for date only (for fields which do not include a time)
function DateOutput($dateString, $type = 0){

	if (!$dateString || $dateString == "0000-00-00 00:00:00" || $dateString == "0000-00-00"){
		switch ($type){
		default:
		case 0:
		case 1:
		case 3:
			return "";
			break;
		case 2:
			return "00:00";
			break;
		}
	}
	else{
		switch ($type){
		default:
		case 0:
			return strftime("%a, %b %e %Y, %H:%M", strtotime($dateString));
			break;
		case 1:
			return strftime(", '%Y-%m-%d'", strtotime($dateString));
			break;
		case 2:
			return strftime("%H:%M", strtotime($dateString));
			break;
		case 3:
			return strftime("%a, %b %e %Y", strtotime($dateString));
			break;
		}
	}
}


// This function puts together a select query for the given table and fields
function GetSelectQuery($fields, $tableName){
	$result = "SELECT ";
	$tableCount = 1;
	for ($i = 0; $i < count($fields); $i++){

		// concatenate a value for each field

		if ($i > 0){
			// all but the first, comma separated
			$result .= ", ";
		}

		switch ($fields[$i]["type"]){
		case FIELD_DATETIME:
		case FIELD_DATE:
		case FIELD_TEXT:
		case FIELD_NUMBER:
		case FIELD_NATION:
			// default case just uses the field name
			if ($fields[$i]["queryField"]){
				$result .= $fields[$i]["fieldname"];
			}
			else{
				// if part of a query, need to specify default table
				$result .= "a." . $fields[$i]["fieldname"];
			}
			break;
		case FIELD_BOOLEAN:
			// little bit of SQL logic to make this come out right..
			$result .= "IF(a." . $fields[$i]["fieldname"] . ", 'Yes', 'No')";
			break;
		case FIELD_CHOICE:
			// connect to choice text rather than choice value (uses table join)
			$result .= "a" . $i . ".choice_text";
			$tableCount++;
			break;
		case FIELD_REFERENCE:
			// combine reference index and name, with a | delimiter (both are needed from query) (uses table join)
			$result .= "CONCAT(a." . $fields[$i]["fieldname"] . ", '|', a" . $i . "." . GetName($fields[$i]["reftable"]) . ")";
			$tableCount++;
			break;
		case FIELD_CURRENCY:
			// complex SQL - checks both _usd and _arg values, outputs formatted text (ex: $40.00 USD or $72.34 ARG)
			// Note that a value will be displayed as either USD or ARG, or both if necessary
			$result .= "CONCAT(IF (ROUND(a." . $fields[$i]["fieldname"] . "_usd, 2), CONCAT('\$', FORMAT(ROUND(a." . $fields[$i]["fieldname"] . "_usd, 2), 2), ' USD'), ''), IF (ROUND(a." . $fields[$i]["fieldname"] . "_usd, 2) AND ROUND(a." . $fields[$i]["fieldname"] . "_arg, 2), ' and ', ''), IF (ROUND(a." . $fields[$i]["fieldname"] . "_arg, 2), CONCAT('\$', FORMAT(ROUND(a." . $fields[$i]["fieldname"] . "_arg, 2), 2), ' ARG'), ''))";
			break;
		default:
			$result .= "0";
			break;
		}
	}

	// finally, get the index of the current entry (often useful)
	if (count($fields > 0)){
		$result .= ", ";
	}
	$result .= "a." . GetIndex($tableName);

	return $result;
}

// Returns a SQL formatted list of the tables required (using LEFT OUTER JOINs) in order to perform a query
// for the requested table and fields.
function GetTableList($tableName, $fields){

	// Main table is always aliased "a"
	$result = " FROM " . $tableName . " AS a";
	$tableCount = 1;

	for ($i = 0; $i < count($fields); $i++){
		// depending on fields (choices and references), other tables may need to be joined in
		// extra tables are aliased "aX" where X is the index number of the field in the $fields array
		switch ($fields[$i]["type"]){
		case FIELD_CHOICE:
			$result .= " LEFT OUTER JOIN Choices AS a" . $i . " ON (a." . $fields[$i]["fieldname"] . " = a" . $i . ".choice_value AND a" . $i . ".choice_field = '" . $fields[$i]["fieldname"] . "')";
			$tableCount++;
			break;
		case FIELD_REFERENCE:
			$result .= " LEFT OUTER JOIN " . $fields[$i]["reftable"] . " AS a" . $i . " ON (a." . $fields[$i]["fieldname"] . " = a" . $i . "." . GetIndex($fields[$i]["reftable"]) . ")";
			$tableCount++;
			break;
		case FIELD_DATETIME:
		case FIELD_DATE:
		case FIELD_TEXT:
		case FIELD_NUMBER:
		case FIELD_CURRENCY:
		case FIELD_NATION:
		case FIELD_BOOLEAN:
		default:
			break;
		}
	}
	return $result;

}


// This function constructs an UPDATE SQL query for the desired table and fields (without WHERE clause)
function GetUpdateQuery($fields, $tableName){

	$result = "UPDATE " . $tableName . " SET ";
	$first = true;
	for ($i = 0; $i < count($fields); $i++){
		if ($fields[$i]["permissions"] == ALLOW_EDIT || $fields[$i]["permissions"] == ALLOW_EDIT_ONLY){
			// Found an editable field, add update assignment

			// all but first are comma separated
			if ($first){
				$first = false;
			}
			else{
				$result .= ", ";
			}

			switch ($fields[$i]["type"]){
			case FIELD_TEXT:
			case FIELD_NATION:
				// set POST value directly
				$result .= $fields[$i]["fieldname"] . " = '" . $_POST[$fields[$i]["fieldname"]] . "'";
				break;
			case FIELD_DATE:
				// set POST value formatted in DB date format
				$result .= $fields[$i]["fieldname"] . " = '" . strftime("%Y-%m-%d", strtotime($_POST[$fields[$i]["fieldname"]])) . "'";
				break;
			case FIELD_DATETIME:
				// set POST value formatted in DB timestamp format
				$result .= $fields[$i]["fieldname"] . " = '" . strftime("%Y-%m-%d %T", strtotime($_POST[$fields[$i]["fieldname"] . "_day"] . " " . $_POST[$fields[$i]["fieldname"] . "_time"])) . "'";
				break;
			case FIELD_CHOICE:
			case FIELD_NUMBER:
			case FIELD_REFERENCE:
			case FIELD_BOOLEAN:
				// set POST value directly, if it is specified (else 0)
				if ($_POST[$fields[$i]["fieldname"]]){
					$result .= $fields[$i]["fieldname"] . " = " . $_POST[$fields[$i]["fieldname"]];
				}
				else{
					$result .= $fields[$i]["fieldname"] . " = 0";
				}
				break;
			case FIELD_CURRENCY:
				// Most complex update...

				// filter out non-numeric characters from text string...
				$number = ereg_replace("[^-1234567890.]", "", $_POST[$fields[$i]["fieldname"] . "_num"]);
				if (!$number){
					$number = 0;
				}

				// get text from currency string
				$currency = $_POST[$fields[$i]["fieldname"] . "_cur"];

				// depending on currency string, set either _usd or _arg, and clear the other value to 0
				// (does not allow entry of both at once - entered values must be either all USD or all ARG)
				if ($currency == "USD"){
					$result .= $fields[$i]["fieldname"] . "_usd = " . $number . ", " . $fields[$i]["fieldname"] . "_arg = 0";
				}
				else{
					$result .= $fields[$i]["fieldname"] . "_arg = " . $number . ", " . $fields[$i]["fieldname"] . "_usd = 0";
				}
				break;
			default:
				break;
			}
		}
	}
	return $result;
}

// This function constructs an INSERT SQL query for the desired table and fields
function GetInsertQuery($fields, $tableName, $extraFields = "", $extraValues = ""){

	// This function constructs the fields and values portions of the query in parallel

	// start with "extra" fields...
	$fieldsResult = $extraFields;
	$valuesResult = $extraValues;

	// if both are empty, then this indicates that we still have an empty string
	if (strlen($extraFields) > 0 || strlen($extraValues) > 0){
		$first = false;
	}
	else{
		$first = true;
	}

	for ($i = 0; $i < count($fields); $i++){
		if ($fields[$i]["permissions"] == ALLOW_EDIT || $fields[$i]["permissions"] == ALLOW_ADD){
			// found an field with edit or add permissions...

			// both sides are comma separated, after the first entry
			if ($first){
				$first = false;
			}
			else{
				$fieldsResult .= ", ";
				$valuesResult .= ", ";
			}


			switch ($fields[$i]["type"]){
			case FIELD_TEXT:
			case FIELD_NATION:
				// Default entry, just put in POST value
				$fieldsResult .= $fields[$i]["fieldname"];
				$valuesResult .= "'" . $_POST[$fields[$i]["fieldname"]] . "'";
				break;
			case FIELD_DATE:
				// Put in POST value formatted for DB date format
				$fieldsResult .= $fields[$i]["fieldname"];
				$valuesResult .= "'" . strftime("%Y-%m-%d", strtotime($_POST[$fields[$i]["fieldname"]])) . "'";
				break;
			case FIELD_DATETIME:
				// Put in POST value formatted for DB timestamp format
				$fieldsResult .= $fields[$i]["fieldname"];
				$valuesResult .= "'" . strftime("%Y-%m-%d %T", strtotime($_POST[$fields[$i]["fieldname"] . "_day"] . " " . $_POST[$fields[$i]["fieldname"] . "_time"])) . "'";
				break;
			case FIELD_CHOICE:
			case FIELD_NUMBER:
			case FIELD_REFERENCE:
			case FIELD_BOOLEAN:
				// set POST value directly, if it is specified (else 0)
				$fieldsResult .= $fields[$i]["fieldname"];
				if ($_POST[$fields[$i]["fieldname"]]){
					$valuesResult .= $_POST[$fields[$i]["fieldname"]];
				}
				else{
					$valuesResult .= "0";
				}
				break;
			case FIELD_CURRENCY:
				// Most complex insert...

				// insert both _usd and _arg values...
				$fieldsResult .= $fields[$i]["fieldname"] . "_usd, " . $fields[$i]["fieldname"] . "_arg";

				// filter out non-numeric characters from text string...
				$number = ereg_replace("[^-1234567890.]", "", $_POST[$fields[$i]["fieldname"] . "_num"]);
				if (!$number){
					$number = "0";
				}

				// get text from currency string
				$currency = $_POST[$fields[$i]["fieldname"] . "_cur"];

				// depending on currency string, set either _usd or _arg, and clear the other value to 0
				// (does not allow entry of both at once - entered values must be either all USD or all ARG)
				if ($currency == "USD"){
					$valuesResult .= $number . ", 0";
				}
				else{
					$valuesResult .= "0, " . $number;
				}
				break;
			default:
				break;
			}
		}
		else if (strpos($fields[$i]["fieldname"], "created_by")){
			// automatically set "created_by" value (to current user ID)

			if ($first){
				$first = false;
			}
			else{
				$fieldsResult .= ", ";
				$valuesResult .= ", ";
			}
			$fieldsResult .= $fields[$i]["fieldname"];
			$valuesResult .= $_SESSION['userid'];
		}
	}

	// combine parallel strings into INSERT query
	$result = "INSERT INTO " . $tableName . "(" . $fieldsResult . ") VALUES (" . $valuesResult . ")";
	return $result;
}


// This rather complex function generates a set of SQL WHERE conditions for a particular table
// based on the array of criteria specified in $searchData
function GetWhereConditions($tableData, $searchData, $numCriteria){
	$result = "";

	if ($numCriteria > 0){
		// only put a WHERE if there is at least one condition!
		$result .= " WHERE ";
		for ($i = 0; $i < $numCriteria; $i++){
			$thisField = $searchData[$i]["field"];  // Get field index from input array
			$thisType = $tableData[$thisField]["type"];  // Get field type from index
			if ($i > 0){
				$result .= " AND "; // all conditions are combined with AND
			}

			// Look up the format for including the condition...
			// The options vary by type, and the search "function" determines which operator to use

			// NOTE: choice "function" meanings must match index meanings specified in
			//       GetFunctionText in common_functions.js


			switch ($thisType){
			case FIELD_CHOICE:
				// Choice uses table alias "aX" where X is field index
				$result .= "a" . $thisField . ".choice_text";
				switch($searchData[$i]["function"]){
				case 1:
					$result .= " LIKE '%" . $searchData[$i]["value"] . "%'";
					break;
				case 2:
					$result .= " LIKE '" . $searchData[$i]["value"] . "'";
					break;
				default:
					return null;
					break;
				}
				break;
			case FIELD_REFERENCE:
				// Reference uses table alias "aX" where X is field index
				// Search looks for the name of the reference item, not the index value directly
				$result .= "a" . $thisField . "." . GetName($tableData[$thisField]["reftable"]);
				switch($searchData[$i]["function"]){
				case 1:
					$result .= " LIKE '%" . $searchData[$i]["value"] . "%'";
					break;
				case 2:
					$result .= " LIKE '" . $searchData[$i]["value"] . "'";
					break;
				default:
					return null;
					break;
				}
				break;
			case FIELD_TEXT:
			case FIELD_NATION:
				// basic case, allows a text contains or equals
				$result .= "a." . $tableData[$thisField]["fieldname"];
				switch($searchData[$i]["function"]){
				case 1:
					$result .= " LIKE '%" . $searchData[$i]["value"] . "%'";
					break;
				case 2:
					$result .= " LIKE '" . $searchData[$i]["value"] . "'";
					break;
				default:
					return null;
					break;
				}
				break;
			case FIELD_BOOLEAN:
				$result .= "a." . $tableData[$thisField]["fieldname"];

				// Convert various versions of "true" to 1, else search for 0
				$reqValue = strtoupper($searchData[$i]["value"]);
				if ($reqValue == "Y" || $reqValue == "YES" || $reqValue == "T" || $reqValue == "TRUE" || $reqValue == "1"){
					$reqValue = "1";
				}
				else{
					$reqValue = "0";
				}
				switch($searchData[$i]["function"]){
				case 1:
					$result .= " = " . $reqValue;
					break;
				default:
					return null;
					break;
				}
				break;
			case FIELD_NUMBER:
				// Basic condition, allows =, >, or <
				$result .= "a." . $tableData[$thisField]["fieldname"];
				switch($searchData[$i]["function"]){
				case 1:
					$result .= " = " . $searchData[$i]["value"];
					break;
				case 2:
					$result .= " > " . $searchData[$i]["value"];
					break;
				case 3:
					$result .= " < " . $searchData[$i]["value"];
					break;
				default:
					return null;
					break;
				}
				break;
			case FIELD_CURRENCY:
				// complex situation...

				// in general, check that either _usd or _arg equals text input
				switch($searchData[$i]["function"]){
				case 1:
					// check if either _usd or _arg is matching, if value is more than zero,
					// else check if _usd and _arg are both 0, if value is zero
					$result .= "(" . $searchData[$i]["value"] . " > 0 AND (ROUND(a." . $tableData[$thisField]["fieldname"] . "_usd, 2)";
					$result .= " = ROUND(" . $searchData[$i]["value"] . ", 2)";
					$result .= " OR ROUND(a." . $tableData[$thisField]["fieldname"] . "_arg, 2)";
					$result .= " = ROUND(" . $searchData[$i]["value"] . ", 2))";
					$result .= " OR (" . $searchData[$i]["value"] . " = 0 AND a." . $tableData[$thisField]["fieldname"] . "_usd = 0 AND a." . $tableData[$thisField]["fieldname"] . "_arg = 0))";
					break;
				case 2:
					// check if either _usd or _arg are greater than value
					$result .= "(a." . $tableData[$thisField]["fieldname"] . "_usd";
					$result .= " > " . $searchData[$i]["value"];
					$result .= " OR a." . $tableData[$thisField]["fieldname"] . "_arg";
					$result .= " > " . $searchData[$i]["value"] . ")";
					break;
				case 3:
					// check if either _usd or _arg are less than value, but non-zero,
					// or both are zero (indicating 0 as the value in the database)
					$result .= "((a." . $tableData[$thisField]["fieldname"] . "_usd";
					$result .= " < " . $searchData[$i]["value"] . " AND a." . $tableData[$thisField]["fieldname"] . "_usd > 0)";
					$result .= " OR (a." . $tableData[$thisField]["fieldname"] . "_arg";
					$result .= " < " . $searchData[$i]["value"] . " AND a." . $tableData[$thisField]["fieldname"] . "_arg > 0)";
					$result .= " OR (a." . $tableData[$thisField]["fieldname"] . "_usd = 0";
					$result .= " AND a." . $tableData[$thisField]["fieldname"] . "_arg = 0))";
					break;
				default:
					return null;
					break;
				}
				break;
			case FIELD_DATE:
				// basic =, >, < check, with DB date format
				$result .= "a." . $tableData[$thisField]["fieldname"];
				switch($searchData[$i]["function"]){
				case 1:
					$result .= " = '" . strftime("%Y-%m-%d", strtotime($searchData[$i]["value"])) . "'";
					break;
				case 2:
					$result .= " > '" . strftime("%Y-%m-%d", strtotime($searchData[$i]["value"])) . "'";
					break;
				case 3:
					$result .= " < '" . strftime("%Y-%m-%d", strtotime($searchData[$i]["value"])) . "'";
					break;
				default:
					return null;
					break;
				}
				break;
			case FIELD_DATETIME:
				// basic >, < check, with DB timestamp format
				$result .= "a." . $tableData[$thisField]["fieldname"];
				switch($searchData[$i]["function"]){
				case 1:
					$result .= " > '" . strftime("%Y-%m-%d %T", strtotime($searchData[$i]["value"])) . "'";
					break;
				case 2:
					$result .= " < '" . strftime("%Y-%m-%d %T", strtotime($searchData[$i]["value"])) . "'";
					break;
				default:
					return null;
					break;
				}
				break;
			default:

				break;
			}
		}
	}
	return $result;

}


// This function creates a search query for a table from a given set of criteria
function MakeSearchQuery($tableData, $tableName, $searchData, $numCriteria){
	return GetSelectQuery($tableData, $tableName) . GetTableList($tableName, $tableData) . GetWhereConditions($tableData, $searchData, $numCriteria);
}


// Huge function, which does most of the display work for data.
// Returns a string which represents the data, or the form, depending on parameters
// Input parameters:
//
// $fields - table data from GetTableData
// $defaults - initial values for a form, field data for a view
// $editing - True for edit/add forms
// $horizontal - Show the entry in a single horizontal row, rather than a full vertical table
// $tableName - Only valid for non-editing horizontal entries, allows a link to the item detail to be made
// $index - For horizontal or autofill tables - This is the index of the item being viewed (required for reference to DB entry)
// $cancelled - For horizontal tables, show strikethrough and removes edit box
// $adding - This parameter is set to true for "add" forms.  Must be used with $editing
// $removeButtons - For horizontal tables, shows remove buttons for table rows
//
function GetFormData($fields, $defaults, $editing = false, $horizontal = false, $tableName = "NULL", $index = -1, $cancelled = false, $adding = false, $removeButtons = false){
	$result = "";
	$focusText = " ID=focus";
	for ($i = 0; $i < count($fields); $i++){

		// This changes all fields to view only when we are not editing the record
		if (!$editing){
			$fields[$i]["permissions"] = ALLOW_VIEW;
		}

		// This changes all ALLOW_ADD fields to editable when we are adding a new record
		if ($adding && $fields[$i]["permissions"] == ALLOW_ADD){
			$fields[$i]["permissions"] = ALLOW_EDIT;
		}

		// This changes all ALLOW_EDIT_ONLY fields to editable when we are not adding a new record
		if (!$adding && $fields[$i]["permissions"] == ALLOW_EDIT_ONLY){
			$fields[$i]["permissions"] = ALLOW_EDIT;
		}

		// The !$adding condition means that on add forms ALLOW_VIEW fields won't be displayed
		if (!$adding || $fields[$i]["permissions"] == ALLOW_EDIT){

			if (!$horizontal){
				// Vertical display puts out a new row, with a heading cell in bold
				$result .= "<TR><TD ALIGN=RIGHT><B>" . Translate($fields[$i]["name"]) . ":</B></TD><TD>\n";
			}
			else{

				// The $horizontal parameter allows a horizontal table, which does not require a
				// new row, or a heading to describe the data.

				if ($i > 0){
					// start new cell
					if ($fields[$i]["fieldname"] == "note_note"){
						// Exception for notes (allow wrapping)
						$result .= "<TD ALIGN=LEFT>\n";
					}
					else{
						$result .= "<TD ALIGN=CENTER NOWRAP>\n";
					}
				}
				else{
					if (!$editing){
						// If viewing a horizontal entry, make the first entry into a link to the full record
						$result .= "<TD ALIGN=LEFT NOWRAP>\n";
						$result .= "<A HREF=view_item.php?table=" . $tableName . "&index=" . $index . ">";
					}
					else{
						// If editing a horizontal entry, allow a checkbox for the item if it is not cancelled
						$result .= "<TD ALIGN=CENTER NOWRAP>\n";
						if (!$cancelled){
							$result .= "<INPUT TYPE=CHECKBOX NAME=item" . $index . " VALUE='SET'>\n";
						}
						$result .= "</TD>\n";
						$result .= "<TD ALIGN=LEFT NOWRAP>\n";
					}
				}
				if ($cancelled){
					// Strikethrough tag for cancelled entries
					$result .= "<S>";
				}
			}

			switch ($fields[$i]["permissions"]){
			case ALLOW_EDIT:
				// These options control the display of add/edit dialogs for all field types
				switch ($fields[$i]["type"]){
				case FIELD_CHOICE:
					// look up choices, and display as an HTML select
					$result .= "<SELECT NAME=" . $fields[$i]["fieldname"] . ">\n";
					$query = "SELECT choice_text, choice_value FROM Choices WHERE choice_field='" . $fields[$i]["fieldname"] . "' ORDER BY choice_value ASC";
					$queryResult = ExecuteQuery($query);
					while ($row = mysql_fetch_row($queryResult)){
						$result .= "<OPTION VALUE=" . $row[1];
						if ($row[0] == $defaults[$i]){
							$result .= " SELECTED";
						}
						$result .= ">" . Translate($row[0], 1) . "</OPTION>\n";
					}
					$result .= "</SELECT>\n";
					break;
				case FIELD_REFERENCE:
					// Look up reference options

					// break value into index/name pair (separated by |)
					$refIndex = substr($defaults[$i], 0, strpos($defaults[$i], "|"));
					$result .= "<SELECT NAME=" . $fields[$i]["fieldname"] . ">\n";
					$query = "SELECT " . GetName($fields[$i]["reftable"]) . ", " . GetIndex($fields[$i]["reftable"]) . " FROM " . $fields[$i]["reftable"] . $fields[$i]["refconditions"] . " ORDER BY " . GetName($fields[$i]["reftable"]) . " ASC";
					$queryResult = ExecuteQuery($query);
					while ($row = mysql_fetch_row($queryResult)){
						$result .= "<OPTION VALUE=" . $row[1];
						if ($row[1] == $refIndex){
							$result .= " SELECTED";
						}
						$result .= ">" . $row[0] . "</OPTION>\n";
					}
					$result .= "</SELECT>\n";
					break;
				case FIELD_BOOLEAN:
					// Show yes and no radio buttons
					$result .= "<INPUT TYPE=RADIO NAME=" . $fields[$i]["fieldname"] . " VALUE=1";
					if ($defaults[$i] == "Yes"){
						$result .= " CHECKED";
					}
					$result .= ">" . Translate("Yes") . "\n";
					$result .= "<INPUT TYPE=RADIO NAME=" . $fields[$i]["fieldname"] . " VALUE=0";
					if ($defaults[$i] != "Yes"){
						$result .= " CHECKED";
					}
					$result .= ">" . Translate("No") . "\n";
					break;
				case FIELD_DATE:
					// use included javascript function (see calendarDateInput.js)
					$result .= "<SCRIPT>DateInput('" . $fields[$i]["fieldname"] . "', true, 'YYYY-MM-DD'" . DateOutput($defaults[$i], 1) . ")</SCRIPT>\n";
					break;
				case FIELD_DATETIME:
					// use included javascript function (see calendarDateInput.js)
					$result .= "<TABLE><TR><TD><SCRIPT>DateInput('" . $fields[$i]["fieldname"] . "_day', true, 'YYYY-MM-DD'" . DateOutput($defaults[$i], 1) . ")</SCRIPT></TD>\n";
					$result .= "<TD><INPUT TYPE=TEXT SIZE=5 NAME=" . $fields[$i]["fieldname"] . "_time" . $focusText . " VALUE='" . DateOutput($defaults[$i], 2) . "'></TD></TR></TABLE>\n";
					$focusText = "";
					break;
				case FIELD_TEXT:
				case FIELD_NUMBER:
					$autocomplete = false;
					if ($fields[$i]["fieldname"] == "event_name"){
						// special case allows autocomplete drop-down values (event_name only)
						$result .= "(Autofill <INPUT TYPE=CHECKBOX NAME=autocomplete ID=autocomplete VALUE=YES onClick=\"var field = document.getElementsByName('event_name')[0]; if (this.checked){field.value = ''; field.disabled = true} else {field.disabled = false}; return true;\"";
						if ($defaults[$i] == "" || $defaults[$i] == GetEventNameAutoFillValue($index)){
							$autocomplete = true;
							$result .= " CHECKED";
						}
						$result .= ">)\n";
					}
					// Text box for both numbers or text inputs
					$result .= "<INPUT TYPE=TEXT NAME=" . $fields[$i]["fieldname"] . " VALUE='";
					if ($autocomplete){
						$result .= "' DISABLED";
					}
					else{
						$result .= SafeValue($defaults[$i]) . "'" . $focusText;
						$focusText = "";
					}
					// Check required fields (see common_functions.js)
					$result .= " onKeyPress='return EnterRequired(event);'>\n";
					if ($fields[$i]["required"]){
						$result .= "*\n";
					}
					break;
				case FIELD_CURRENCY:
					$value = $defaults[$i];
					if (strpos($value, " ")){
						// extract the numeric part of currency default
						$number = substr($value, 0, strpos($value, " "));
					}
					else{
						$number = $value;
					}

					// determine currency part of default
					if (strpos($value, "USD")){
						$usd = true;
						$curText = "USD";
					}
					else{
						$usd = false;
						$curText = "ARG";
					}

					// The final value is determined by the values of [fieldname]_num and [fieldname]_cur
					$result .= "<INPUT TYPE=TEXT NAME=" . $fields[$i]["fieldname"] . "_num" . $focusText . " VALUE='" . SafeValue($number) . "'>";
					$result .= "<SELECT NAME=" . $fields[$i]["fieldname"] . "_cur>";
					$result .= "<OPTION VALUE='USD'";
					if ($usd){
						$result .= " SELECTED";
					}
					$result .= ">USD</OPTION>";
					$result .= "<OPTION VALUE='ARG'";
					if (!$usd){
						$result .= " SELECTED";
					}
					$result .= ">ARG</OPTION>";
					$result .= "</SELECT>\n";
					$focusText = "";
					break;
				case FIELD_NATION:
					// Special field type that allows user to select from a long list of countries
					$result .= "<SELECT NAME=" . $fields[$i]["fieldname"] . " ID=selectNationality" . $i . ">\n";
					include "country_list.php"; // get a list of options
					$result .= $countryList;
					$result .= "</SELECT>\n";
					$result .= "<SCRIPT>\n";
					$result .= "SetSelectDefault('selectNationality" . $i . "', '" . SafeValue($defaults[$i]) . "');";
					$result .= "</SCRIPT>\n";
					break;
				default:
					break;
				}
				break;
			case ALLOW_ADD:
			case ALLOW_VIEW:
				// These options control the display of all field types without editing
				switch ($fields[$i]["type"]){
				case FIELD_DATE:
					$result .= DateOutput($defaults[$i], 3);
					break;
				case FIELD_DATETIME:
					$result .= DateOutput($defaults[$i]);
					break;
				case FIELD_NATION:
				case FIELD_TEXT:
				case FIELD_NUMBER:
				case FIELD_CURRENCY:
					if ($fields[$i]["allowNewline"]){
						$result .= ereg_replace("\n", "<BR>", htmlspecialchars($defaults[$i]));
					}
					else{
						$result .= htmlspecialchars($defaults[$i]);
					}
					break;
				case FIELD_CHOICE:
				case FIELD_BOOLEAN:
					$result .= Translate(htmlspecialchars($defaults[$i]));
					break;
				case FIELD_REFERENCE:
					$refIndex = substr($defaults[$i], 0, strpos($defaults[$i], "|"));
					$refText = substr($defaults[$i], strpos($defaults[$i], "|") + 1);
					if ($_SESSION['userstatus'] <= 2){
						$result .= "<A HREF=view_item?table=" . $fields[$i]["reftable"] . "&index=" . $refIndex . ">";
					}
					$result .= htmlspecialchars($refText);
					if ($_SESSION['userstatus'] <= 2){
						$result .= "</A>";
					}
					break;
				default:
					break;
				}
				break;
			default:
				break;
			}

			// Finish off table entry
			if (!$horizontal){
				$result .= "</TD></TR>\n";
			}
			else{
				if ($i == 0 && !$editing){
					$result .= "</A>";
				}
				if ($cancelled){
					$result .= "</S>";
				}
				$result .= "</TD>\n";
			}
		}
	}

	if ($horizontal && $removeButtons){
		// This allows remove buttons to be displayed for horizantal tables (sub-tables)
		$result .= "<TD><INPUT TYPE=SUBMIT NAME=remove VALUE='" . Translate("Remove", 1) . "' onClick='document.getElementById(\"action\").value=\"" . $index . "\"; document.noteForm.submit();'>" . Translate("Remove", 2) . "</TD>\n";
	}

	if ($horizontal){
		// Format result within a table row
		global $tableCellColor;
		return "<TR BGCOLOR=" . $tableCellColor . ">\n" . $result . "</TR>\n";
	}
	else{
		return $result;
	}
}

// This function returns a table row full of header values (for sub-table display)
function GetHeaderRow($fields, $editing = false, $extraField = ""){
	$result = "";
	if ($editing){
		// Editable sub-tables always include an extra field (for checkboxes)
		$result .= "<TD ALIGN=CENTER><B>" . $extraField . "</B></TD>\n";
	}
	for ($i = 0; $i < count($fields); $i++){
		$result .= "<TD ALIGN=CENTER NOWRAP><B>" . Translate($fields[$i]["name"]) . "</B></TD>";
	}
	global $tableHeadingColor;
	return "<TR BGCOLOR=" . $tableHeadingColor . ">\n" . $result . "</TR>\n";
}


// Returns javascript code to check the required fields of a form input
function GetRequiredCode($fields, $formName, $adding = true){
	$result = "";
	for ($i = 0; $i < count($fields); $i++){
		if ($fields[$i]["required"] && ($fields[$i]["permissions"] == ALLOW_EDIT || ($adding && $fields[$i]["permissions"] == ALLOW_ADD))){
			$result .= "if (document." . $formName . "." . $fields[$i]["fieldname"] . ".value == \"\"){alert(\"Must enter value for " . $fields[$i]["name"] . "\"); document." . $formName . "." . $fields[$i]["fieldname"] . ".focus(); return false;} ";
		}
	}
	return $result;
}


// Returns an array of table data fields
// The array has the following indicies:
//
// name - Name of the field for display
// fieldname - Database field name
// type - Encoded field type (see FIELD_* defines)
// permissions - Encoded permissions for field access (see ALLOW_* defines)
// reftable (FIELD_REFERENCE only) - The name of the table in which to look up the reference
// required (optional, FIELD_TEXT and FIELD_NUMBER only) - true for fields which cannot be left empty
// access (optional) - Internal indicator which will remove fields if the user does not have sufficient permissions
// allowNewline (optional, FIELD_TEXT only) - Indicates that a text field may contain a newline character
// queryField (optional) - Indicates that the fieldname is actually a subquery, or a referenced table
// refconditions (optional, FIELD_REFERENCE only) - Extra WHERE conditions to apply to reference lookups (for selecting drop-down lists)
//
function GetTableData($tableName){
	switch ($tableName){
	case "Users":
		$fields = array(
			array("name" => "Full Name",				"fieldname" => "user_fullname",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT,	"required" => true		),
			array("name" => "Username",				"fieldname" => "user_name",			"type" => FIELD_TEXT,		"permissions" => ALLOW_ADD,	"required" => true		),
			array("name" => "Gender",				"fieldname" => "user_gender",			"type" => FIELD_CHOICE,		"permissions" => ALLOW_EDIT					),
			array("name" => "Arrival Date",			"fieldname" => "user_arrival_date",		"type" => FIELD_DATE,		"permissions" => ALLOW_EDIT					),
			array("name" => "Departure Date",			"fieldname" => "user_departure_date",		"type" => FIELD_DATE,		"permissions" => ALLOW_EDIT					),
			array("name" => "Nationality",				"fieldname" => "user_nationality",		"type" => FIELD_NATION,		"permissions" => ALLOW_EDIT					),
			array("name" => "Region",				"fieldname" => "user_region",			"type" => FIELD_CHOICE,		"permissions" => ALLOW_EDIT					),
			array("name" => "Language",				"fieldname" => "user_lang",			"type" => FIELD_CHOICE,		"permissions" => ALLOW_EDIT					),
			array("name" => "Passport Number",		"fieldname" => "user_passport",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT,	"required" => true		),
			array("name" => "Email Address",			"fieldname" => "user_email",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT,	"required" => true		),
			array("name" => "Email Valid",			"fieldname" => "user_email_valid",		"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT_ONLY,	"access" => 2		),
			array("name" => "Date of Birth",			"fieldname" => "user_date_of_birth",		"type" => FIELD_DATE,		"permissions" => ALLOW_EDIT					),
			array("name" => "Marital Status",			"fieldname" => "user_marital_status",		"type" => FIELD_CHOICE,		"permissions" => ALLOW_EDIT					),
			array("name" => "Religion",				"fieldname" => "user_religion",			"type" => FIELD_CHOICE,		"permissions" => ALLOW_EDIT					),
			array("name" => "Spanish Level",			"fieldname" => "user_spanish_level",		"type" => FIELD_CHOICE,		"permissions" => ALLOW_EDIT					),
			array("name" => "Purpose of Visit",			"fieldname" => "user_purpose_of_visit",		"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Referred by",			"fieldname" => "user_reference",		"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Local Address",			"fieldname" => "user_local_address",		"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Local Phone",			"fieldname" => "user_local_phone",		"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Local Phone (Cell)",		"fieldname" => "user_local_phone_cell",		"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Home Address",			"fieldname" => "user_home_address",		"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Home Phone",			"fieldname" => "user_home_phone",		"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Home Phone (Cell)",		"fieldname" => "user_home_phone_cell",		"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Education Level",			"fieldname" => "user_education_level",		"type" => FIELD_CHOICE,		"permissions" => ALLOW_EDIT					),
			array("name" => "Educational Institution",	"fieldname" => "user_education_institution",	"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Diseases",				"fieldname" => "user_health_diseases",		"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Allergies",				"fieldname" => "user_health_allergies",		"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Medication",			"fieldname" => "user_health_medication",	"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Dietary Requirements",	"fieldname" => "user_health_dietary_req",	"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Medical Coverage",		"fieldname" => "user_health_medical_coverage",	"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Emergency Contact Name",		"fieldname" => "user_emergency_contact_name",	"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT,	"required" => true		),
			array("name" => "Emergency Contact Phone",		"fieldname" => "user_emergency_contact_phone",	"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT,	"required" => true		),
			array("name" => "Can Help With Recreation",	"fieldname" => "user_vol_area_recreation",	"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT					),
			array("name" => "Can Help With Sports",	"fieldname" => "user_vol_area_sports",		"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT					),
			array("name" => "Can Help With Teaching/Literacy",	"fieldname" => "user_vol_area_teaching",	"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT					),
			array("name" => "Can Help With Language Lessons",	"fieldname" => "user_vol_area_language",	"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT					),
			array("name" => "Can Help With Hospital Visits",	"fieldname" => "user_vol_area_hospital",	"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT					),
			array("name" => "Can Help With Art",		"fieldname" => "user_vol_area_art",		"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT					),
			array("name" => "Can Help With Fundraising",	"fieldname" => "user_vol_area_fundraising",	"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT					),
			array("name" => "Can Help With Translation",		"fieldname" => "user_vol_area_translation",	"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT					),
			array("name" => "Can Help With Administration",	"fieldname" => "user_vol_area_admin",		"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT					),
			array("name" => "Can Help With Management",	"fieldname" => "user_vol_area_management",	"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT					),
			array("name" => "Can Help With Research and Dev.",	"fieldname" => "user_vol_area_research",	"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT					),
			array("name" => "Can Help With Other",		"fieldname" => "user_vol_area_other",		"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Volunteer Status",		"fieldname" => "user_status",			"type" => FIELD_CHOICE,		"permissions" => ALLOW_VIEW					),
			array("name" => "Date Created",			"fieldname" => "user_date_created",		"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					),
			array("name" => "Last Login",				"fieldname" => "user_last_login",		"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					),
			array("name" => "Outstanding Balance",	"fieldname" => "user_balance",			"type" => FIELD_CURRENCY,	"permissions" => ALLOW_VIEW					),
			array("name" => "Organization",			"fieldname" => "user_org",			"type" => FIELD_REFERENCE,	"permissions" => ALLOW_EDIT_ONLY,	"access" => 2,	"reftable" => "Organizations"	),
			array("name" => "Fundraising Potential",	"fieldname" => "user_fund_potential",		"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT_ONLY,	"access" => 2		),
			array("name" => "Translation Potential",		"fieldname" => "user_trans_potential",		"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT_ONLY,	"access" => 2		)
		);
		break;
	case "Contacts":
		$fields = array(
			array("name" => "Name",				"fieldname" => "contact_name",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Language",				"fieldname" => "contact_lang",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Nationality",				"fieldname" => "contact_nationality",		"type" => FIELD_NATION,		"permissions" => ALLOW_EDIT					),
			array("name" => "Email Address",			"fieldname" => "contact_email",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Email Valid",			"fieldname" => "contact_email_valid",		"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT					),
			array("name" => "Active",			"fieldname" => "contact_active",		"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT					)
		);
		break;
	case "SmallUsers":
		$fields = array(
			array("name" => "Full Name",				"fieldname" => "user_fullname",			"type" => FIELD_TEXT,		"permissions" => ALLOW_VIEW					),
			array("name" => "Status",				"fieldname" => "user_status",			"type" => FIELD_CHOICE,		"permissions" => ALLOW_VIEW					)
		);
		break;
	case "UserNotes":
		$fields = array(
			array("name" => "ID",					"fieldname" => "note_id",			"type" => FIELD_NUMBER,		"permissions" => ALLOW_VIEW					),
			array("name" => "Message",				"fieldname" => "note_note",			"type" => FIELD_TEXT,		"permissions" => ALLOW_VIEW,	"allowNewline" => true		),
			array("name" => "Created By",			"fieldname" => "note_created_by",		"type" => FIELD_REFERENCE,	"permissions" => ALLOW_VIEW,	"reftable" => "Users"		),
			array("name" => "Date Created",			"fieldname" => "note_date_created",		"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					),
			array("name" => "Private",				"fieldname" => "note_private",			"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_VIEW					)
		);
		break;
	case "Locations":
		$fields = array(
			array("name" => "Name",				"fieldname" => "loc_name",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Description",			"fieldname" => "loc_desc",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Cost",					"fieldname" => "loc_cost",			"type" => FIELD_CURRENCY,	"permissions" => ALLOW_EDIT					)
		);
		break;
	case "Organizations":
		$fields = array(
			array("name" => "Name",				"fieldname" => "org_name",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Notes",				"fieldname" => "org_notes",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Unlimited Registrations",	"fieldname" => "org_unlimited",			"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_EDIT					)
		);
		break;
	case "Events":
		$fields = array(
			array("name" => "Name",				"fieldname" => "event_name",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Current attendance",		"fieldname" => "(SELECT COUNT(reg_id) FROM Registrations WHERE reg_event=event_id AND reg_cancelled = 0)",		"type" => FIELD_NUMBER,		"permissions" => ALLOW_VIEW	,	"queryField" => true		),
			array("name" => "Maximum attendance (0 for unlimited)",	"fieldname" => "event_max_users",		"type" => FIELD_NUMBER,		"permissions" => ALLOW_EDIT					),
			array("name" => "Description",			"fieldname" => "event_desc",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Type",					"fieldname" => "event_type",			"type" => FIELD_REFERENCE,	"permissions" => ALLOW_EDIT,	"reftable" => "EventTypes"	),
			array("name" => "Location",				"fieldname" => "event_location",		"type" => FIELD_REFERENCE,	"permissions" => ALLOW_EDIT,	"reftable" => "Locations"	),
			array("name" => "Coordinator",			"fieldname" => "event_coordinator",		"type" => FIELD_REFERENCE,	"permissions" => ALLOW_EDIT,	"reftable" => "Users",		"refconditions" => " WHERE user_status <= 3"		),
			array("name" => "Cost",					"fieldname" => "event_cost",			"type" => FIELD_CURRENCY,	"permissions" => ALLOW_EDIT					),
			array("name" => "Date Created",			"fieldname" => "event_date_created",		"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					),
			array("name" => "Created By",			"fieldname" => "event_created_by",		"type" => FIELD_REFERENCE,	"permissions" => ALLOW_VIEW,	"reftable" => "Users"		),
			array("name" => "Registration Deadline",	"fieldname" => "event_registration_deadline",	"type" => FIELD_DATETIME,	"permissions" => ALLOW_EDIT					),
			array("name" => "Meeting Time",			"fieldname" => "event_meeting_time",		"type" => FIELD_DATETIME,	"permissions" => ALLOW_EDIT					),
			array("name" => "Meeting Location",		"fieldname" => "event_meeting_location",	"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Departure Time",			"fieldname" => "event_departure_time",		"type" => FIELD_DATETIME,	"permissions" => ALLOW_EDIT					),
			array("name" => "Departed",				"fieldname" => "event_departed",		"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_VIEW					),
			array("name" => "Actual Departure Time",	"fieldname" => "event_actual_departure_time",	"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					),
			array("name" => "Return Time",			"fieldname" => "event_return_time",		"type" => FIELD_DATETIME,	"permissions" => ALLOW_EDIT					),
			array("name" => "Actual Return Time",		"fieldname" => "event_actual_return_time",	"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					),
			array("name" => "Cancellation Time",		"fieldname" => "event_cancellation_time",	"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					),
			array("name" => "Cancelled",				"fieldname" => "event_cancelled",		"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_VIEW					),
			array("name" => "Cancelled By",			"fieldname" => "event_cancelled_by",		"type" => FIELD_REFERENCE,	"permissions" => ALLOW_VIEW,	"reftable" => "Users"		),
			array("name" => "Completed",			"fieldname" => "event_completed",		"type" => FIELD_BOOLEAN,	"permissions" => ALLOW_VIEW					),
			array("name" => "Completed By",			"fieldname" => "event_completed_by",		"type" => FIELD_REFERENCE,	"permissions" => ALLOW_VIEW,	"reftable" => "Users"		),
			array("name" => "Notes",				"fieldname" => "event_notes",			"type" => FIELD_TEXT,		"permissions" => ALLOW_VIEW	,	"allowNewline" => true		)
		);
		break;
	case "SmallEvents":
		$fields = array(
			array("name" => "Name",				"fieldname" => "event_name",			"type" => FIELD_TEXT,		"permissions" => ALLOW_VIEW					),
			array("name" => "Description",			"fieldname" => "event_desc",			"type" => FIELD_TEXT,		"permissions" => ALLOW_VIEW					),
			array("name" => "Type",					"fieldname" => "event_type",			"type" => FIELD_REFERENCE,	"permissions" => ALLOW_VIEW,	"reftable" => "EventTypes"	),
			array("name" => "Location",				"fieldname" => "event_location",		"type" => FIELD_REFERENCE,	"permissions" => ALLOW_VIEW,	"reftable" => "Locations"	),
			array("name" => "Coordinator",			"fieldname" => "event_coordinator",		"type" => FIELD_REFERENCE,	"permissions" => ALLOW_VIEW,	"reftable" => "Users",		"refconditions" => " WHERE user_status <= 3"		),
			array("name" => "Cost",					"fieldname" => "event_cost",			"type" => FIELD_CURRENCY,	"permissions" => ALLOW_VIEW					),
			array("name" => "Registration Deadline",	"fieldname" => "event_registration_deadline",	"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					),
			array("name" => "Meeting Time",			"fieldname" => "event_meeting_time",		"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					),
			array("name" => "Meeting Location",		"fieldname" => "event_meeting_location",	"type" => FIELD_TEXT,		"permissions" => ALLOW_VIEW					),
			array("name" => "Departure Time",			"fieldname" => "event_departure_time",		"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					),
			array("name" => "Return Time",			"fieldname" => "event_return_time",		"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					)
		);
		break;
	case "Registrations":
		$fields = array(
			array("name" => "Name",				"fieldname" => "event_name",			"type" => FIELD_TEXT,		"permissions" => ALLOW_VIEW					),
			array("name" => "Description",			"fieldname" => "event_desc",			"type" => FIELD_TEXT,		"permissions" => ALLOW_VIEW					),
			array("name" => "Type",					"fieldname" => "event_type",			"type" => FIELD_REFERENCE,	"permissions" => ALLOW_VIEW,	"reftable" => "EventTypes"	),
			array("name" => "Location",				"fieldname" => "event_location",		"type" => FIELD_REFERENCE,	"permissions" => ALLOW_VIEW,	"reftable" => "Locations"	),
			array("name" => "Coordinator",			"fieldname" => "event_coordinator",		"type" => FIELD_REFERENCE,	"permissions" => ALLOW_VIEW,	"reftable" => "Users",		"refconditions" => " WHERE user_status <= 3"		),
			array("name" => "Cost",					"fieldname" => "event_cost",			"type" => FIELD_CURRENCY,	"permissions" => ALLOW_VIEW					),
			array("name" => "Registration Deadline",	"fieldname" => "event_registration_deadline",	"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					),
			array("name" => "Meeting Time",			"fieldname" => "event_meeting_time",		"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					),
			array("name" => "Meeting Location",		"fieldname" => "event_meeting_location",	"type" => FIELD_TEXT,		"permissions" => ALLOW_VIEW					),
			array("name" => "Departure Time",			"fieldname" => "event_departure_time",		"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					),
			array("name" => "Return Time",			"fieldname" => "event_return_time",		"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW					),
			array("name" => "Cancellation Time",		"fieldname" => "b.reg_cancellation_time",	"type" => FIELD_DATETIME,	"permissions" => ALLOW_VIEW,	"queryField" => true)
		);
		break;
	case "Transactions":
		$fields = array(
			array("name" => "Date",					"fieldname" => "trans_date",			"type" => FIELD_DATETIME,		"permissions" => ALLOW_EDIT					),
			array("name" => "User",					"fieldname" => "trans_user",			"type" => FIELD_REFERENCE,		"permissions" => ALLOW_VIEW,	"reftable"	=> "Users"	),
			array("name" => "Type",					"fieldname" => "trans_type",			"type" => FIELD_CHOICE,			"permissions" => ALLOW_VIEW					),
			array("name" => "Amount",				"fieldname" => "trans_amount",		"type" => FIELD_CURRENCY,		"permissions" => ALLOW_EDIT					),
			array("name" => "Event",				"fieldname" => "trans_reference",		"type" => FIELD_REFERENCE,		"permissions" => ALLOW_VIEW,	"reftable" => "Events"	),
			array("name" => "Notes",				"fieldname" => "trans_notes",			"type" => FIELD_TEXT,			"permissions" => ALLOW_EDIT					),
			array("name" => "Created By",			"fieldname" => "trans_created_by",		"type" => FIELD_REFERENCE,		"permissions" => ALLOW_VIEW,	"reftable"	=> "Users"	)
		);
		break;
	case "EventTypes":
		$fields = array(
			array("name" => "Name",				"fieldname" => "type_name",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Description",			"fieldname" => "type_desc",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					)
		);
		break;
	case "Languages":
		$fields = array(
			array("name" => "English",				"fieldname" => "lang_en",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					),
			array("name" => "Spanish",				"fieldname" => "lang_sp",			"type" => FIELD_TEXT,		"permissions" => ALLOW_EDIT					)
		);
		break;
	default:
		return NULL;
	}

	// eliminate fields from array for which the user does not have access.
	for ($i = 0; $i < count($fields); $i++){
		if ($fields[$i]["access"] && $fields[$i]["access"] < $_SESSION["userstatus"]){
			array_splice($fields, $i, 1);
			$i--;
		}
	}

	return $fields;
}


// Find the index of a particular field in the array
function GetFieldIndex($fields, $fieldName){
	for ($i = 0; $i < count($fields); $i++){
		if ($fields[$i]["fieldname"] == $fieldName){
			return $i;
		}
	}
	return -1;
}

// Returns the singular form of the table name
function GetSingular($tableName){
	switch ($tableName){
	case "Users":
		return "User";
		break;
	case "Contacts":
		return "Contact";
		break;
	case "SmallUsers":
		return "User";
		break;
	case "UserNotes":
		return "Note";
		break;
	case "Locations":
		return "Location";
		break;
	case "Organizations":
		return "Organization";
		break;
	case "Events":
		return "Event";
		break;
	case "Languages":
		return "Translation";
		break;
	case "EventTypes":
		return "Event Type";
		break;
	case "SmallEvents":
		return "Event";
		break;
	case "Transactions":
		return "Transaction";
		break;
	default:
		return NULL;
	}
}

// Returns the plural form of the table name
function GetPlural($tableName){
	switch ($tableName){
	case "Users":
		return "Users";
		break;
	case "Contacts":
		return "Contacts";
		break;
	case "SmallUsers":
		return "Users";
		break;
	case "UserNotes":
		return "Notes";
		break;
	case "Locations":
		return "Locations";
		break;
	case "Organizations":
		return "Organizations";
		break;
	case "Events":
		return "Events";
		break;
	case "Languages":
		return "Translations";
		break;
	case "EventTypes":
		return "Event Types";
		break;
	case "SmallEvents":
		return "Events";
		break;
	case "Transactions":
		return "Transactions";
		break;
	default:
		return NULL;
	}
}

// Returns the name of the field that should be used as the index for the requested table
function GetIndex($tableName){
	switch ($tableName){
	case "Users":
		return "user_id";
		break;
	case "Contacts":
		return "contact_id";
		break;
	case "SmallUsers":
		return "user_id";
		break;
	case "UserNotes":
		return "note_id";
		break;
	case "Locations":
		return "loc_id";
		break;
	case "Organizations":
		return "org_id";
		break;
	case "Events":
		return "event_id";
		break;
	case "Languages":
		return "lang_id";
		break;
	case "EventTypes":
		return "type_id";
		break;
	case "SmallEvents":
		return "event_id";
		break;
	case "Transactions":
		return "trans_id";
		break;
	default:
		return NULL;
	}
}

// Returns the name of the field that should be used to identify objects from the requested table
function GetName($tableName){
	switch ($tableName){
	case "Users":
		return "user_fullname";
		break;
	case "Contacts":
		return "contact_name";
		break;
	case "SmallUsers":
		return "user_fullname";
		break;
	case "UserNotes":
		return "note_id";
		break;
	case "Locations":
		return "loc_name";
		break;
	case "Organizations":
		return "org_name";
		break;
	case "Events":
		return "event_name";
		break;
	case "Languages":
		return "lang_en";
		break;
	case "EventTypes":
		return "type_name";
		break;
	case "SmallEvents":
		return "event_name";
		break;
	case "Transactions":
		return "trans_date";
		break;
	default:
		return NULL;
	}
}

// Specialized function to allow an autofill value for the event_name field
// This function auto-generates an event name based on the entered data (date, type, location).
function GetEventNameAutoFillValue($index){
	if ($index == -1){
		return "";
	}
	$query = "SELECT a.event_meeting_time, b.type_name, c.loc_name FROM Events AS a LEFT OUTER JOIN EventTypes AS b ON (a.event_type = b.type_id) LEFT OUTER JOIN Locations AS c ON (a.event_location = c.loc_id) WHERE a.event_id = " . $index;
	$queryResult = ExecuteQuery($query);
	if ($row = mysql_fetch_row($queryResult)){
		$dateString = "";
		if ($row[0] && $row[0] != "0000-00-00 00:00:00"){
			$dateString = strftime("%Y/%m/%d, %H:%M (%a)", strtotime($row[0]));
		}

		return $dateString . " - " . $row[1] . " - " . $row[2];
	}
	else{
		return "";
	}

}

// Add a string to an existing string, with a delimiter.
function AddString($currentString, $newString, $delimiter){
	if (strlen($currentString)){
		return $currentString . $delimiter . $newString;
	}
	else{
		return $newString;
	}
}

// Translate text from English to Spanish, if required
// Optionally, provide a link to provide a translation, if translation does not exist and user has
// a high enough access level.
function Translate($string, $noTraducir = 0){

	if ($string == ""){
		return "";
	}

	global $languageOverride;
	$retVal = $string;
	$transString = "";

	// Either of these values mean that the user should be shown Spanish
	if ($_SESSION['language'] == 2 || $languageOverride){

		// Get Spanish translation from DB...
		$query = "SELECT lang_sp FROM Languages WHERE lang_en = '" . SafeSingleQuotes($string) . "'";
		$queryResult = ExecuteQuery($query);
		if ($row = mysql_fetch_row($queryResult)){
			// send DB result
			$retVal = $row[0];
		}
		else if ($_SESSION['userstatus'] <= 2 && $_SESSION['language'] == 2){
			// provide English with option to insert a translation
			$transString = " <SMALL>[<A HREF='add_translation_init.php?phrase=" . urlencode($string) . "'>Trad�celo</A>]</SMALL>";
		}
	}

	// Depending on optional parameter value, provide translation option or translation, or both
	switch ($noTraducir){
	default:
	case 0:
		return $retVal . $transString;
		break;
	case 1:
		return $retVal;
		break;
	case 2:
		return $transString;
		break;
	}

}

// Load user settings from database
function ReloadUserSettings(){
	$userQuery = "SELECT user_fullname, user_status, user_lang FROM Users WHERE user_id = " . $_SESSION['userid'];
	$userResult = ExecuteQuery($userQuery);
	if ($userRow = mysql_fetch_row($userResult)){
		$_SESSION['username'] = $userRow[0];
		$_SESSION['userstatus'] = $userRow[1];
		$_SESSION['language'] = $userRow[2];
	}
}

function SafeSingleQuotes($string){
	return str_replace("'", "\'", $string);
}

function UnsafeSingleQuotes($string){
	return str_replace("\'", "'", $string);
}

?>