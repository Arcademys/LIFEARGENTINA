<?php
include_once "header_system.php";

if ($_SESSION['language'] == 2){
	$_GET['lang'] = "es";
}

$indexErrorMsg = "<P ALIGN=CENTER><B>" . Translate("User Logged Off") . "</B></P>";

// destoying the session erases the login information
session_destroy();

// include the main login page
include "index.php";
include_once "footer_system.php";
?>
