<?
if ($_SESSION['auth'] != "TRUE"){

	// If user is not authorized, send them to the login page

	// $noRedirect - This is set by all "results" pages (pages which require a POST)
	// to indicate that if the user enters the page without a login, that they should
	// not be redirected to that page after a sucessful login.
	if ($noRedirect){
		// go to login page without instructions to redirect
		header("Location: index.php");
	}
	else{
		// go to login page with instructions to redirect back to the current page
		// after login
		header("Location: index.php?redirect=" . urlencode(array_pop(explode("/", $_SERVER["REQUEST_URI"]))));
	}
	exit();
}

// Get User Settings
ReloadUserSettings();

// Check to see if user has authorization to view this particular page.
// If $pageStatus is unset, page is visible to all users.
// Otherwise, user status must be less than or equal to the page status.
// Lower values of page status are more restrictive.
// Lower values of user status have more access.
if ($pageStatus && $_SESSION['userstatus'] > $pageStatus){
	header("Location: noauth.php");
}

?>
