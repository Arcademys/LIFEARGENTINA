<?
$noRedirect = true;
$pageStatus = 2;
$tableName = $_POST['table'];
$index = $_POST['index'];

include_once "header_system.php";
$pageTitle = Translate("Edit " . GetSingular($tableName) . " Results");
include_once "header.php";


if ($tableName == "Transactions"){
	// If editing a transaction, you must update the effect of the transaction as well
	$query = "SELECT trans_amount_usd, trans_amount_arg, trans_user FROM Transactions WHERE trans_id = " . $index;
	$result = ExecuteQuery($query);
	if ($row = mysql_fetch_row($result)){
		// This undoes the previous transaction effect (subtracts the change)
		$query = "UPDATE Users SET user_balance_usd = user_balance_usd - " . $row[0] . ", user_balance_arg = user_balance_arg - " . $row[1] . " WHERE user_id = " . $row[2];
		ExecuteQuery($query);
	}
}

// Create and excute update query
$query = GetUpdateQuery(GetTableData($tableName), $tableName) . " WHERE " . GetIndex($tableName) . " = " . $index;
if (ExecuteQuery($query)){
	echo "<P ALIGN=CENTER>" . Translate(GetSingular($tableName) . " Changed") . "</P>\n";
}


if ($tableName == "Transactions"){
	// If editing a transaction, you must update the effect of the transaction as well
	$query = "SELECT trans_amount_usd, trans_amount_arg, trans_user FROM Transactions WHERE trans_id = " . $index;
	$result = ExecuteQuery($query);
	if ($row = mysql_fetch_row($result)){
		// This applies the new transaction effect (adds the change)
		$query = "UPDATE Users SET user_balance_usd = user_balance_usd + " . $row[0] . ", user_balance_arg = user_balance_arg + " . $row[1] . " WHERE user_id = " . $row[2];
		ExecuteQuery($query);
	}
}

if ($tableName == "Events" && $_POST['autocomplete']){
	// update event name with new autofill information
	$query = "UPDATE Events SET event_name = '" . GetEventNameAutoFillValue($index) . "' WHERE event_id = " . $index;
	ExecuteQuery($query);
}

if ($tableName == "Events"){
	// when changing event cost, you must cascade this change to all transactions tied to this event

	$query = "SELECT event_cost_usd, event_cost_arg FROM Events WHERE event_id = " . $index;
	$result = ExecuteQuery($query);
	$row = mysql_fetch_row($result);
	$usd = $row[0];
	$arg = $row[1];

	// get existing transaction value (old cost)
	$query = "SELECT trans_user, trans_amount_usd, trans_amount_arg FROM Transactions WHERE trans_type = 1 AND trans_reference = " . $index;
	$result = ExecuteQuery($query);
	while ($row = mysql_fetch_row($result)){
		// update balances to reflect new cost
		$query = "UPDATE Users SET user_balance_usd = user_balance_usd - " . $row[1] . " + " . $usd . ", user_balance_arg = user_balance_arg - " . $row[2] . " + " . $arg . " WHERE user_id = " . $row[0];
		ExecuteQuery($query);
	}

	// update transactions to reflect new cost
	$query = "UPDATE Transactions SET trans_amount_usd = " . $usd . ", trans_amount_arg = " . $arg . " WHERE trans_type = 1 AND trans_reference = " . $index;
	ExecuteQuery($query);

}

echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("View " . GetSingular($tableName), 1) . "' onClick='window.location.href=\"view_item.php?table=" . $tableName . "&index=" . $index . "\"'>" . Translate("View " . GetSingular($tableName), 2) . "</P>\n";

include_once "footer.php";
?>

