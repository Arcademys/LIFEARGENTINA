<?
include_once "header_system.php";

$pageStatus = 2;

$index = $_GET["index"];

$query = "SELECT event_name, event_coordinator FROM Events WHERE event_cancelled = 0 AND event_completed = 0 AND event_departed = 1 AND event_id = " . $index;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	// The requested event does not exist, or is not valid for completion

	$pageTitle = Translate("Complete Event") . " - " . Translate("Invalid");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("Event data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

// This page is more permissive if the current user is the event coordinator
if ($row[1] == $_SESSION["userid"]){
	$pageStatus = 3;
}

$eventName = $row[0];

$pageTitle = Translate("Complete Event") . " - " . htmlspecialchars($eventName);
include_once "header.php";

// display confirmation dialog (with additional notes to be entered, as well as return time)

echo "<FORM NAME=completeEventForm METHOD=POST ACTION=complete_event_results.php>\n";
echo "<P ALIGN=CENTER>" . Translate("Notes") . ":<BR><TEXTAREA NAME=notes ROWS=3 COLS=80></TEXTAREA><BR>\n";
echo "<TABLE><TR><TD>" . Translate("Actual Return Time") . ":</TD><TD><SCRIPT>DateInput('actual_return_day', true, 'YYYY-MM-DD')</SCRIPT></TD>\n";
echo "<TD><INPUT TYPE=TEXT SIZE=5 NAME=actual_return_time VALUE='" . strftime("%H:%M") . "'></TD></TR></TABLE>\n";

echo "<INPUT TYPE=HIDDEN NAME=index VALUE=" . $index . ">\n";

echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Return", 1) . "' onClick='window.location.href=\"view_item.php?table=Events&index=" . $index . "\"'>" . Translate("Return", 2) . "\n";
echo "<INPUT TYPE=SUBMIT NAME=submit VALUE='" . Translate("Complete Event", 1) . "'>" . Translate("Complete Event", 2) . "\n";
echo "</P>\n";
echo "</FORM>\n";

include_once "footer.php";
?>

