<?
include_once "functions.php";
$pageTitle = Translate("Access Denied");
include_once "header.php";

// This page is loaded if the user tries to access a page that they do not have
// authorization to view (user status > page status).  Please see auth.php
// for more information.

echo "<P ALIGN=CENTER>" . Translate("You are not allowed to access that page") . "</P>\n";

echo "<P ALIGN=CENTER><A HREF=home.php>" . Translate("Home") . "</A></P>\n";


include_once "footer.php";
?>

