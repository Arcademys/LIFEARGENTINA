<?
$pageStatus = 2;

include_once "header_system.php";
$pageTitle = Translate("Import Contact");
include_once "header.php";

$importText = $_POST['importText'];

if ($importText){

	// Divide import text by newlines
	$importArray = explode("\n", $importText);

	$name = "";
	$email = "";
	$lang = "";
	$nation = "";

	for ($i = 0; $i < count($importArray); $i++){
		// Look for keywords in line, and set values accordingly
		if (($offset = strpos($importArray[$i], "Nombre: ")) !== FALSE){
			$name = trim(substr($importArray[$i], $offset + 8));
		}
		if (($offset = strpos($importArray[$i], "e-mail: ")) !== FALSE){
			$email = trim(substr($importArray[$i], $offset + 8));
		}
		if (($offset = strpos($importArray[$i], "Contactar en: ")) !== FALSE){
			$lang = trim(substr($importArray[$i], $offset + 14));
		}
		if (($offset = strpos($importArray[$i], "Pais: ")) !== FALSE){
			$nation = trim(substr($importArray[$i], $offset + 6));
		}
	}

	// if all values are set..
	if ($name !== "" && $email !== "" && $lang !== "" && $nation !== ""){
		// import contact
		$query = "INSERT INTO Contacts (contact_name, contact_email, contact_lang, contact_nationality) VALUES ('" . $name . "', '" . $email . "', '" . $lang . "', '" . $nation . "')";
		if (ExecuteQuery($query)){
			echo "<P ALIGN=CENTER><B>" . Translate("Contact Added") . "</B></P>\n";
		}
	}

}

// produce form to allow contact import
echo "<FORM NAME=importForm ACTION=import_contact.php METHOD=POST>\n";
echo "<P ALIGN=CENTER>\n";
echo Translate("Import Contact") . ":<BR>\n";
echo "<TEXTAREA NAME=importText ROWS=5 COLS=80></TEXTAREA><BR>\n";
echo "<INPUT TYPE=SUBMIT VALUE='" . Translate("Enter", 1) . "'>" . Translate("Enter", 2) . "\n";
echo "</P>\n";
echo "</FORM>\n";

include_once "footer.php";
?>

