<?
include_once "header_system.php";

// $loginSpecial - This is set by index.php and user_register_init.php
// to indicate that they are pages which do not need a login
if (!$loginSpecial){
	include_once "auth.php";
}

include_once "header_display.php";
?>
