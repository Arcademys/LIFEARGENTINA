<?
$noRedirect = true;
include_once "header_system.php";
if ($_POST['lang'] == 2){
	$languageOverride = true;
}
else{
	$languageOverride = false;
}

$pageTitle = Translate("Registration Results");
include_once "header_display.php";

// Passwords must match!
if ($_POST['password'] == $_POST['passwordRetry']){

	// check for existing user with that name...
	$query = "SELECT user_id FROM Users WHERE user_name = '" . $_POST['user_name'] . "'";
	$result = ExecuteQuery($query);
	if ($row = mysql_fetch_row($result)){
		// user already exists
		session_destroy();
		include_once "header_display.php";
		echo "<P ALIGN=CENTER>" . Translate("Failure - username not available") . "</P>\n";
		echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("Back", 1) . "' onClick='window.location.href=\"index.php?lang=" . $_POST['lang'] . "\"'></P>\n";
	}
	else{
		// Create insert query
		// NOTE - passwords are MD5 hashed at this point (not high security, but better than nothing!)
		// Google MD5 password hashing for more information if required
		$query = GetInsertQuery(GetTableData("Users"), "Users", "user_password", "'" . md5($_POST['password']) . "'");
		if (ExecuteQuery($query)){
			// User inserted, so now sign the user in as the new user
			$query = "SELECT user_id, user_fullname, user_status FROM Users WHERE user_name = '" . $_POST['user_name'] . "'";
			$result = ExecuteQuery($query);
			if ($row = mysql_fetch_row($result)){
				$_SESSION['userid'] = $row[0];
				$_SESSION['auth'] = "TRUE";
				echo "<P ALIGN=CENTER><B>" . Translate("Registration Complete!") . "</B></P>\n";
				echo "<P ALIGN=CENTER>" . Translate("Please take a moment to send us an email and introduce yourself.  If possible, please include a recent photograph of yourself.") . "</P>\n";
				echo "<P ALIGN=CENTER><A HREF='mailto:info@lifeargentina.org'>LIFE Argentina</A></P>\n";
				echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("Continue", 1) . "' onClick='window.location.href=\"home.php\"'></P>\n";
			}
			else{
				// Should never happen ... insert succesful but user not found?
				session_destroy();
				echo "<P ALIGN=CENTER>" . Translate("Failure - Could not find new user") . "</P>\n";
				echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("Back", 1) . "' onClick='window.location.href=\"index.php?lang=" . $_POST['lang'] . "\"'></P>\n";
			}
		}
	}
}
else{
	// Show error (password match)
	session_destroy();
	echo "<P ALIGN=CENTER>" . Translate("Failure - Passwords do not match") . "</P>\n";
	echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("Back", 1) . "' onClick='window.location.href=\"index.php?lang=" . $_POST['lang'] . "\"'></P>\n";
}

include_once "footer.php";
?>

