<?
// This page is only a collection of links to predefined searches
// Since the search form uses a GET input, you can bookmark search criteria, or create links like these.


include_once "header_system.php";
$pageTitle = Translate("Predefined Event Searches");
include_once "header.php";

$pageStatus = 2;

echo "<P>\n";
echo "<B>" . Translate("Please Select") . ":</B><BR>\n";
echo "<UL>\n";
echo "<LI><A HREF=search_form.php?table=Events&numCriteria=2&criteria0field=17&criteria0function=1&criteria0value=No&criteria1field=19&criteria1function=1&criteria1value=No>" . Translate("Uncompleted Events Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Events&numCriteria=1&criteria0field=19&criteria0function=1&criteria0value=Yes>" . Translate("Completed Events Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Events&numCriteria=1&criteria0field=17&criteria0function=1&criteria0value=Yes>" . Translate("Cancelled Events Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Events&numCriteria=2&criteria0field=11&criteria0function=1&criteria0value=Jan+1+2009+00%3A00&criteria1field=11&criteria1function=2&criteria1value=Dec+31+2009+23%3A59>" . Translate("Event Departure Date Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Events&numCriteria=1&criteria0field=2&criteria0function=1&criteria0value=>" . Translate("Event Type Search") . "</A></LI>\n";

echo "</UL>\n";
echo "</P>\n";

include_once "footer.php";
?>

