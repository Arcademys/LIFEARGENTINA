<?
$pageStatus = 2;
$tableName = $_GET['table'];
$index = $_GET['index'];

include_once "header_system.php";
$pageTitle = Translate("View " . GetSingular($tableName));
include_once "header.php";

// Get table data, generate and excute query to get record
$fields = GetTableData($tableName);
$query = GetSelectQuery($fields, $tableName) . GetTableList($tableName, $fields) . " WHERE " . GetIndex($tableName) . " = " . $index;
$result = ExecuteQuery($query);
if ($row = mysql_fetch_row($result)){
	// show_actions.php generates a list of valid actions to perform on this item
	include "show_actions.php";

	// show item data
	echo "<TABLE ALIGN=CENTER>\n";
	echo GetFormData($fields, $row);
	echo "</TABLE>\n";
}
else{
	echo "<P ALIGN=CENTER>" . Translate("Error: Could not load record") . "</P>\n";
}

if ($tableName == "Events"){

	// If item is an Event, we must show a list of registered users

	echo "<HR>\n";

	// Generate subquery
	$tableData = GetTableData("SmallUsers");
	$query = GetSelectQuery($tableData, "SmallUsers") . ", b.reg_cancelled" . GetTableList("SmallUsers", $tableData) . " LEFT OUTER JOIN Registrations AS b ON (a.user_id = b.reg_user AND b.reg_event = " . $index . ") WHERE b.reg_id IS NOT NULL ORDER BY b.reg_date_created ASC";
	$result = ExecuteQuery($query);

	// Show results
	$noResults = true;
	echo "<P ALIGN=CENTER><B>" . Translate("Registered Users") . ":</B></P>\n";
	while ($row = mysql_fetch_row($result)){
		$thisIndex = $row[count($row) - 2];
		$cancelled = $row[count($row) - 1];
		if ($noResults){
			echo "<TABLE BGCOLOR=" . $tableBGColor . " CELLPADDING=5 ALIGN=CENTER>\n";
			echo GetHeaderRow($tableData);
			$noResults = false;
		}
		echo GetFormData($tableData, $row, false, true, "Users", $thisIndex, $cancelled);
	}
	if (!$noResults){
		echo "</TABLE>\n";
	}
	else{
		echo "<P ALIGN=CENTER>" . Translate("No users registered") . "</P>\n";
	}
}

if ($tableName == "Users"){

	// If item is a user, show notes and allow user to enter new notes

	echo "<HR>\n";

	$actionText = $_POST['action'];
	if ($actionText == "default"){
		// Create new note
		$query = "INSERT INTO UserNotes (note_user, note_created_by, note_note, note_private) VALUES (" . $index . ", " . $_SESSION["userid"] . ", '" . $_POST["note"] . "', " . $_POST["private"] . ")";
		if (ExecuteQuery($query)){
			echo "<P ALIGN=CENTER><B>" . Translate("Note Added") . "</B></P>\n";
		}
	}
	else if ($actionText != NULL){
		// Check for remove command

		$removeNum = $actionText;
		$query = "SELECT a.note_id FROM UserNotes AS a LEFT OUTER JOIN Users AS b ON (a.note_created_by = b.user_id) WHERE a.note_deleted = 0 AND a.note_id = " . $removeNum . " AND (a.note_created_by = " . $_SESSION["userid"] . " OR b.user_status > " . $_SESSION["userstatus"] . ")";
		$result = ExecuteQuery($query);
		if ($row = mysql_fetch_row($result)){
			// Mark note as removed
			$query = "UPDATE UserNotes SET note_deleted = 1 WHERE note_id = " . $removeNum;
			if (ExecuteQuery($query)){
				echo "<P ALIGN=CENTER><B>" . Translate("Note Removed") . "</B></P>\n";
			}
		}
	}

	// Get list of notes for the User
	// Note that private notes are visible only to the creator, and admins
	$tableData = GetTableData("UserNotes");
	$query = GetSelectQuery($tableData, "UserNotes") . ", (a.note_created_by = " . $_SESSION["userid"] . " OR b.user_status > " . $_SESSION["userstatus"] . ")" . GetTableList("UserNotes", $tableData) . " LEFT OUTER JOIN Users AS b ON (a.note_created_by = b.user_id) WHERE a.note_deleted = 0 AND a.note_user = " . $index . " AND (a.note_private = 0 OR a.note_created_by = " . $_SESSION["userid"] . " OR b.user_status > " . $_SESSION["userstatus"] . ") ORDER BY a.note_date_created ASC";
	$result = ExecuteQuery($query);

	// Display list of notes
	$noResults = true;
	echo "<P ALIGN=CENTER><B>" . Translate("Notes") . ":</B></P>\n";
	while ($row = mysql_fetch_row($result)){
		$thisIndex = $row[count($row) - 2];
		$allowRemove = $row[count($row) - 1];
		if ($noResults){
			// first result, generate table and show header row
			echo "<TABLE BGCOLOR=" . $tableBGColor . " CELLPADDING=5 ALIGN=CENTER>\n";
			echo GetHeaderRow($tableData);
			$noResults = false;
		}
		echo GetFormData($tableData, $row, false, true, "UserNotes", $thisIndex, false, false, $allowRemove);
	}
	if (!$noResults){
		echo "</TABLE>\n";
	}
	else{
		echo "<P ALIGN=CENTER>" . Translate("No notes entered") . "</P>\n";
	}

	// show form to allow users to create new notes
	echo "<FORM NAME=noteForm ACTION=view_item.php?table=Users&index=" . $index . " METHOD=POST>\n";
	echo "<P ALIGN=CENTER>\n";
	echo Translate("Create New Note") . ":<BR>\n";
	echo "<TEXTAREA NAME=note ROWS=3 COLS=80></TEXTAREA><BR>\n";
	echo Translate("Private") . ": <SELECT NAME=private><OPTION VALUE=1>" . Translate("Yes", 1) . "</OPTION><OPTION VALUE=0>" . Translate("No", 1) . "</OPTION></SELECT>\n";
	echo "<INPUT TYPE=HIDDEN NAME=action ID=action VALUE='default'>\n";
	echo "<INPUT TYPE=SUBMIT VALUE='" . Translate("Enter", 1) . "'>" . Translate("Enter", 2) . "\n";
	echo "</P>\n";
	echo "</FORM>\n";

}

include_once "footer.php";
?>

