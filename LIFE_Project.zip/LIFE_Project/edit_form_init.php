<?
$pageStatus = 2;
$tableName = $_GET['table'];
$index = $_GET['index'];

include_once "header_system.php";
$pageTitle = Translate("Edit " . GetSingular($tableName));
include_once "header.php";

// Look up existing values for item
$fields = GetTableData($tableName);
$query = GetSelectQuery($fields, $tableName) . GetTableList($tableName, $fields) . " WHERE " . GetIndex($tableName) . " = " . $index;
$result = ExecuteQuery($query);
if ($row = mysql_fetch_row($result)){

	// Create edit form
	echo "<FORM NAME=editForm METHOD=POST ACTION=edit_form_results.php>\n";

	// Generate a script to check for required fields
	echo "<SCRIPT>function CheckFormValid(){ " . GetRequiredCode($fields, "editForm", false) . "return true; }</SCRIPT>\n";

	if ($tableName == "Users"){
		echo "<P ALIGN=CENTER>* = " . Translate("Required Field") . "</P>\n";
	}

	// Generate edit form
	echo "<TABLE ALIGN=CENTER>\n";

	echo GetFormData($fields, $row, true, false, "NULL", $index);

	echo "<TR><TD ALIGN=CENTER COLSPAN=2>\n";
	echo "<INPUT TYPE=HIDDEN NAME=index VALUE='" . $index . "'>\n";
	echo "<INPUT TYPE=HIDDEN NAME=table VALUE='" . $tableName . "'>\n";
	echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Cancel", 1) . "' onClick='window.location.href=\"view_item.php?table=" . $tableName . "&index=" . $index . "\"'>" . Translate("Cancel", 2) . "\n";
	echo "<INPUT TYPE=SUBMIT ID=requiredButton VALUE='" . Translate("Save", 1) . "' onClick='return CheckFormValid();'>" . Translate("Save", 2) . "\n";
	echo "</TD></TR>\n";
	echo "</TABLE>\n";
	echo "</FORM>\n";

}
else{
	echo "<P ALIGN=CENTER>" . Translate("Error: Could not load " . GetSingular($tableName)) . "</P>\n";
}

include_once "footer.php";
?>

