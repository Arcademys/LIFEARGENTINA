<?
$noRedirect = true;
$userNum = $_POST['index'];
include "header_system.php";

// Get user name and status
$query = "SELECT user_fullname, user_status FROM Users WHERE user_id = " . $userNum;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	$pageTitle = Translate("Reset Password Results") . " - " . Translate("Unknown User");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("User data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

$userName = $row[0];
$userStatus = $row[1];
$currentUserStatus = $_SESSION['userstatus'];

// only allowed to edit password of users with a lower status (admins excepted)
if ($userStatus == 1){
	$pageStatus = 1;
}
else{
	$pageStatus = $userStatus - 1;
}

if ($pageStatus > 3){
	// minimum access required to reset password
	$pageStatus = 3;
}


$pageTitle = Translate("Reset Password Results") . " - " . htmlspecialchars($userName);
include_once "header.php";

// Change password (uses md5 hashing, google md5 password hash for info)
$query = "UPDATE Users SET user_password = '" . md5($_POST['newPassword']) . "' WHERE user_id = " . $userNum;
if (ExecuteQuery($query)){
	$resultString = "Password Changed";
}
else{
	$resultString = "Failure - Could not change record";
}

echo "<P ALIGN=CENTER>" . Translate($resultString) . "</P>\n";
echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("Return", 1) . "' onClick='window.location.href=\"view_item.php?table=Users&index=" . $userNum . "\"'>" . Translate("Return", 2) . "</P>\n";

include_once "footer.php";
?>

