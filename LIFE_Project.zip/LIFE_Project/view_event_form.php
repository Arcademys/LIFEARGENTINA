<?

$index = $_GET['index'];
include_once "header_system.php";
$pageStatus = 2;

// This page shows more or less printable form for volunteer signup

// Get event name and departure time
$query = "SELECT event_name, event_departure_time FROM Events WHERE event_id = " . $index;
$result = ExecuteQuery($query);
if ($row = mysql_fetch_row($result)){
	$eventName = $row[0];
	$departTime = $row[1];
}
else{
	$pageTitle = Translate("Invalid Event");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("Event data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

include_once "functions.php";
$pageTitle = Translate("View Event Form") . " - " . $eventName;
include_once "header.php";

echo "<P ALIGN=CENTER><B>" . Translate("Event") . ":</B> " . $eventName . "<BR>\n";
echo "<B>" . Translate("Departs at") . ":</B> " . $departTime . "</P>\n";

// Get list of users who are attending
// data includes user name, organization, event cost (if applicable), and amount owing
$query = "SELECT b.user_fullname, c.org_name, CONCAT(IF (ROUND(d.trans_amount_usd, 2), CONCAT('\$', FORMAT(ROUND(d.trans_amount_usd, 2), 2), ' USD'), ''), IF (ROUND(d.trans_amount_usd, 2) AND ROUND(d.trans_amount_arg, 2), ' and ', ''), IF (ROUND(d.trans_amount_arg, 2), CONCAT('\$', FORMAT(ROUND(d.trans_amount_arg, 2), 2), ' ARG'), '')), CONCAT(IF (ROUND(b.user_balance_usd, 2), CONCAT('\$', FORMAT(ROUND(b.user_balance_usd, 2), 2), ' USD'), ''), IF (ROUND(b.user_balance_usd, 2) AND ROUND(b.user_balance_arg, 2), ' and ', ''), IF (ROUND(b.user_balance_arg, 2), CONCAT('\$', FORMAT(ROUND(b.user_balance_arg, 2), 2), ' ARG'), '')) FROM Registrations AS a LEFT OUTER JOIN Users AS b ON (a.reg_user = b.user_id) LEFT OUTER JOIN Organizations AS c ON (b.user_org = c.org_id) LEFT OUTER JOIN Transactions AS d ON (a.reg_user = d.trans_user AND a.reg_event = d.trans_reference) WHERE a.reg_cancelled = 0 AND a.reg_event = " . $index;
$result = ExecuteQuery($query);

$noResults = true;
while ($row = mysql_fetch_row($result)){
	if ($noResults){
		// display header for first result
		echo "<TABLE BORDER=1 BGCOLOR=" . $tableBGColor . " CELLPADDING=5 ALIGN=CENTER WIDTH=100%>\n";
		echo "<TR BGCOLOR=" . $tableHeadingColor . ">\n";
		echo "<TD ALIGN=CENTER NOWRAP><B>" . Translate("Full Name") . "</B></TD>\n";
		echo "<TD ALIGN=CENTER NOWRAP WIDTH=200><B>" . Translate("Signature") . "</B></TD>\n";
		echo "<TD ALIGN=CENTER NOWRAP><B>" . Translate("Organization") . "</B></TD>\n";
		echo "<TD ALIGN=CENTER NOWRAP><B>" . Translate("Price") . "</B></TD>\n";
		echo "<TD ALIGN=CENTER NOWRAP><B>" . Translate("Balance") . "</B></TD>\n";
		echo "<TD ALIGN=CENTER NOWRAP WIDTH=150><B>" . Translate("Amount Paid") . "</B></TD>\n";
		echo "</TR>\n";
		$noResults = false;
	}

	// Row 0 is the name, 1 is the organization, 2 is the event cost, and 3 is the user balance
	echo "<TR BGCOLOR=" . $tableCellColor . ">\n";
	echo "<TD ALIGN=CENTER NOWRAP>" . $row[0] . "</TD>\n";
	echo "<TD ALIGN=CENTER NOWRAP> &nbsp </TD>\n";
	echo "<TD ALIGN=CENTER NOWRAP>" . $row[1] . "</TD>\n";
	echo "<TD ALIGN=CENTER NOWRAP>" . $row[2] . "</TD>\n";
	echo "<TD ALIGN=CENTER NOWRAP>" . $row[3] . "</TD>\n";
	echo "<TD ALIGN=CENTER NOWRAP> &nbsp </TD>\n";
	echo "</TR>\n";
}
if (!$noResults){
	echo "</TABLE>\n";
}
else{
	echo "<P ALIGN=CENTER>" . Translate("No users registered") . "</P>\n";
}

// show an empty box at the bottom for event comments
echo "<HR>\n";
echo "<TABLE ALIGN=CENTER WIDTH=100% BORDER=1><TR><TD ALIGN=CENTER><B>" . Translate("Comments") . ":</B></TD></TR>\n";
echo "<TR><TD HEIGHT=150> &nbsp </TD></TR></TABLE>\n";

include_once "footer.php";
?>

