<?
$noRedirect = true;

include_once "header_system.php";

// Generate query to update user settings
$success = false;
$query = GetUpdateQuery(GetTableData("Users"), "Users") . " WHERE user_id = " . $_SESSION['userid'];
if (ExecuteQuery($query)){
	$success = true;
	ReloadUserSettings();
}

// Show page results
$pageTitle = Translate("Edit Settings Results");
include_once "header.php";
if ($success){
	echo "<P ALIGN=CENTER>" . Translate("Settings Changed") . "</P>\n";
}

echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("View Settings", 1) . "' onClick='window.location.href=\"user_view_settings.php\"'>" . Translate("View Settings", 2) . "</P>\n";

include_once "footer.php";
?>

