<?
$systemTitle = Translate("LIFE Argentina");
?>

<HTML>
<HEAD>
<SCRIPT SRC="common_functions.js"></SCRIPT>
<SCRIPT TYPE="text/javascript" SRC="calendarDateInput.js">

/***********************************************
* Jason's Date Input Calendar- By Jason Moon http://calendar.moonscript.com/dateinput.cfm
* Script featured on and available at http://www.dynamicdrive.com
* Keep this notice intact for use.
***********************************************/

</SCRIPT>
<TITLE><? echo $systemTitle . " - " . $pageTitle; ?></TITLE>
</HEAD>
<BODY BGCOLOR=<? echo $pageBGColor; ?> onLoad="SetFocus();">

<TABLE WIDTH=100%><TR>
<TD WIDTH=30%>
<H1 ALIGN=CENTER><? echo $systemTitle; ?></H1>
</TD>

<TD WIDTH=40%>
<H2 ALIGN=CENTER><? echo $pageTitle; ?></H2>
</TD>

<TD WIDTH=30%>
<?
// $loginSpecial indicates a page that doesn't require a login, therefore do not show
// interior navigation links and user information.
if (!$loginSpecial){
	echo "<P ALIGN=CENTER>\n";
	echo "<B>" . Translate("User") . ":</B> " . htmlspecialchars($_SESSION['username']) . "<BR>\n";
	if ($_SESSION['userstatus'] <= 2){
		echo "<A HREF='search_form.php?table=Contacts'>" . Translate("Contacts") . "</A>\n";
		echo "<A HREF='search_form.php?table=Users'>" . Translate("Users") . "</A>\n";
		echo "<A HREF='search_form.php?table=Events'>" . Translate("Events") . "</A><BR>\n";
		echo "<A HREF='search_form.php?table=Locations'>" . Translate("Locations") . "</A>\n";
		echo "<A HREF='search_form.php?table=EventTypes'>" . Translate("Types") . "</A><BR>\n";
		echo "<A HREF='search_form.php?table=Organizations'>" . Translate("Organizations") . "</A>\n";
		echo "<A HREF='search_form.php?table=Languages'>" . Translate("Translations") . "</A><BR>\n";
	}
	echo "<A HREF='home.php'>" . Translate("Home") . "</A>\n";
	echo "<A HREF='user_view_settings.php'>" . Translate("Settings") . "</A>\n";
	echo "<A HREF='logout.php'>" . Translate("Logout") . "</A>\n";
	echo "</P>\n";
} // if
?>
</TD></TR></TABLE>

<HR>
