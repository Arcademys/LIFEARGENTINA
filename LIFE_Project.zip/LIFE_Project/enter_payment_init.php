<?
$pageStatus = 2;
include_once "header_system.php";

// Get user name and current balance
$userNum = $_GET['index'];
$query = "SELECT user_fullname, FORMAT(ROUND(user_balance_usd, 2), 2), FORMAT(ROUND(user_balance_arg, 2), 2) FROM Users WHERE user_id = " . $userNum;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	$pageTitle = Translate("Enter Payment") . " - " . Translate("Unknown User");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("User data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

$userName = $row[0];
$usd = $row[1];
$arg = $row[2];

$pageTitle = Translate("Enter Payment") . " - " . htmlspecialchars($userName);
include_once "header.php";

// Show current balance, and allow user to enter payment amount
echo "<FORM NAME=enterPaymentForm METHOD=POST ACTION=enter_payment_results.php>\n";
echo "<TABLE ALIGN=CENTER>\n";
echo "<TR><TD></TD><TD ALIGN=CENTER><B>US Dollars</B></TD><TD ALIGN=CENTER><B>ARG Pesos</B></TD></TR>\n";
echo "<TR><TD><B>" . Translate("Current Balance") . ":</B></TD><TD ALIGN=LEFT>" . $usd . "</TD><TD ALIGN=LEFT>" . $arg . "</TD></TR>\n";
echo "<TR><TD><B>" . Translate("Payment") . ":</B></TD><TD ALIGN=LEFT><INPUT TYPE=TEXT SIZE=7 NAME=usd VALUE='0'></TD><TD ALIGN=LEFT><INPUT TYPE=TEXT SIZE=7 NAME=arg VALUE='0'></TD></TR>\n";
echo "</TABLE>\n";

// Show confirmation dialog
echo "<P ALIGN=CENTER><INPUT TYPE=HIDDEN NAME=index VALUE=" . $userNum . ">\n";
echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Cancel", 1) . "' onClick='window.location.href=\"view_item.php?table=Users&index=" . $userNum . "\"'>" . Translate("Cancel", 2) . "\n";
echo "<INPUT TYPE=SUBMIT NAME=submit VALUE='" . Translate("Enter Payment", 1) . "'>" . Translate("Enter Payment", 2) . "</P>\n";

echo "</FORM>\n";

include_once "footer.php";
?>

