<?
include_once "header_system.php";
$pageTitle = Translate("View Settings");
include_once "header.php";

// Look up user data
$fields = GetTableData("Users");
$query = GetSelectQuery($fields, "Users") . GetTableList("Users", $fields) . " WHERE user_id = " . $_SESSION['userid'];

$result = ExecuteQuery($query);
if ($row = mysql_fetch_row($result)){
	// Display user data

	echo "<TABLE ALIGN=CENTER>\n";
	echo GetFormData($fields, $row);
	echo "</TABLE>\n";

	// Show options to change password or settings
	echo "<P ALIGN=CENTER>\n";
	echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Change Password", 1) . "' onClick='window.location.href=\"user_change_pw_init.php\"'>" . Translate("Change Password", 2) . "\n";
	echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Edit Settings", 1) . "' onClick='window.location.href=\"user_edit_settings_init.php\"'>" . Translate("Edit Settings", 2) . "\n";
	echo "</P>\n";

}
else{
	echo "<P ALIGN=CENTER>" . Translate("Error: Could not load settings") . "</P>\n";
}

include_once "footer.php";
?>

