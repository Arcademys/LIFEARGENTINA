<?
$noRedirect = true;
$userNum = $_POST['index'];
include "header_system.php";

// Get user name
$query = "SELECT user_fullname FROM Users WHERE user_id = " . $userNum;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	$pageTitle = Translate("Enter T-Shirt Fee Results") . " - " . Translate("Unknown User");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("User data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

$userName = $row[0];
$pageStatus = 2;

$pageTitle = Translate("Enter T-Shirt Fee Results") . " - " . $userName;
include_once "header.php";

$usd = $_POST["usd"];
if (!$usd){
	$usd = 0;
}
$arg = $_POST["arg"];
if (!$arg){
	$arg = 0;
}

// Insert T-shirt transaction
$query = "INSERT INTO Transactions(trans_user, trans_type, trans_amount_usd, trans_amount_arg, trans_created_by, trans_notes) VALUES (" . $userNum . ", 5, " . $usd . ", " . $arg . ", " . $_SESSION["userid"] . ", '" . $_POST["notes"] . "')";
if (ExecuteQuery($query)){
	$resultString = "T-Shirt Fee Entered";
}
else{
	$resultString = "Failure - Could not enter t-shirt fee";
}

// update balance
$query = "UPDATE Users SET user_balance_usd = user_balance_usd + " . $usd . ", user_balance_arg = user_balance_arg + " . $arg . " WHERE user_id = " . $userNum;
ExecuteQuery($query);

echo "<P ALIGN=CENTER>" . Translate($resultString) . "</P>\n";
echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("Return", 1) . "' onClick='window.location.href=\"view_item.php?table=Users&index=" . $userNum . "\"'>" . Translate("Return", 2) . "</P>\n";

include_once "footer.php";
?>

