<?
$noRedirect = true;
include_once "header_system.php";
$pageTitle = Translate("Change Password Results");
include_once "header.php";

// make sure passwords match
if ($_POST['newPassword'] == $_POST['newPasswordRetry']){

	// make sure old password matches
	$query = "SELECT user_id FROM Users WHERE user_password = '" . md5($_POST['oldPassword']) . "' AND user_id = " . $_SESSION['userid'];
	$result = ExecuteQuery($query);
	if ($row = mysql_fetch_row($result)){
		// change password (uses md5 hash - google for md5 password hash for more info)
		$query = "UPDATE Users SET user_password = '" . md5($_POST['newPassword']) . "' WHERE user_id = " . $row[0];
		if (ExecuteQuery($query)){
			$resultString = "Password Changed";
		}
		else{
			$resultString = "Failure - Could not change record";
		}
	}
	else{
		$resultString = "Failure - Old password incorrect";
	}
}
else{
	$resultString = "Failure - Passwords do not match";
}

echo "<P ALIGN=CENTER>" . Translate($resultString) . "</P>\n";
echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("View Settings", 1) . "' onClick='window.location.href=\"user_view_settings.php\"'>" . Translate("View Settings", 2) . "</P>\n";

include_once "footer.php";
?>

