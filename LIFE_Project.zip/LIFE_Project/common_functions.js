
// For pages with forms, set the focus on the element named "focus"
function SetFocus(){
	if (document.getElementById('focus')){
		document.getElementById('focus').focus();
	}
}

// Search through a select dialog for an option, and select it
function SetSelectDefault(selectID, selectValue){
	var selectList = document.getElementById(selectID);

	// search for specified option
	var i = 0;
	var found = false;
	while (selectList && i < selectList.length && !found){
		if (selectList.options[i].value == selectValue){
			selectList.options[i].selected = true;
			found = true;
		}
		i++;
	}
	
	// if option not found, search for "other" option
	i = 0;
	while (selectList && i < selectList.length && !found){
		if (selectList.options[i].value == "Other"){
			selectList.options[i].selected = true;
			found = true;
		}
		i++;
	}
}

// This function is used by the search dialog (search_form.php).  It allows the operators
// to change when the search criterion field is changed.  This is necessary because the
// operators allowed for a text field are different than those allowed for a numerical
// or date field.
function SetFunctionValues(elementNum, functionType, selectedChoice){
	
	// Find specified list
	var selectList = document.getElementById('criteria' + elementNum + 'function');
	selectList.length = 0;
	
	var i = 1;
	var text = GetFunctionText(functionType, i);
	while (text){
		// Loop through all of the options specified by GetFunctionText for
		// this particular field type.
		
		// Create a new select option for each operator
		selectList.options[selectList.options.length] = new Option(text, i);
		if (selectedChoice == i){
			selectList.options[i-1].selected = true;
		}
		i++;
		text = GetFunctionText(functionType, i);
	}

}


// This function is used by SetFunctionValues to return a sequence of select options
// corresponding to valid operators for each field type.
// NOTE: functionType index meanings must match FIELD_* defines in functions.php
// NOTE: choice index meanings must match $searchData[$i]["function"] meanings in
//       GetWhereConditions in functions.php
// Please see functions.php for descriptions of field types
function GetFunctionText(functionType, choice){
	switch(functionType){
	case 1:
	case 4:
	case 5:
	case 7:
		switch(choice){
		case 1:
			return "contains";
			break;    
		case 2:
			return "equals";
			break;
		default:
			return null;
			break;
		}
		break;    
	case 2:
	case 6:
	case 9:
		switch(choice){
		case 1:
			return "equals";
			break;    
		case 2:
			return "greater than";
			break;
		case 3:
			return "less than";
			break;
		default:
			return null;
			break;
		}
		break;
	case 3:
		switch(choice){
		case 1:
			return "greater than";
			break;
		case 2:
			return "less than";
			break;
		default:
			return null;
			break;
		}
		break;
	case 8:
		switch(choice){
		case 1:
			return "equals";
			break;    
		default:
			return null;
			break;
		}
		break;
	default:
		return null;
		break;
	}
}


// This function is used to set an input value and submit a form when an Enter
// keypress is detected
function EnterFormButton(buttonName, buttonValue, formName, event){
	
	var keycode;
	if (window.event){
		keycode = window.event.keyCode;
	}
	else if (event){
		keycode = event.which;
	}
	else{
		return true;
	}

	if (keycode == 13){ // Enter
		document.getElementById(buttonName).value = buttonValue;
		document.getElementById(formName).submit();
		return false;
	}
	else{
		return true;
	}

}

// For forms which have required fields, this function detects Enter keypresses and
// filters them through a CheckFormValid function.  That function must be defined in
// the javascript of such a page.
function EnterRequired(event){
		
	if (!document.getElementById('requiredButton')){
		return true;
	}
	
	var keycode;
	if (window.event){
		keycode = window.event.keyCode;
	}
	else if (event){
		keycode = event.which;
	}
	else{
		return true;
	}

	if (keycode == 13){
		return CheckFormValid();
	}
	else{
		return true;
	}

}








