<?
// This page is dynamically determined to search a table.
// It requres a GET variable 'table', and it loads the search fields for that table only

$tableName = $_GET['table'];
$pageStatus = 2;

include_once "header_system.php";
$pageTitle = Translate("Search " . GetPlural($tableName));
include_once "header.php";
$tableData = GetTableData($tableName);

if ($tableData == NULL){
	echo "<P ALIGN=CENTER>" . Translate("Unable to find table") . ": " . $tableName . "</P>\n";
}
else{

	// Read the number of existing critera
	$numCriteria = $_GET['numCriteria'];
	if (!$numCriteria){
		$numCriteria = 0;
	}
	if ($_GET['action'] == "addCriteria"){
		$numCriteria++;
	}

	// load all criteria which were NOT removed
	$j = 0;
	for ($i = 0; $i < $numCriteria; $i++){
		if ($_GET['action'] != "remove" . $i){
			// criteria was not removed, add it to array

			$searchData[$j]["field"] = $_GET["criteria" . $i . "field"];
			if (!$searchData[$j]["field"]){
				$searchData[$j]["field"] = 0;
			}
			$searchData[$j]["function"] = $_GET["criteria" . $i . "function"];
			if (!$searchData[$j]["function"]){
				$searchData[$j]["function"] = 0;
			}
			$searchData[$j]["value"] = $_GET["criteria" . $i . "value"];
			$j++;
		}
	}
	$numCriteria = $j;

	// Create search form
	echo "<FORM NAME=searchForm ID=searchForm METHOD=GET ACTION=search_form.php>\n";
	echo "<INPUT TYPE=HIDDEN NAME=table VALUE='" . $tableName . "'>\n";
	echo "<INPUT TYPE=HIDDEN NAME=numCriteria VALUE='" . $numCriteria . "'>\n";
	echo "<INPUT TYPE=HIDDEN NAME=action ID=action VALUE='update'>\n";
	if ($tableName != "Transactions"){
		// Transactions have no action buttons

		if ($tableName != "Users"){
			if ($tableName != "Contacts"){
				// Default case - most tables allow an ADD ability
				echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("Create New " . GetSingular($tableName), 1) . "' onClick='window.location.href=\"add_form_init.php?table=" . $tableName . "\"'>" . Translate("Create New " . GetSingular($tableName), 2) . "</P>\n";
			}
			else{
				// Contacts allow an import, add, or email list
				echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("Import Contact", 1) . "' onClick='window.location.href=\"import_contact.php\"'>" . Translate("Import Contact", 2) . " <INPUT TYPE=BUTTON VALUE='" . Translate("Create New " . GetSingular($tableName), 1) . "' onClick='window.location.href=\"add_form_init.php?table=" . $tableName . "\"'>" . Translate("Create New " . GetSingular($tableName), 2) . " <INPUT TYPE=BUTTON VALUE='" . Translate("Email List", 1) . "' onClick='document.searchForm.action = \"email_list.php\"; document.searchForm.submit();'>" . Translate("Email List", 2) . "</P>\n";
			}
		}
		else{
			// Users have only an email list button (no create user option)
			echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("Email List", 1) . "' onClick='document.searchForm.action = \"email_list.php\"; document.searchForm.submit();'>" . Translate("Email List", 2) . "</P>\n";
		}
	}
	echo "<P ALIGN=CENTER><B>" . Translate("Existing Filter Criteria") . ":</B><BR>\n";

	$numFields = count($tableData);

	// The following array is used by the javascript on this page to update the criteria function when the field is changed
	// each index corresponds to a field index, and the value is the field type.
	echo "<SCRIPT>\n";
	echo "var criteriaValueTypeArray = new Array(" . $numFields . ");\n";
	for ($i = 0; $i < $numFields; $i++){
		echo "criteriaValueTypeArray[" . $i . "] = " . $tableData[$i]["type"] . ";\n";
	}
	echo "</SCRIPT>\n";

	for ($i = 0; $i < $numCriteria; $i++){
		// Create a line for each existing criteria

		// Criteria field - when this changes, SetFunctionValues (in common_functions.js) is called
		echo "<SELECT NAME=criteria" . $i . "field ID=criteria" . $i . "field OnChange='SetFunctionValues(" . $i . ", criteriaValueTypeArray[document.getElementById(\"criteria" . $i . "field\").value], 1);'>\n";
		for ($j = 0; $j < $numFields; $j++){
			echo "<OPTION VALUE=" . $j;
			if ($j == $searchData[$i]["field"]){
				echo " SELECTED";
			}
			echo ">" . Translate($tableData[$j]["name"], 1) . "</OPTION>\n";
		}
		echo "</SELECT>\n";

		// Criteria function, with a script to fill it (using SetFunctionValues)
		echo "<SELECT NAME=criteria" . $i . "function ID=criteria" . $i . "function>\n";
		echo "</SELECT>\n";
		echo "<SCRIPT>\n";
		echo "SetFunctionValues(" . $i . ", criteriaValueTypeArray[document.getElementById('criteria" . $i . "field').value], " . $searchData[$i]["function"] . ");";
		echo "</SCRIPT>\n";

		// Criteria text, and remove button
		echo "<INPUT TYPE=TEXT NAME=criteria" . $i . "value VALUE='" . SafeValue($searchData[$i]["value"]) . "' onKeyPress='return EnterFormButton(\"action\", \"update\", \"searchForm\", event);'>\n";
		echo "<INPUT TYPE=SUBMIT NAME=remove" . $i . " VALUE='" . Translate("Remove", 1) . "' onClick='document.getElementById(\"action\").value=\"remove" . $i . "\"; return true;'>" . Translate("Remove", 2) . "<BR>\n";
	}
	if ($numCriteria == 0){
		echo Translate("No criteria specified (full list displayed)") . "<BR>\n";
	}
	echo "<INPUT TYPE=SUBMIT NAME=update VALUE='" . Translate("Update" , 1) . "'>" . Translate("Update" , 2) . "<BR>\n";
	echo "</P>\n";

	// Allow user to enter a new criteria
	echo "<P ALIGN=CENTER><B>" . Translate("New Filter Criteria") . ":</B><BR>\n";

	// Criteria field - when this changes, SetFunctionValues (in common_functions.js) is called
	echo "<SELECT NAME=criteria" . $numCriteria . "field ID=criteria" . $numCriteria . "field OnChange='SetFunctionValues(" . $i . ", criteriaValueTypeArray[document.getElementById(\"criteria" . $numCriteria . "field\").value], 1);'>\n";
	for ($j = 0; $j < $numFields; $j++){
		echo "<OPTION VALUE=" . $j . ">" . Translate($tableData[$j]["name"], 1) . "</OPTION>\n";
	}
	echo "</SELECT>\n";

	// Criteria function, with a script to fill it (using SetFunctionValues)
	echo "<SELECT NAME=criteria" . $numCriteria . "function ID=criteria" . $numCriteria . "function>\n";
	echo "</SELECT>\n";
	echo "<SCRIPT>\n";
	echo "SetFunctionValues(" . $numCriteria . ", criteriaValueTypeArray[document.getElementById('criteria" . $numCriteria . "field').value], 1);";
	echo "</SCRIPT>\n";

	// Criteria text, and add button
	echo "<INPUT TYPE=TEXT NAME=criteria" . $numCriteria . "value ID=focus VALUE='' onKeyPress='return EnterFormButton(\"action\", \"addCriteria\", \"searchForm\", event);'>\n";
	echo "<INPUT TYPE=SUBMIT NAME=addCriteria VALUE='" . Translate("Add", 1) . "' onClick='document.getElementById(\"action\").value=\"addCriteria\"; return true;'>" . Translate("Add", 2) . "<BR>\n";
	echo "</P>\n";
	echo "<HR>\n";

	// Get count of results (preview query)
	$query = "SELECT COUNT(a." . GetIndex($tableName) . ")" . GetTableList($tableName, $tableData) . GetWhereConditions($tableData, $searchData, $numCriteria);
	$result = ExecuteQuery($query);
	$row = mysql_fetch_row($result);
	$numResults = $row[0];

	if ($numResults > 0){

		// Check the number of results requested per page, calculate pages required
		$resultsPerPage = $_GET["resultsPerPage"];
		if (!$resultsPerPage){
			$resultsPerPage = 10;
		}
		$numPages = ceil($numResults / $resultsPerPage);

		if ($resultsPerPage > 0 && $numResults > $resultsPerPage){
			// Paging required

			// Get current page, and allow page navigation
			$currentPage = $_GET["currentPage"];
			if ($_GET["backPage"]){
				$currentPage--;
			}
			if ($_GET["forwardPage"]){
				$currentPage++;
			}
			if (!$currentPage || $currentPage < 1){
				$currentPage = 1;
			}
			if ($currentPage > $numPages){
				$currentPage = $numPages;
			}

			// Calculate paging part of request
			$paging = " LIMIT " . (($currentPage - 1) * $resultsPerPage) . ", " . $resultsPerPage;

		}
		else{
			$currentPage = 0;
			$paging = "";
		}

		// Determine ORDER BY value
		$orderByField = $_GET["orderBy"];
		if (!$orderByField || $orderByField < 0 || $orderByField >= $numFields){
			if ($tableName == "Events"){
				// Special default for events
				$orderByField = GetFieldIndex($tableData, "event_departure_time");
			}
			else{
				$orderByField = 0;
			}
		}

		// Determine ORDER BY portion of query
		if ($tableData[$orderByField]["queryField"]){
			$orderBy = " ORDER BY " . $tableData[$orderByField]["fieldname"];
		}
		else{
			$orderBy = " ORDER BY a." . $tableData[$orderByField]["fieldname"];
		}

		if (!$_GET["orderByDesc"] && $tableName == "Events"){
			// Special default for events
			$orderBy .= " DESC";
			$orderByDesc = true;
		}
		else{
			$orderByDesc = ($_GET["orderByDesc"] == "TRUE");
			if ($orderByDesc){
				$orderBy .= " DESC";
			}
			else{
				$orderBy .= " ASC";
			}
		}


		echo "<TABLE WIDTH=100%><TR>\n";

		// Report result size
		echo "<TD ALIGN=LEFT>";
		if ($numResults == 1){
			$word = "record";
		}
		else{
			$word = "records";
		}
		echo "<B>" . $numResults . " " . Translate($word . " found") . "</B>";
		echo "</TD>\n";

		// Show results per page options
		echo "<TD ALIGN=CENTER>";
		echo Translate("Show") . " <SELECT NAME=resultsPerPage onChange='document.searchForm.submit(); return true;'>\n";
		echo "<OPTION VALUE=10";
		if ($resultsPerPage == 10){
			echo " SELECTED";
		}
		echo ">10</OPTION>\n";
		echo "<OPTION VALUE=20";
		if ($resultsPerPage == 20){
			echo " SELECTED";
		}
		echo ">20</OPTION>\n";
		echo "<OPTION VALUE=50";
		if ($resultsPerPage == 50){
			echo " SELECTED";
		}
		echo ">50</OPTION>\n";
		echo "<OPTION VALUE=100";
		if ($resultsPerPage == 100){
			echo " SELECTED";
		}
		echo ">100</OPTION>\n";
		echo "<OPTION VALUE=-1";
		if ($resultsPerPage == -1){
			echo " SELECTED";
		}
		echo ">" . Translate("All", 1) . "</OPTION>\n";
		echo "</SELECT>" . Translate("All", 2) . " " . Translate("results per page") . "\n";
		echo "</TD>\n";

		// Show page navigation
		echo "<TD ALIGN=CENTER>";
		if ($currentPage > 0){
			echo "<INPUT TYPE=HIDDEN NAME=currentPage VALUE=" . $currentPage . ">\n";
			if ($currentPage > 1){
				echo "<INPUT TYPE=SUBMIT NAME=backPage VALUE='<'> ";
			}
			echo Translate("Page") . " " . $currentPage . " " . Translate("of") . " " . $numPages;
			if ($currentPage < $numPages){
				echo " <INPUT TYPE=SUBMIT NAME=forwardPage VALUE='>'>";
			}
		}
		echo "</TD>\n";

		// Show ORDER BY dialog
		echo "<TD ALIGN=RIGHT>";
		echo Translate("Order By") . ": <SELECT NAME=orderBy onChange='document.searchForm.submit(); return true;'>\n";
		for ($j = 0; $j < $numFields; $j++){
			echo "<OPTION VALUE=" . $j;
			if ($j == $orderByField){
				echo " SELECTED";
			}
			echo ">" . Translate($tableData[$j]["name"]) . "</OPTION>\n";
		}
		echo "</SELECT>";
		echo "<SELECT NAME=orderByDesc onChange='document.searchForm.submit(); return true;'>\n";
		echo "<OPTION VALUE='FALSE'";
		if (!$orderByDesc){
			echo " SELECTED";
		}
		echo ">ASC</OPTION>\n";
		echo "<OPTION VALUE='TRUE'";
		if ($orderByDesc){
			echo " SELECTED";
		}
		echo ">DESC</OPTION>\n";
		echo "</SELECT>\n";
		echo "</TD>\n";

		echo "</TR></TABLE>\n";

		// Generate and execute query
		$query = MakeSearchQuery($tableData, $tableName, $searchData, $numCriteria) . $orderBy . $paging;
		$result = ExecuteQuery($query);

		$noResults = true;

		while ($row = mysql_fetch_row($result)){
			if ($noResults){
				// First entry, output table info and header row
				echo "<TABLE BGCOLOR=" . $tableBGColor . " CELLPADDING=5 ALIGN=CENTER WIDTH=100%>\n";
				echo GetHeaderRow($tableData);
				$noResults = false;
			}
			// Output result line
			echo GetFormData($tableData, $row, false, true, $tableName, $row[count($row) - 1]);
		}
		if (!$noResults){
			echo "</TABLE>\n";
		}
	}
	else{
		echo "<P ALIGN=CENTER><B>" . Translate("No Results Found") . "</B></P>\n";
	}

	echo "</FORM>\n";

}

include_once "footer.php";
?>

