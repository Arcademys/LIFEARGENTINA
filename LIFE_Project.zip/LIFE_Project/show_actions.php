
<?

// This is an include file that generates the available actions when viewing an item

$currentUserStatus = $_SESSION['userstatus'];
$index = $row[count($row) - 1];
$actionList = "";
switch ($tableName){
case "Users":
	// If we are viewing a user entry, the available actions depend on the status of the entry
	$query = "SELECT user_status FROM Users WHERE user_id = " . $index;
	$result = ExecuteQuery($query);
	if ($actionRow = mysql_fetch_row($result)){
		$userStatus = $actionRow[0];
		if ($currentUserStatus == 1 || ($currentUserStatus < $userStatus && $currentUserStatus <= 3)){
			// A lower permission user cannot modify a higher permission user, or their own level
			$actionList = AddString($actionList, "<A HREF=user_change_status_init.php?index=" . $index . ">" . Translate("Change Status") . "</A>\n", " <B>|</B> ");
			$actionList = AddString($actionList, "<A HREF=user_reset_password_init.php?index=" . $index . ">" . Translate("Reset Password") . "</A>\n", " <B>|</B> ");
			$actionList = AddString($actionList, "<A HREF=edit_form_init.php?table=Users&index=" . $index . ">" . Translate("Edit") . "</A>\n", " <B>|</B> ");
		}
	}
	if ($currentUserStatus <= 2){
		// These actions are valid irregardless of relative access
		$actionList = AddString($actionList, "<A HREF=user_registrations.php?index=" . $index . ">" . Translate("Registrations") . "</A>\n", " <B>|</B> ");
		$actionList = AddString($actionList, "<A HREF=view_balance.php?index=" . $index . ">" . Translate("Balance History") . "</A>\n", " <B>|</B> ");
		$actionList = AddString($actionList, "<A HREF=enter_payment_init.php?index=" . $index . ">" . Translate("Enter Payment") . "</A>\n", " <B>|</B> ");
		$actionList = AddString($actionList, "<A HREF=enter_tshirt_fee_init.php?index=" . $index . ">" . Translate("Enter T-Shirt Fee") . "</A>\n", " <B>|</B> ");
		$actionList = AddString($actionList, "<A HREF=enter_adjustment_init.php?index=" . $index . ">" . Translate("Enter Adjustment") . "</A>\n", " <B>|</B> ");
	}
	if ($currentUserStatus <= 1){
		// Remove option (only available if all other connected entries are first removed)
		$removeable = true;
		$query = "SELECT reg_id FROM Registrations WHERE reg_user = " . $index;
		$result = ExecuteQuery($query);
		if (($actionRow = mysql_fetch_row($result))){
			$removeable = false;
		}
		$query = "SELECT note_id FROM UserNotes WHERE note_user = " . $index;
		$result = ExecuteQuery($query);
		if (($actionRow = mysql_fetch_row($result))){
			$removeable = false;
		}
		$query = "SELECT trans_id FROM Transactions WHERE trans_user = " . $index;
		$result = ExecuteQuery($query);
		if (($actionRow = mysql_fetch_row($result))){
			$removeable = false;
		}
		if ($removeable){
			$actionList = AddString($actionList, "<A HREF=remove_item_init.php?table=Users&index=" . $index . ">" . Translate("Remove") . "</A>\n", " <B>|</B> ");
		}
	}
	break;
case "Events":
	if ($currentUserStatus <= 2){
		// Options depend on event status
		$query = "SELECT event_completed, event_departed, event_cancelled FROM Events WHERE event_id = " . $index;
		$result = ExecuteQuery($query);
		if ($actionRow = mysql_fetch_row($result)){
			$completed = $actionRow[0];
			$departed = $actionRow[1];
			$cancelled = $actionRow[2];
			if (!$completed && !$cancelled){
				// Active event
				if ($departed){
					$actionList = AddString($actionList, "<A HREF=complete_event_init.php?index=" . $index . ">" . Translate("Complete") . "</A>\n", " <B>|</B> ");
				}
				else{
					$actionList = AddString($actionList, "<A HREF=depart_event_init.php?index=" . $index . ">" . Translate("Depart") . "</A>\n", " <B>|</B> ");
					$actionList = AddString($actionList, "<A HREF=cancel_event_init.php?index=" . $index . ">" . Translate("Cancel") . "</A>\n", " <B>|</B> ");
				}
			}
		}
		$actionList = AddString($actionList, "<A HREF=view_event_form.php?index=" . $index . ">" . Translate("Event Form") . "</A>\n", " <B>|</B> ");
		$actionList = AddString($actionList, "<A HREF=edit_event_registrations.php?index=" . $index . ">" . Translate("Edit Event Registrations") . "</A>\n", " <B>|</B> ");
	}
	if ($currentUserStatus <= 1){
		// Allow remove only if no registrations
		$removeable = true;
		$query = "SELECT reg_id FROM Registrations WHERE reg_event = " . $index;
		$result = ExecuteQuery($query);
		if (($actionRow = mysql_fetch_row($result))){
			$removeable = false;
		}
		if ($removeable){
			$actionList = AddString($actionList, "<A HREF=remove_item_init.php?table=Events&index=" . $index . ">" . Translate("Remove") . "</A>\n", " <B>|</B> ");
		}
	}
	// note no break.. event condition includes edit as well..
case "Languages":
case "Locations":
case "EventTypes":
case "Organizations":
	// Edit allowed
	$actionList = AddString($actionList, "<A HREF=edit_form_init.php?table=" . $tableName . "&index=" . $index . ">" . Translate("Edit") . "</A>\n", " <B>|</B> ");
	break;
case "Contacts":
	if ($currentUserStatus <= 1){
		// remove possible
		$actionList = AddString($actionList, "<A HREF=remove_item_init.php?table=Contacts&index=" . $index . ">" . Translate("Remove") . "</A>\n", " <B>|</B> ");
	}
	$actionList = AddString($actionList, "<A HREF=edit_form_init.php?table=" . $tableName . "&index=" . $index . ">" . Translate("Edit") . "</A>\n", " <B>|</B> ");
	break;
case "Transactions":
	// edit and remove allowed
	$actionList = AddString($actionList, "<A HREF=edit_form_init.php?table=" . $tableName . "&index=" . $index . ">" . Translate("Edit") . "</A>\n", " <B>|</B> ");
	$actionList = AddString($actionList, "<A HREF=remove_item_init.php?table=Transactions&index=" . $index . ">" . Translate("Remove") . "</A>\n", " <B>|</B> ");
	break;
default:
	break;
}

if ($actionList != ""){
	echo "<P ALIGN=CENTER>\n";
	echo $actionList;
	echo "</P>\n";
}

?>