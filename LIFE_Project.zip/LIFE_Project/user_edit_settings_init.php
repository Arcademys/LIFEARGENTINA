<?
include_once "header_system.php";
$pageTitle = Translate("Edit Settings");
include_once "header.php";

// Get user information
$fields = GetTableData("Users");
$query = GetSelectQuery($fields, "Users") . GetTableList("Users", $fields) . " WHERE user_id = " . $_SESSION['userid'];
$result = ExecuteQuery($query);
if ($row = mysql_fetch_row($result)){

	// Generate script to check that all required fields are filled
	echo "<SCRIPT>function CheckFormValid(){ " . GetRequiredCode($fields, "changeSettingsForm", false) . "return true; }</SCRIPT>\n";

	// Generate edit form
	echo "<FORM NAME=changeSettingsForm METHOD=POST ACTION=user_edit_settings_results.php>\n";
	echo "<P ALIGN=CENTER>* = " . Translate("Required Field") . "</P>\n";
	echo "<TABLE ALIGN=CENTER>\n";

	// Output edit form fields (function generates input fields automatically)
	echo GetFormData($fields, $row, true);

	echo "<TR><TD ALIGN=CENTER COLSPAN=2>\n";
	echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Cancel", 1) . "' onClick='window.location.href=\"user_view_settings.php\"'>" . Translate("Cancel", 2) . "\n";
	echo "<INPUT TYPE=SUBMIT ID=requiredButton VALUE='" . Translate("Save", 1) . "' onClick='return CheckFormValid();'>" . Translate("Save", 2) . "\n";
	echo "</TD></TR>\n";
	echo "</TABLE>\n";
	echo "</FORM>\n";

}
else{
	echo "<P ALIGN=CENTER>" . Translate("Error: Could not load settings") . "</P>\n";
}

include_once "footer.php";
?>

