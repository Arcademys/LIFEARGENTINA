<?
$pageTitle = "Login";
$loginSpecial = true;
if ($_GET['lang'] == "es"){
	$languageOverride = true;
}
include_once "header.php";

echo "<FORM NAME=loginForm METHOD=POST ACTION=login.php>\n";
echo "<TABLE ALIGN=CENTER>\n";
echo "<TR><TD ALIGN=RIGHT>" . Translate("Username") . ":</TD><TD><INPUT TYPE=TEXT NAME=username ID=focus></TD></TR>\n";
echo "<TR><TD ALIGN=RIGHT>" . Translate("Password") . ":</TD><TD><INPUT TYPE=PASSWORD NAME=password></TD></TR>\n";
echo "<TR><TD ALIGN=CENTER COLSPAN=2><INPUT TYPE=SUBMIT NAME=submit VALUE='" . Translate("Login", 1) . "'></TD></TR>\n";
echo "</TABLE>\n";

// Pass on lang and redirect variables
echo "<INPUT TYPE=HIDDEN NAME=lang VALUE='" . $_GET['lang'] . "'>\n";
echo "<INPUT TYPE=HIDDEN NAME=redirect VALUE='" . $_GET['redirect'] . "'>\n";

echo "</FORM>\n";

echo "<P ALIGN=CENTER><A HREF='user_register_init.php?lang=" . $_GET['lang'] . "'>" . Translate("Register") . "</A></P>\n";

// This string is set by login.php or logout.php when they include this page as a result
echo $indexErrorMsg;

include_once "footer_display.php";
?>