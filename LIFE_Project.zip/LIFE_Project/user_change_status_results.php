<?
$noRedirect = true;
$userNum = $_POST['index'];
include "header_system.php";

// Look up user name and status
$query = "SELECT user_fullname, user_status FROM Users WHERE user_id = " . $userNum;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	$pageTitle = Translate("Change Status Results") . " - " . Translate("Unknown User");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("User data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

$userName = $row[0];
$userStatus = $row[1];
$currentUserStatus = $_SESSION['userstatus'];
$newUserStatus = $_POST['newStatus'];

// Set page permissions so that only users of a higher level can change the status of a lower level (admins excepted)
if ($userStatus == 1 || $newUserStatus == 1){
	$pageStatus = 1;
}
else{
	// Set permission to lowest of the two statuses
	if ($userStatus < $newUserStatus){
		$pageStatus = $userStatus - 1;
	}
	else{
		$pageStatus = $newUserStatus - 1;
	}
}

if ($pageStatus > 3){
	// minimum access required to change status
	$pageStatus = 3;
}

$pageTitle = Translate("Change Status Results") . " - " . htmlspecialchars($userName);
include_once "header.php";

// Update status
$query = "UPDATE Users SET user_status = '" . $newUserStatus . "' WHERE user_id = " . $userNum;
if (ExecuteQuery($query)){
	$resultString = "Status Changed";
}
else{
	$resultString = "Failure - Could not change record";
}

echo "<P ALIGN=CENTER>" . Translate($resultString) . "</P>\n";
echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("Return", 1) . "' onClick='window.location.href=\"view_item.php?table=Users&index=" . $userNum . "\"'>" . Translate("Return", 2) . "</P>\n";

include_once "footer.php";
?>

