<?
$pageStatus = 2;

include_once "header_system.php";
$pageTitle = Translate("Add Translation");
include_once "header.php";

$fields = GetTableData("Languages");

// note that this page goes to default add_form_results.php
echo "<FORM NAME=addForm METHOD=POST ACTION=add_form_results.php>\n";
echo "<TABLE ALIGN=CENTER>\n";

// Load default value from passed phrase
$defaults[0] = UnsafeSingleQuotes($_GET['phrase']);

// Generate Add form
echo GetFormData($fields, $defaults, true);

echo "<TR><TD ALIGN=CENTER COLSPAN=2>\n";
echo "<INPUT TYPE=HIDDEN NAME=table VALUE='Languages'>\n";
echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Cancel", 1) . "' onClick='window.location.href=\"search_form.php?table=Languages\"'>" . Translate("Cancel", 2) . "\n";
echo "<INPUT TYPE=SUBMIT VALUE='" . Translate("Save", 1) . "'>" . Translate("Save", 2) . "\n";
echo "</TD></TR>\n";
echo "</TABLE>\n";
echo "</FORM>\n";

include_once "footer.php";
?>

