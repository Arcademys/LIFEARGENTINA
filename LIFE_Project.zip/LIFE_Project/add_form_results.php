<?
$noRedirect = true;
$pageStatus = 2;
$tableName = $_POST['table'];

include_once "header_system.php";
$pageTitle = Translate("Add " . GetSingular($tableName) . " Results");
include_once "header.php";

if ($tableName == "Users"){
	// Cannot add users with this interface
	echo "<P ALIGN=CENTER>" . Translate("Cannot add user with this form.. have user register from login page") . "</P>\n";
	include_once "footer.php";
	exit();
}

// Create and excute INSERT query
$query = GetInsertQuery(GetTableData($tableName), $tableName);
if (ExecuteQuery($query)){
	echo "<P ALIGN=CENTER>" . Translate(GetSingular($tableName) . " Added") . "</P>\n";
}

// Look up item ID
$query = "SELECT LAST_INSERT_ID() FROM " . $tableName;
if ($result = ExecuteQuery($query)){
	$row = mysql_fetch_row($result);
	$newItem = $row[0];
	if ($tableName == "Events" && $_POST['autocomplete']){
		// Update event name with autofill information (now that it is known for sure)
		$query = "UPDATE Events SET event_name = '" . GetEventNameAutoFillValue($newItem) . "' WHERE event_id = " . $newItem;
		ExecuteQuery($query);
	}
	// Allow a link to the new item
	echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("View " . GetSingular($tableName), 1) . "' onClick='window.location.href=\"view_item.php?table=" . $tableName . "&index=" . $newItem . "\"'>" . Translate("View " . GetSingular($tableName), 2) . "</P>\n";
}

include_once "footer.php";
?>

