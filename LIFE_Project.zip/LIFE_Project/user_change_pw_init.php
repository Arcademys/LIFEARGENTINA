<?
include_once "header_system.php";
$pageTitle = Translate("Change Password");
include_once "header.php";

// show dialog with old password, new password, and reentry of new password
echo "<FORM NAME=changePasswordForm METHOD=POST ACTION=user_change_pw_results.php>\n";
echo "<TABLE ALIGN=CENTER>\n";
echo "<TR><TD ALIGN=RIGHT>" . Translate("Old Password") . ":</TD><TD><INPUT TYPE=PASSWORD NAME=oldPassword ID=focus></TD></TR>\n";
echo "<TR><TD ALIGN=RIGHT>" . Translate("New Password") . ":</TD><TD><INPUT TYPE=PASSWORD NAME=newPassword></TD></TR>\n";
echo "<TR><TD ALIGN=RIGHT>" . Translate("New Password Again") . ":</TD><TD><INPUT TYPE=PASSWORD NAME=newPasswordRetry></TD></TR>\n";
echo "<TR><TD ALIGN=CENTER COLSPAN=2>\n";

// show confirmation dialog
echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Cancel", 1) . "' onClick='window.location.href=\"user_view_settings.php\"'>" . Translate("Cancel", 2) . "\n";
echo "<INPUT TYPE=SUBMIT NAME=submit VALUE='" . Translate("Change Password", 1) . "'>" . Translate("Change Password", 2) . "\n";
echo "</TD></TR>\n";
echo "</TABLE>\n";
echo "</FORM>\n";

include_once "footer.php";
?>

