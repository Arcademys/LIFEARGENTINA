
<?
mysql_close();
?>
