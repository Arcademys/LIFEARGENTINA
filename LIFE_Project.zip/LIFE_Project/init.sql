
INSERT INTO Users(user_name, user_password, user_fullname, user_status, user_passport, user_email, user_emergency_contact_name, user_emergency_contact_phone) values ("admin", "21232f297a57a5a743894a0e4a801fc3", "Administrator", 1, "NA", "admin@lifeargentina.org", "NA", "NA");

INSERT INTO Locations(loc_name, loc_desc) values ("LIFE Office", "The LIFE offices at Pe�a 2121");
INSERT INTO EventTypes(type_name, type_desc) values ("School Support", "Helping the kids with their homework");
INSERT INTO Organizations(org_id, org_name, org_notes) values (1, "No Organization", "Came to LIFE directly");

INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Active Admin", 1, "user_status");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Active Intern", 2, "user_status");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Active Coordinator", 3, "user_status");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Active Volunteer", 4, "user_status");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Future Admin", 5, "user_status");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Future Intern", 6 "user_status");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Future Coordinator", 7, "user_status");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Future Volunteer", 8, "user_status");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Past Admin", 9, "user_status");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Past Intern", 10, "user_status");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Past Coordinator", 11, "user_status");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Past Volunteer", 12, "user_status");

INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Event Fee", 1, "trans_type");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Payment", 2, "trans_type");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Adjustment", 3, "trans_type");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("T-Shirt Fee", 4, "trans_type");

INSERT INTO Choices(choice_text, choice_value, choice_field) values ("English", 1, "user_lang");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Espanol", 2, "user_lang");

INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Male", 1, "user_gender");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Female", 2, "user_gender");

INSERT INTO Choices(choice_text, choice_value, choice_field) values ("North America", 1, "user_region");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Latin America", 2, "user_region");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Europe", 3, "user_region");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Asia", 4, "user_region");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Africa", 5, "user_region");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Oceania", 6, "user_region");

INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Single", 1, "user_marital_status");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Married", 2, "user_marital_status");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Divorced", 3, "user_marital_status");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Widowed", 4, "user_marital_status");

INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Christian", 1, "user_religion");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Muslim", 2, "user_religion");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Jewish", 3, "user_religion");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("None", 4, "user_religion");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Other", 5, "user_religion");

INSERT INTO Choices(choice_text, choice_value, choice_field) values ("None", 1, "user_spanish_level");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Basic", 2, "user_spanish_level");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Conversational", 3, "user_spanish_level");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Fluent", 4, "user_spanish_level");

INSERT INTO Choices(choice_text, choice_value, choice_field) values ("High School", 1, "user_education_level");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Uncompleted Degree", 2, "user_education_level");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Bachelors Degree", 3, "user_education_level");
INSERT INTO Choices(choice_text, choice_value, choice_field) values ("Masters Degree", 4, "user_education_level");

