<?
$noRedirect = true;
$index = $_POST['index'];
include "header_system.php";

$pageStatus = 2;

$query = "SELECT event_name, event_coordinator FROM Events WHERE event_cancelled = 0 AND event_completed = 0 AND event_departed = 1 AND event_id = " . $index;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	// The requested event does not exist, or is not valid for completion

	$pageTitle = Translate("Complete Event") . " - " . Translate("Invalid");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("Event data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

// This page is more permissive if the current user is the event coordinator
if ($row[1] == $_SESSION["userid"]){
	$pageStatus = 3;
}

$eventName = $row[0];

$pageTitle = Translate("Complete Event Results") . " - " . htmlspecialchars($eventName);
include_once "header.php";

// Execute query to set event as completed, and set notes and return time
$query = "UPDATE Events SET event_completed = 1, event_actual_return_time = '" . strftime("%Y-%m-%d %T", strtotime($_POST["actual_return_day"] . " " . $_POST["actual_return_time"])) . "', event_completed_by = " . $_SESSION["userid"] . ", event_notes = '" . $_POST["notes"] . "' WHERE event_id = " . $index;
if (ExecuteQuery($query)){
	$resultString = "Event Completed";
}
else{
	$resultString = "Failure - Could not change record";
}

echo "<P ALIGN=CENTER>" . Translate($resultString) . "</P>\n";
echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("Return", 1) . "' onClick='window.location.href=\"view_item.php?table=Events&index=" . $index . "\"'>" . Translate("Return", 2) . "</P>\n";

include_once "footer.php";
?>

