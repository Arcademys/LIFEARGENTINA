<?
// This page creates a list of comma separated email addresses from a user search

$pageStatus = 2;

include_once "header_system.php";
$pageTitle = Translate("Email List");
include_once "header.php";

$tableName = $_GET["table"];
$tableData = GetTableData($tableName);

// load criteria from search form
$numCriteria = $_GET['numCriteria'];
if (!$numCriteria){
	$numCriteria = 0;
}
for ($i = 0; $i < $numCriteria; $i++){
	$searchData[$i]["field"] = $_GET["criteria" . $i . "field"];
	if (!$searchData[$i]["field"]){
		$searchData[$i]["field"] = 0;
	}
	$searchData[$i]["function"] = $_GET["criteria" . $i . "function"];
	if (!$searchData[$i]["function"]){
		$searchData[$i]["function"] = 0;
	}
	$searchData[$i]["value"] = $_GET["criteria" . $i . "value"];
}

echo "<P ALIGN=CENTER><B>" . Translate("Filter Criteria") . ":</B><BR>\n";

$numFields = count($tableData);

// display criteria used in search
for ($i = 0; $i < $numCriteria; $i++){

	// output field name
	echo Translate($tableData[$searchData[$i]["field"]]["name"]) . "\n";

	// output search function (uses an empty tag and a javascript fill function)
	echo "<A ID=value" . $i . "></A>\n";  // empty tag

	// Script to fill empty tag
	echo "<SCRIPT>\n";
	echo "document.getElementById('value" . $i . "').innerHTML = GetFunctionText(" . $tableData[$searchData[$i]["field"]]["type"] . ", " . $searchData[$i]["function"] . ");";
	echo "</SCRIPT>\n";

	// output search value
	echo $searchData[$i]["value"];
	echo "<BR>\n";
}
if ($numCriteria == 0){
	echo Translate("No criteria specified (full list displayed)") . "<BR>\n";
}
echo "</P>\n";

echo "<HR>\n";

// determine field from table
if ($tableName == "Contacts"){
	$selectChoices = "a.contact_email";
}
else{
	$selectChoices = "a.user_email";
}

// Get list of emails
$query = "SELECT " . $selectChoices . GetTableList($tableName, $tableData) . GetWhereConditions($tableData, $searchData, $numCriteria);
$result = ExecuteQuery($query);

// output email list
echo "<P ALIGN=CENTER>\n";
$noResults = true;
while ($row = mysql_fetch_row($result)){
	if ($noResults){
		$noResults = false;
	}
	else{
		echo ", ";
	}
	echo $row[0];
}
if ($noResults){
	echo Translate("No " . GetPlural($tableName) . " Found") . "\n";
}
echo "</P>\n";


include_once "footer.php";
?>

