<?
$loginSpecial = true;
include_once "header_system.php";
$fields = GetTableData("Users");
if ($_GET['lang'] == "es"){
	$languageOverride = true;
	// Set Spanish as default choice
	$defaults[GetFieldIndex($fields, "user_lang")] = "Espa�ol";
}
else{
	// Set English as default choice
	$defaults[GetFieldIndex($fields, "user_lang")] = "English";
}
$pageTitle = Translate("Register");
include_once "header.php";

// Script to validate form before submission
// Note that password fields are done separately from other fields
echo "<SCRIPT>function CheckFormValid(){ " . GetRequiredCode($fields, "registerUserForm") . "if (document.registerUserForm.password.value == \"\"){alert(\"Must enter value for Password\"); document.registerUserForm.password.focus(); return false;} if (document.registerUserForm.passwordRetry.value == \"\"){alert(\"Must enter value for Password Again\"); document.registerUserForm.passwordRetry.focus(); return false;}  return true; }</SCRIPT>\n";

echo "<FORM NAME=registerUserForm ID=registerUserForm METHOD=POST ACTION=user_register_results.php>\n";
echo "<P ALIGN=CENTER>* = " . Translate("Required Field") . "</P>\n";
echo "<TABLE ALIGN=CENTER>\n";

// Output form to ask users to enter their information
echo GetFormData($fields, $defaults, true, false, "Users", -1, false, true);

// Add password fields to form (not included in table data)
echo "<TR><TD ALIGN=RIGHT><B>" . Translate("Password") . ":</B></TD><TD><INPUT TYPE=PASSWORD NAME=password> *</TD></TR>\n";
echo "<TR><TD ALIGN=RIGHT><B>" . Translate("Password Again") . ":</B></TD><TD><INPUT TYPE=PASSWORD NAME=passwordRetry> *</TD></TR>\n";
echo "<TR><TD ALIGN=CENTER COLSPAN=2>\n";
echo "<INPUT TYPE=HIDDEN NAME=lang VALUE='" . $_GET['lang'] . "'>\n";
echo "<INPUT TYPE=SUBMIT ID=requiredButton VALUE='" . Translate("Register", 1) . "' onClick='return CheckFormValid();'>\n";
echo "</TD></TR>\n";
echo "</TABLE>\n";
echo "</FORM>\n";

include_once "footer_display.php";
?>

