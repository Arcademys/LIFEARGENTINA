<?
$noRedirect = true;
$index = $_POST['index'];
include "header_system.php";

$pageStatus = 2;

$query = "SELECT event_name FROM Events WHERE event_cancelled = 0 AND event_completed = 0 AND event_departed = 0 AND event_id = " . $index;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	// The requested event does not exist, or is not valid for departure

	$pageTitle = Translate("Depart Event") . " - " . Translate("Invalid");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("Event data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

$eventName = $row[0];

$pageTitle = Translate("Depart Event Results") . " - " . htmlspecialchars($eventName);
include_once "header.php";

// Execute query to set event as departed
$query = "UPDATE Events SET event_departed = 1, event_actual_departure_time = CURRENT_TIMESTAMP WHERE event_id = " . $index;
if (ExecuteQuery($query)){
	$resultString = "Event Departed";
}
else{
	$resultString = "Failure - Could not change record";
}

// Get a list of registered users for the event
$tableData = GetTableData("SmallUsers");
$query = GetSelectQuery($tableData, "SmallUsers") . GetTableList("SmallUsers", $tableData) . " LEFT OUTER JOIN Registrations AS b ON (a.user_id = b.reg_user AND b.reg_event = " . $index . " AND b.reg_cancelled = 0) WHERE b.reg_id IS NOT NULL ORDER BY b.reg_date_created ASC";
$result = ExecuteQuery($query);

while ($row = mysql_fetch_row($result)){
	// check if the user was marked present...
	$thisIndex = $row[count($row) - 1];
	if ($_POST["item" . $thisIndex]){
		// user was present, mark as attended
		$query = "UPDATE Registrations SET reg_attended = 1 WHERE reg_cancelled = 0 AND reg_event = " . $index . " AND reg_user = " . $thisIndex;
		ExecuteQuery($query);
	}
	else{
		// user was not present, cancel registration
		$query = "UPDATE Registrations SET reg_cancelled = 1 WHERE reg_cancelled = 0 AND reg_event = " . $index . " AND reg_user = " . $thisIndex;
		ExecuteQuery($query);
	}
}

echo "<P ALIGN=CENTER>" . Translate($resultString) . "</P>\n";
echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("Return", 1) . "' onClick='window.location.href=\"view_item.php?table=Events&index=" . $index . "\"'>" . Translate("Return", 2) . "</P>\n";

include_once "footer.php";
?>

