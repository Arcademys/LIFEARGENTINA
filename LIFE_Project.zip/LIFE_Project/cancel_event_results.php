<?
$noRedirect = true;
$index = $_POST['index'];
include "header_system.php";
$pageStatus = 2;

$query = "SELECT event_name FROM Events WHERE event_cancelled = 0 AND event_completed = 0 AND event_departed = 0 AND event_id = " . $index;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	// The requested event does not exist, or is not valid for cancellation

	$pageTitle = Translate("Cancel Event") . " - " . Translate("Invalid");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("Event data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

$eventName = $row[0];

$pageTitle = Translate("Cancel Event Results") . " - " . htmlspecialchars($eventName);
include_once "header.php";

// Get the list of registered users for event
$tableData = GetTableData("SmallUsers");
$query = GetSelectQuery($tableData, "SmallUsers") . GetTableList("SmallUsers", $tableData) . " LEFT OUTER JOIN Registrations AS b ON (a.user_id = b.reg_user AND b.reg_event = " . $index . " AND b.reg_cancelled = 0) WHERE b.reg_id IS NOT NULL ORDER BY b.reg_date_created ASC";
$result = ExecuteQuery($query);

// Display a table of users who should be warned about the event cancellation
$warnUsers = "";
$noResults = true;
while ($row = mysql_fetch_row($result)){
	$thisIndex = $row[count($row) - 1];
	if ($noResults){
		$warnUsers .= "<P ALIGN=CENTER>" . Translate("The following users should be warned about the cancellation") . ":</P>\n";
		$warnUsers .= "<TABLE BGCOLOR=" . $tableBGColor . " CELLPADDING=5 ALIGN=CENTER>\n";
		$warnUsers .= GetHeaderRow($tableData);
		$noResults = false;
	}
	$warnUsers .= GetFormData($tableData, $row, false, true, "Users", $thisIndex);
}
if (!$noResults){
	$warnUsers .= "</TABLE>\n";
}

// Execute query to set event as cancelled
$query = "UPDATE Events SET event_cancelled = 1, event_cancellation_time = CURRENT_TIMESTAMP, event_cancelled_by = " . $_SESSION["userid"] . " WHERE event_id = " . $index;
if (ExecuteQuery($query)){
	$resultString = "Event Cancelled";
}
else{
	$resultString = "Failure - Could not change record";
}

// Cancel all assicated registrations
$query = "UPDATE Registrations SET reg_cancelled = 1, reg_cancellation_time = CURRENT_TIMESTAMP, reg_cancelled_by = " . $_SESSION["userid"] . " WHERE reg_event = " . $index;
ExecuteQuery($query);

// Get a list of transactions associated with this event
$query = "SELECT trans_user, trans_amount_usd, trans_amount_arg FROM Transactions WHERE trans_type = 1 AND trans_reference = " . $index;
$result = ExecuteQuery($query);
while ($row = mysql_fetch_row($result)){
	// undo transaction charge (subtract transaction balance)
	$query = "UPDATE Users SET user_balance_usd = user_balance_usd - " . $row[1] . ", user_balance_arg = user_balance_arg - " . $row[2] . " WHERE user_id = " . $row[0];
	ExecuteQuery($query);
}

// Remove transactions
$query = "DELETE FROM Transactions WHERE trans_type = 1 AND trans_reference = " . $index;
ExecuteQuery($query);

echo "<P ALIGN=CENTER>" . Translate($resultString) . "</P>\n";
echo $warnUsers;
echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("Return", 1) . "' onClick='window.location.href=\"view_item.php?table=Events&index=" . $index . "\"'>" . Translate("Return", 2) . "</P>\n";

include_once "footer.php";
?>

