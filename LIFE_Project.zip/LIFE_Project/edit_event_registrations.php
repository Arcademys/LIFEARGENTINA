<?
$pageStatus = 2;
$index = $_GET['index'];

include_once "header_system.php";
$pageTitle = Translate("Edit Event Registrations");
include_once "header.php";

// form links back to this page
echo "<FORM NAME=eventRegistrationForm METHOD=POST ACTION=edit_event_registrations.php?index=" . $index . ">\n";

if ($_POST["addUser"] != ""){
	$userNum = $_POST["addUserNum"];

	$query = "SELECT event_cost_usd, event_cost_arg FROM Events WHERE event_id = " . $index;
	$result = ExecuteQuery($query);
	$row = mysql_fetch_row($result);

	$costUSD = $row[0];
	$costARG = $row[1];

	// Get the user name, and determine if they have unlimited (free) registrations
	$query = "SELECT a.user_fullname, b.org_unlimited FROM Users AS a LEFT OUTER JOIN Organizations AS b ON (a.user_org = b.org_id) WHERE a.user_id = " . $userNum;
	$result = ExecuteQuery($query);
	$row = mysql_fetch_row($result);

	$userName = $row[0];
	$freeEvents = $row[1]; // This user does not pay for events

	// Check if user has previously created and cancelled a registration for this event
	$query = "SELECT a.event_name, c.reg_id FROM SmallEvents AS a LEFT OUTER JOIN Registrations AS b ON (a.event_id = b.reg_event AND b.reg_user = " . $userNum . " AND b.reg_cancelled = 0) LEFT OUTER JOIN Registrations AS c ON (a.event_id = c.reg_event AND c.reg_user = " . $userNum . " AND c.reg_cancelled = 1) WHERE b.reg_id IS NULL AND a.event_id = " . $index;
	$innerResult = ExecuteQuery($query);
	if ($innerRow = mysql_fetch_row($innerResult)){
		if ($innerRow[1]){
			// Delete cancelled registration for event, if present
			$query = "DELETE FROM Registrations WHERE reg_id = " . $innerRow[1];
			ExecuteQuery($query);
		}

		// Add a new registration
		$query = "INSERT INTO Registrations(reg_user, reg_event, reg_created_by, reg_free) VALUES (" . $userNum . ", " . $index . ", " . $_SESSION["userid"] . ", " . $freeEvents . ")";
		if (ExecuteQuery($query)){
			$actionText .= "<P ALIGN=CENTER><B>" . Translate("Registration added for") . ":</B> " . $userName . "</P>\n";
		}

		if (!$freeEvents){
			// User pays for events, so add a transaction
			$query = "INSERT INTO Transactions(trans_user, trans_type, trans_reference, trans_amount_usd, trans_amount_arg, trans_created_by) VALUES (" . $userNum . ", 1, " . $index . ", " . $costUSD . ", " . $costARG . ", " . $_SESSION["userid"] . ")";
			ExecuteQuery($query);

			// Update balance to reflect transaction
			$query = "UPDATE Users SET user_balance_usd = user_balance_usd + " . $costUSD . ", user_balance_arg = user_balance_arg + " . $costARG . " WHERE user_id = " . $userNum;
			ExecuteQuery($query);
		}

	}

}

// Generate query to get list of registrations
$tableData = GetTableData("SmallUsers");
$query = GetSelectQuery($tableData, "SmallUsers") . ", b.reg_cancelled" . GetTableList("SmallUsers", $tableData) . " LEFT OUTER JOIN Registrations AS b ON (a.user_id = b.reg_user AND b.reg_event = " . $index . ") WHERE b.reg_id IS NOT NULL ORDER BY b.reg_date_created ASC";
$result = ExecuteQuery($query);

// Show results
$noResults = true;
echo "<P ALIGN=CENTER><B>" . Translate("Registered Users") . ":</B></P>\n";
while ($row = mysql_fetch_row($result)){
	$thisIndex = $row[count($row) - 2];
	$cancelled = $row[count($row) - 1];

	if ($_POST["item$thisIndex"] == "SET" && $_POST["removeUsers"] != ""){
		// Remove user registration

		// Look up user registration, and verify that the deadline has not passed
		$query = "SELECT a.event_name, b.reg_id, a.event_registration_deadline > CURRENT_TIMESTAMP FROM SmallEvents AS a LEFT OUTER JOIN Registrations AS b ON (a.event_id = b.reg_event AND b.reg_user = " . $thisIndex . " AND b.reg_cancelled = 0) WHERE b.reg_id IS NOT NULL AND a.event_id = " . $index;
		$innerResult = ExecuteQuery($query);
		if ($innerRow = mysql_fetch_row($innerResult)){
			// Cancel registration
			$query = "UPDATE Registrations SET reg_cancelled = 1, reg_cancelled_by = " . $_SESSION["userid"] . ", reg_cancellation_time = CURRENT_TIMESTAMP WHERE reg_id = " . $innerRow[1];
			$cancelled = true;

			if ($innerRow[2] || $_POST["refund"] == "Yes"){
				// not past deadline, or refund desired, so refund registration fee

				if (ExecuteQuery($query)){
					$actionText .= "<P ALIGN=CENTER><B>" . Translate("Registration cancelled for") . ":</B> " . $row[0] . "<BR>" . Translate("Event Fee Refunded") . "</P>\n";
				}

				// Get registration fee amount
				$query = "SELECT trans_amount_usd, trans_amount_arg FROM Transactions WHERE trans_user = " . $thisIndex . " AND trans_type = 1 AND trans_reference = " . $index;
				$insideResult = ExecuteQuery($query);
				if ($insideRow = mysql_fetch_row($insideResult)){
					$rebateCostUSD = $insideRow[0];
					$rebateCostARG = $insideRow[1];
				}
				else{
					$rebateCostUSD = 0;
					$rebateCostARG = 0;
				}

				// Remove registration fee transaction
				$query = "DELETE FROM Transactions WHERE trans_user = " . $thisIndex . " AND trans_type = 1 AND trans_reference = " . $index;
				ExecuteQuery($query);

				// Update balance (subtract fee amount)
				$query = "UPDATE Users SET user_balance_usd = user_balance_usd - " . $rebateCostUSD . ", user_balance_arg = user_balance_arg - " . $rebateCostARG . " WHERE user_id = " . $thisIndex;
				ExecuteQuery($query);
			}
			else{
				// Deadline passed, so do not refund fee
				if (ExecuteQuery($query)){
					$actionText .= "<P ALIGN=CENTER><B>" . Translate("Registration cancelled for") . ":</B> " . $row[0] . "<BR>" . Translate("Event Fee NOT Refunded (deadline passed)") . "</P>\n";
				}
			}
		}
	}

	if ($noResults){
		echo "<TABLE BGCOLOR=" . $tableBGColor . " CELLPADDING=5 ALIGN=CENTER>\n";
		echo GetHeaderRow($tableData, true, "Remove");
		$noResults = false;
	}
	echo GetFormData($tableData, $row, true, true, "Users", $thisIndex, $cancelled);
}
if (!$noResults){
	echo "</TABLE>\n";

	// Show dialog to remove users
	echo "<P ALIGN=CENTER>Refund Event Fee (overrides deadline)?\n";
	echo "<INPUT TYPE=CHECKBOX NAME=refund VALUE=Yes";
	if ($_POST["refund"] == "Yes"){
		echo " CHECKED";
	}
	echo ">\n";
	echo "<INPUT TYPE=SUBMIT NAME=removeUsers VALUE='Remove Users'></P>\n";
}
else{
	echo "<P ALIGN=CENTER>" . Translate("No users registered") . "</P>\n";
}

$query = "SELECT a.user_id, a.user_fullname FROM Users AS a LEFT OUTER JOIN Registrations AS b ON (b.reg_event = " . $index . " AND b.reg_user = a.user_id AND b.reg_cancelled = 0) WHERE a.user_status <= 4 AND b.reg_id IS NULL ORDER BY a.user_fullname ASC";
$result = ExecuteQuery($query);
$noResults = true;
while ($row = mysql_fetch_row($result)){
	if ($noResults){
		echo "<P ALIGN=CENTER><B>Add user</B>:\n";
		echo "<SELECT NAME=addUserNum>\n";
		$noResults = false;
	}
	echo "<OPTION VALUE=" . $row[0] . ">" . $row[1] . "</OPTION>\n";
}
if (!$noResults){
	echo "</SELECT>\n";
	echo "<INPUT TYPE=SUBMIT NAME=addUser VALUE=Add></P>\n";
}

echo $actionText;

echo "</FORM>\n";

include_once "footer.php";
?>

