<?
$pageStatus = 1;

include_once "header_system.php";

// Get user name and balance
$userNum = $_GET['index'];
$query = "SELECT user_fullname, FORMAT(ROUND(user_balance_usd, 2), 2), FORMAT(ROUND(user_balance_arg, 2), 2) FROM Users WHERE user_id = " . $userNum;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	$pageTitle = Translate("Enter Adjustment") . " - " . Translate("Unknown User");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("User data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

$userName = $row[0];
$usd = $row[1];
$arg = $row[2];

$pageTitle = Translate("Enter Adjustment") . " - " . htmlspecialchars($userName);
include_once "header.php";

// Show current user balance, and allow user to insert adjustment amount
echo "<FORM NAME=enterAdjustmentForm METHOD=POST ACTION=enter_adjustment_results.php>\n";
echo "<TABLE ALIGN=CENTER>\n";
echo "<TR><TD></TD><TD ALIGN=CENTER><B>US Dollars</B></TD><TD ALIGN=CENTER><B>ARG Pesos</B></TD></TR>\n";
echo "<TR><TD><B>" . Translate("Current Balance") . ":</B></TD><TD ALIGN=LEFT>" . $usd . "</TD><TD ALIGN=LEFT>" . $arg . "</TD></TR>\n";
echo "<TR><TD><B>" . Translate("Adjustment") . ":</B></TD><TD ALIGN=LEFT><INPUT TYPE=TEXT SIZE=7 NAME=usd VALUE='0'></TD><TD ALIGN=LEFT><INPUT TYPE=TEXT SIZE=7 NAME=arg VALUE='0'></TD></TR>\n";
echo "</TABLE>\n";

// show confirmation dialog and notes
echo "<P ALIGN=CENTER>" . Translate("Notes") . ": <INPUT TYPE=TEXT NAME=notes VALUE='' SIZE=30></P>\n";
echo "<P ALIGN=CENTER><INPUT TYPE=HIDDEN NAME=index VALUE=" . $userNum . ">\n";
echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Cancel", 1) . "' onClick='window.location.href=\"view_item.php?table=Users&index=" . $userNum . "\"'>" . Translate("Cancel", 2) . "\n";
echo "<INPUT TYPE=SUBMIT NAME=submit VALUE='" . Translate("Enter Adjustment", 1) . "'>" . Translate("Enter Adjustment", 2) . "</P>\n";
echo "</FORM>\n";

include_once "footer.php";
?>

