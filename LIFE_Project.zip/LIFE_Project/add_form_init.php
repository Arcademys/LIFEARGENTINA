<?
$pageStatus = 2;
$tableName = $_GET['table'];

include_once "header_system.php";
$pageTitle = Translate("Add " . GetSingular($tableName));
include_once "header.php";

if ($tableName == "Users"){
	// Cannot add users with this interface
	echo "<P ALIGN=CENTER>" . Translate("Cannot add user with this form.. have user register from login page") . "</P>\n";
	include_once "footer.php";
	exit();
}

$fields = GetTableData($tableName);

// Generate form
echo "<FORM NAME=addForm METHOD=POST ACTION=add_form_results.php>\n";
echo "<TABLE ALIGN=CENTER>\n";

// This function puts together the form fields automatically
echo GetFormData($fields, null, true);

echo "<TR><TD ALIGN=CENTER COLSPAN=2>\n";
echo "<INPUT TYPE=HIDDEN NAME=table VALUE='" . $tableName . "'>\n";
echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Cancel", 1) . "' onClick='window.location.href=\"search_form.php?table=" . $tableName . "\"'>" . Translate("Cancel", 2) . "\n";
echo "<INPUT TYPE=SUBMIT VALUE='" . Translate("Save", 1) . "'>" . Translate("Save", 2) . "\n";
echo "</TD></TR>\n";
echo "</TABLE>\n";
echo "</FORM>\n";

include_once "footer.php";
?>

