<?
include_once "header_system.php";

// Get user name and status
$userNum = $_GET['index'];
$query = "SELECT user_fullname, user_status FROM Users WHERE user_id = " . $userNum;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	$pageTitle = Translate("Reset Password") . " - " . Translate("Unknown User");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("User data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

$userName = $row[0];
$userStatus = $row[1];
$currentUserStatus = $_SESSION['userstatus'];

// This page is only available to users of a higher status, or admins
if ($userStatus == 1){
	$pageStatus = 1;
}
else{
	$pageStatus = $userStatus - 1;
}

if ($pageStatus > 3){
	// minimum access required to reset password
	$pageStatus = 3;
}

$pageTitle = Translate("Reset Password") . " - " . htmlspecialchars($userName);
include_once "header.php";

// Show user name, and allow entry of new password
echo "<FORM NAME=resetPasswordForm METHOD=POST ACTION=user_reset_password_results.php>\n";
echo "<TABLE ALIGN=CENTER>\n";
echo "<TR><TD ALIGN=RIGHT>" . Translate("Full Name") . ":</TD><TD>" . htmlspecialchars($userName) . "</TD></TR>\n";
echo "<TR><TD ALIGN=RIGHT>" . Translate("New Password") . ":</TD><TD><INPUT ID=focus TYPE=PASSWORD NAME=newPassword VALUE=''></TD></TR>\n";
echo "<TR><TD ALIGN=CENTER COLSPAN=2>\n";
echo "<INPUT TYPE=HIDDEN NAME=index VALUE=" . $userNum . ">\n";

// show confirmation dialog
echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Cancel", 1) . "' onClick='window.location.href=\"view_item.php?table=Users&index=" . $userNum . "\"'>" . Translate("Cancel", 2) . "\n";
echo "<INPUT TYPE=SUBMIT NAME=submit VALUE='" . Translate("Reset Password", 1) . "'>" . Translate("Reset Password", 2) . "\n";
echo "</TD></TR>\n";
echo "</TABLE>\n";
echo "</FORM>\n";

include_once "footer.php";
?>

