<?
include_once "header_system.php";

$pageStatus = 1;

$index = $_GET["index"];
$table = $_GET["table"];

// The following queries check to see if the item to be removed is connected to anything as a parent
// They also check that the requested item exists
if ($table == "Events"){
	$query = "SELECT reg_id FROM Registrations WHERE reg_event = " . $index;
	$result = ExecuteQuery($query);
	if (($row = mysql_fetch_row($result))){
		$pageTitle = Translate("Remove Event") . " - " . Translate("Invalid");
		include_once "header.php";
		echo "<P ALIGN=CENTER>" . Translate("Event cannot be removed - Registrations exist") . "</P>\n";
		include_once "footer.php";
		exit();
	}

	$query = "SELECT event_name FROM Events WHERE event_id = " . $index;
	$result = ExecuteQuery($query);
	if (!($row = mysql_fetch_row($result))){
		$pageTitle = Translate("Remove Event") . " - " . Translate("Invalid");
		include_once "header.php";
		echo "<P ALIGN=CENTER>" . Translate("Event data could not be retrieved") . "</P>\n";
		include_once "footer.php";
		exit();
	}
}
else if ($table == "Users"){
	$query = "SELECT reg_id FROM Registrations WHERE reg_user = " . $index;
	$result = ExecuteQuery($query);
	if (($row = mysql_fetch_row($result))){
		$pageTitle = Translate("Remove User") . " - " . Translate("Invalid");
		include_once "header.php";
		echo "<P ALIGN=CENTER>" . Translate("User cannot be removed - Registrations exist") . "</P>\n";
		include_once "footer.php";
		exit();
	}

	$query = "SELECT note_id FROM UserNotes WHERE note_user = " . $index;
	$result = ExecuteQuery($query);
	if (($row = mysql_fetch_row($result))){
		$pageTitle = Translate("Remove User") . " - " . Translate("Invalid");
		include_once "header.php";
		echo "<P ALIGN=CENTER>" . Translate("User cannot be removed - Notes exist") . "</P>\n";
		include_once "footer.php";
		exit();
	}

	$query = "SELECT trans_id FROM Transactions WHERE trans_user = " . $index;
	$result = ExecuteQuery($query);
	if (($row = mysql_fetch_row($result))){
		$pageTitle = Translate("Remove User") . " - " . Translate("Invalid");
		include_once "header.php";
		echo "<P ALIGN=CENTER>" . Translate("User cannot be removed - Transactions exist") . "</P>\n";
		include_once "footer.php";
		exit();
	}

	$query = "SELECT user_fullname FROM Users WHERE user_id = " . $index;
	$result = ExecuteQuery($query);
	if (!($row = mysql_fetch_row($result))){
		$pageTitle = Translate("Remove User") . " - " . Translate("Invalid");
		include_once "header.php";
		echo "<P ALIGN=CENTER>" . Translate("User data could not be retrieved") . "</P>\n";
		include_once "footer.php";
		exit();
	}
}
else if ($table == "Contacts"){
	$query = "SELECT contact_name FROM Contacts WHERE contact_id = " . $index;
	$result = ExecuteQuery($query);
	if (!($row = mysql_fetch_row($result))){
		$pageTitle = Translate("Remove Contact") . " - " . Translate("Invalid");
		include_once "header.php";
		echo "<P ALIGN=CENTER>" . Translate("Contact data could not be retrieved") . "</P>\n";
		include_once "footer.php";
		exit();
	}
}
else if ($table == "Transactions"){
	$query = "SELECT trans_date FROM Transactions WHERE trans_id = " . $index;
	$result = ExecuteQuery($query);
	if (!($row = mysql_fetch_row($result))){
		$pageTitle = Translate("Remove Transaction") . " - " . Translate("Invalid");
		include_once "header.php";
		echo "<P ALIGN=CENTER>" . Translate("Transaction data could not be retrieved") . "</P>\n";
		include_once "footer.php";
		exit();
	}
}
else{
	// not allowed to remove by default - must be one of the above tables

	$pageTitle = Translate("Remove " . GetSingular($table)) . " - " . Translate("Invalid");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("This type of record cannot be removed") . "</P>\n";
	include_once "footer.php";
	exit();
}

$itemName = $row[0];

$pageTitle = Translate("Remove " . GetSingular($table)) . " - " . htmlspecialchars($itemName);
include_once "header.php";

// Generate confirm dialog
echo "<FORM NAME=removeItemForm METHOD=POST ACTION=remove_item_results.php>\n";
echo "<P ALIGN=CENTER>" . Translate("Are you sure?  This action cannot be undone.") . "<BR>\n";
echo "<INPUT TYPE=HIDDEN NAME=index VALUE=" . $index . ">\n";
echo "<INPUT TYPE=HIDDEN NAME=table VALUE=" . $table . ">\n";
echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Return", 1) . "' onClick='window.location.href=\"view_item.php?table=" . $table . "&index=" . $index . "\"'>" . Translate("Return", 2) . "\n";
echo "<INPUT TYPE=SUBMIT NAME=submit VALUE='" . Translate("Remove " . GetSingular($table), 1) . "'>" . Translate("Remove " . GetSingular($table), 2) . "\n";
echo "</P>\n";
echo "</FORM>\n";

include_once "footer.php";
?>

