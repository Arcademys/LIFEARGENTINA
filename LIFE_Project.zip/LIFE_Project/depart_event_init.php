<?
include_once "header_system.php";

$pageStatus = 2;

$index = $_GET["index"];

$query = "SELECT event_name FROM Events WHERE event_cancelled = 0 AND event_completed = 0 AND event_departed = 0 AND event_id = " . $index;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	// The requested event does not exist, or is not valid for departure

	$pageTitle = Translate("Depart Event") . " - " . Translate("Invalid");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("Event data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

$eventName = $row[0];

$pageTitle = Translate("Depart Event") . " - " . htmlspecialchars($eventName);
include_once "header.php";

echo "<FORM NAME=departEventForm METHOD=POST ACTION=depart_event_results.php>\n";

// Get data on registered users
$tableData = GetTableData("SmallUsers");
$query = GetSelectQuery($tableData, "SmallUsers") . ", b.reg_cancelled" . GetTableList("SmallUsers", $tableData) . " LEFT OUTER JOIN Registrations AS b ON (a.user_id = b.reg_user AND b.reg_event = " . $index . ") WHERE b.reg_id IS NOT NULL ORDER BY b.reg_date_created ASC";
$result = ExecuteQuery($query);

// Show a table of registered users, with a checkbox to mark them as present
$noResults = true;
while ($row = mysql_fetch_row($result)){
	$thisIndex = $row[count($row) - 2];
	$cancelled = $row[count($row) - 1];
	if ($noResults){
		echo "<P ALIGN=CENTER>" . Translate("The following people are registered for this event") . ":</P>\n";
		echo "<TABLE BGCOLOR=" . $tableBGColor . " CELLPADDING=5 ALIGN=CENTER>\n";
		echo GetHeaderRow($tableData, true, Translate("Present"));
		$noResults = false;
	}
	echo GetFormData($tableData, $row, true, true, "Users", $thisIndex, $cancelled);
}
if (!$noResults){
	echo "</TABLE>\n";
}
else{
	echo "<P ALIGN=CENTER><I>" . Translate("No Users Registered") . "</I></P>\n";
}

// display confirmation dialog
echo "<P ALIGN=CENTER><INPUT TYPE=HIDDEN NAME=index VALUE=" . $index . ">\n";
echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Return", 1) . "' onClick='window.location.href=\"view_item.php?table=Events&index=" . $index . "\"'>" . Translate("Return", 2) . "\n";
echo "<INPUT TYPE=SUBMIT NAME=submit VALUE='" . Translate("Depart Event", 1) . "'>" . Translate("Depart Event", 2) . "\n";
echo "</P>\n";
echo "</FORM>\n";

include_once "footer.php";
?>

