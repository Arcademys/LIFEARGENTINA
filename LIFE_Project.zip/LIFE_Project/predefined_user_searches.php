<?
// This page is only a collection of links to predefined searches
// Since the search form uses a GET input, you can bookmark search criteria, or create links like these.

include_once "header_system.php";
$pageTitle = Translate("Predefined User Searches");
include_once "header.php";

$pageStatus = 2;

echo "<P>\n";
echo "<B>" . Translate("Please Select") . ":</B><BR>\n";
echo "<UL>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=0&criteria0function=1&criteria0value=>" . Translate("Username Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=1&criteria0function=1&criteria0value=>" . Translate("Full Name Search") . "</A></LI>\n";

echo "<LI>" . Translate("Religion Searches") . ":<UL>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=12&criteria0function=1&criteria0value=Christian>" . Translate("Christian Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=12&criteria0function=1&criteria0value=Jewish>" . Translate("Jewish Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=12&criteria0function=1&criteria0value=Muslim>" . Translate("Muslim Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=12&criteria0function=1&criteria0value=Other>" . Translate("Other Religion Search") . "</A></LI>\n";
echo "</UL></LI>\n";

echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=9&criteria0function=1&criteria0value=>" . Translate("Email Search") . "</A></LI>\n";

echo "<LI>" . Translate("Education Level Searches") . ":<UL>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=22&criteria0function=1&criteria0value=High+School>" . Translate("High School Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=22&criteria0function=1&criteria0value=Uncompleted+Degree>" . Translate("Uncompleted Degree Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=22&criteria0function=1&criteria0value=Bachelors+Degree>" . Translate("Bachelors Degree Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=22&criteria0function=1&criteria0value=Masters+Degree>" . Translate("Masters Degree Search") . "</A></LI>\n";
echo "</UL></LI>\n";


echo "<LI>" . Translate("Spanish Level Searches") . ":<UL>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=13&criteria0function=1&criteria0value=None>" . Translate("No Spanish Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=13&criteria0function=1&criteria0value=Basic>" . Translate("Basic Spanish Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=13&criteria0function=1&criteria0value=Conversational>" . Translate("Conversational Spanish Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=13&criteria0function=1&criteria0value=Fluent>" . Translate("Fluent Spanish Search") . "</A></LI>\n";
echo "</UL></LI>\n";

echo "<LI>" . Translate("Status Searches") . ":<UL>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=43&criteria0function=1&criteria0value=Admin>" . Translate("Admin Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=43&criteria0function=1&criteria0value=Intern>" . Translate("Intern Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=43&criteria0function=1&criteria0value=Active+Volunteer>" . Translate("Active Volunteer Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=43&criteria0function=1&criteria0value=Future+Volunteer>" . Translate("Future Volunteer Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=43&criteria0function=1&criteria0value=Past+Volunteer>" . Translate("Past Volunteer Search") . "</A></LI>\n";
echo "</UL></LI>\n";

echo "<LI><A HREF=search_form.php?table=Users&numCriteria=2&criteria0field=10&criteria0function=2&criteria0value=Jan+1+1980&criteria1field=10&criteria1function=3&criteria1value=Dec+31+2009>" . Translate("Date of Birth Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=2&criteria0field=3&criteria0function=2&criteria0value=Jan+1+2009&criteria1field=3&criteria1function=3&criteria1value=Dec+31+2009>" . Translate("Date of Arrival Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=2&criteria0field=4&criteria0function=2&criteria0value=Jan+1+2009&criteria1field=4&criteria1function=3&criteria1value=Dec+31+2009>" . Translate("Date of Departure Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=5&criteria0function=1&criteria0value=>" . Translate("Nationality Search") . "</A></LI>\n";

echo "<LI>" . Translate("Region Searches") . ":<UL>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=6&criteria0function=1&criteria0value=North+America>" . Translate("North America Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=6&criteria0function=1&criteria0value=Latin+America>" . Translate("Latin America Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=6&criteria0function=1&criteria0value=Europe>" . Translate("Europe Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=6&criteria0function=1&criteria0value=Asia>" . Translate("Asia Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=6&criteria0function=1&criteria0value=Africa>" . Translate("Africa Search") . "</A></LI>\n";
echo "<LI><A HREF=search_form.php?table=Users&numCriteria=1&criteria0field=6&criteria0function=1&criteria0value=Oceania>" . Translate("Oceania Search") . "</A></LI>\n";
echo "</UL></LI>\n";

echo "</UL>\n";
echo "</P>\n";

include_once "footer.php";
?>

