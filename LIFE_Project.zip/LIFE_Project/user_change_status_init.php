<?
include_once "header_system.php";

$userNum = $_GET['index'];

// Look up user name and status
$query = "SELECT user_fullname, user_status FROM Users WHERE user_id = " . $userNum;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	$pageTitle = Translate("Change Status") . " - " . Translate("Unknown User");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("User data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

$userName = $row[0];
$userStatus = $row[1];
$currentUserStatus = $_SESSION['userstatus'];

// Set page permissions so that only users of a higher level can change the status of a lower level
if ($userStatus == 1){
	$pageStatus = 1;
}
else{
	$pageStatus = $userStatus - 1;
}

if ($pageStatus > 3){
	// minimum access required to change status
	$pageStatus = 3;
}


$pageTitle = Translate("Change Status") . " - " . htmlspecialchars($userName);
include_once "header.php";

// Create form to ask for new status
echo "<FORM NAME=changeStatusForm METHOD=POST ACTION=user_change_status_results.php>\n";
echo "<TABLE ALIGN=CENTER>\n";
echo "<TR><TD ALIGN=RIGHT>" . Translate("Full Name") . ":</TD><TD>" . htmlspecialchars($userName) . "</TD></TR>\n";
echo "<TR><TD ALIGN=RIGHT>" . Translate("Status") . ":</TD><TD>";
echo "<SELECT ID=focus NAME=newStatus>\n";
$query = "SELECT choice_text, choice_value FROM Choices WHERE choice_field='user_status'";
if ($currentUserStatus != 1){
	// if not an admin, you can only set a status to something under your status
	$query .= " AND choice_value > " . $currentUserStatus;
}
$query .= " ORDER BY choice_value ASC";
$result = ExecuteQuery($query);
while ($row = mysql_fetch_row($result)){
	echo "<OPTION VALUE=" . $row[1];
	if ($row[1] == $userStatus){
		echo " SELECTED";
	}
	echo ">" . Translate($row[0], 1) . "</OPTION>\n";
}

echo "</SELECT>\n";
echo "</TD></TR>\n";

// Show a confirmation dialog
echo "<TR><TD ALIGN=CENTER COLSPAN=2>\n";
echo "<INPUT TYPE=HIDDEN NAME=index VALUE=" . $userNum . ">\n";
echo "<INPUT TYPE=BUTTON VALUE='" . Translate("Cancel", 1) . "' onClick='window.location.href=\"view_item.php?table=Users&index=" . $userNum . "\"'>" . Translate("Cancel", 2) . "\n";
echo "<INPUT TYPE=SUBMIT NAME=submit VALUE='" . Translate("Change Status", 1) . "'>" . Translate("Change Status", 2) . "\n";
echo "</TD></TR>\n";
echo "</TABLE>\n";
echo "</FORM>\n";

include_once "footer.php";
?>

