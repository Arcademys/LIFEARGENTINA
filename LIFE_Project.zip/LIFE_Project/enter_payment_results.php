<?
$noRedirect = true;
$userNum = $_POST['index'];
include "header_system.php";

// Get user name
$query = "SELECT user_fullname FROM Users WHERE user_id = " . $userNum;
$result = ExecuteQuery($query);
if (!($row = mysql_fetch_row($result))){
	$pageTitle = Translate("Enter Payment Results") . " - " . Translate("Unknown User");
	include_once "header.php";
	echo "<P ALIGN=CENTER>" . Translate("User data could not be retrieved") . "</P>\n";
	include_once "footer.php";
	exit();
}

$userName = $row[0];
$pageStatus = 2;

$pageTitle = Translate("Enter Payment Results") . " - " . $userName;
include_once "header.php";

$usd = -($_POST["usd"]);
if (!$usd){
	$usd = 0;
}
$arg = -($_POST["arg"]);
if (!$arg){
	$arg = 0;
}

// Insert payment transaction
$query = "INSERT INTO Transactions(trans_user, trans_type, trans_amount_usd, trans_amount_arg, trans_created_by) VALUES (" . $userNum . ", 2, " . $usd . ", " . $arg . ", " . $_SESSION["userid"] . ")";
if (ExecuteQuery($query)){
	$resultString = "Payment Entered";
}
else{
	$resultString = "Failure - Could not enter payment";
}

// Update user balance
$query = "UPDATE Users SET user_balance_usd = user_balance_usd + " . $usd . ", user_balance_arg = user_balance_arg + " . $arg . " WHERE user_id = " . $userNum;
ExecuteQuery($query);

echo "<P ALIGN=CENTER>" . Translate($resultString) . "</P>\n";
echo "<P ALIGN=CENTER><INPUT TYPE=BUTTON VALUE='" . Translate("Return", 1) . "' onClick='window.location.href=\"view_item.php?table=Users&index=" . $userNum . "\"'>" . Translate("Return", 2) . "</P>\n";

include_once "footer.php";
?>

