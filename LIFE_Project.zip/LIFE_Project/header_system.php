<?
// This standard include file sets up the session and the database access

session_start();

if (strstr($_SERVER["REQUEST_URI"], "local")){
	mysql_connect(localhost,"root","abc123");
	if (strstr($_SERVER["REQUEST_URI"], "lifeDev")){
		@mysql_select_db("lifeDev") or die("Unable to select database");
		$pageBGColor = "DDFFDD";
		$tableCellColor = "CCFFCC";
		$tableHeadingColor = "BBFFBB";
		$tableBGColor = "AAFFAA";
	}
	else{
		@mysql_select_db("life") or die("Unable to select database");
		$pageBGColor = "FFDDDD";
		$tableCellColor = "FFCCCC";
		$tableHeadingColor = "FFBBBB";
		$tableBGColor = "FFAAAA";
	}
}
else{
	if (strstr($_SERVER["REQUEST_URI"], "lifeDev")){
		mysql_connect("72.167.233.86","gruther4_lifeDev","PASSWORD_GOES_HERE");
		@mysql_select_db("gruther4_lifeDev") or die("Unable to select database");
		$pageBGColor = "DDDDFF";
		$tableCellColor = "CCCCFF";
		$tableHeadingColor = "BBBBFF";
		$tableBGColor = "AAAAFF";
	}
	else{
		// *** NOTE for Juan Jose Benitez! *** This is where you will need to put the new DB login information....
		mysql_connect("72.167.233.88","gruther4_life","PASSWORD_GOES_HERE");
		@mysql_select_db("gruther4_life") or die("Unable to select database");
		$pageBGColor = "FFFFFF";
		$tableCellColor = "EEEEEE";
		$tableHeadingColor = "DDDDDD";
		$tableBGColor = "CCCCCC";
	}
}

include_once "functions.php";
?>
